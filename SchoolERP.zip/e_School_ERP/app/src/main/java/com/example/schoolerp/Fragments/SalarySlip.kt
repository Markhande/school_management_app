package com.example.schoolerp.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentPaySalaryBinding

class SalarySlip : Fragment() {
    private lateinit var binding:FragmentPaySalaryBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentPaySalaryBinding.bind(inflater.inflate(R.layout.fragment_pay_salary,null))
        return binding.root
    }
}