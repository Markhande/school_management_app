package com.example.schoolerp.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolerp.DataClasses.StudentIDData
import com.example.schoolerp.R

class StduentIDAdapter(private var studentList: List<StudentIDData>) : RecyclerView.Adapter<StduentIDAdapter.StudentViewHolder>() {

    // Inflate the layout for each item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.icard_layout, parent, false)
        return StudentViewHolder(view)
    }

    // Bind the data to the view holder
    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        val student = studentList[position]
        holder.bind(student)
    }

    // Return the size of the data list
    override fun getItemCount(): Int {
        return studentList.size
    }

    // ViewHolder class to represent each student item
    class StudentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val studentName: TextView = itemView.findViewById(R.id.studentName)
        private val studentId: TextView = itemView.findViewById(R.id.studentId)
        private val studentDob: TextView = itemView.findViewById(R.id.studentDob)
        private val studentAddress: TextView = itemView.findViewById(R.id.studentAddress)
        private val studentImage: ImageView = itemView.findViewById(R.id.studentImage)

        // Bind the student data to the UI elements
        fun bind(student: StudentIDData) {
            studentName.text = student.name
            studentId.text = student.name
            studentDob.text = student.dob
            studentAddress.text = student.address

            // Optionally set an image, or use a placeholder
            studentImage.setImageResource(R.drawable.teacherprofile) // Placeholder image
        }
    }

    // Update the student list dynamically and refresh
    fun updateStudentList(newStudentList: List<StudentIDData>) {
        studentList = newStudentList
        notifyDataSetChanged() // Refresh the data in RecyclerView
    }
}
