package com.example.schoolerp.Fragments

import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.example.schoolerp.Adapter.EmployeeAttandanceAdapter
import com.example.schoolerp.Adapters.AbsentStudentAdapter
import com.example.schoolerp.DataClasses.AbsentStudent
import com.example.schoolerp.DataClasses.AllEmployee
import com.example.schoolerp.DataClasses.Student
import com.example.schoolerp.Fragments.Fragment.AddStudent
import com.example.schoolerp.R
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.ClassItem
import com.example.schoolerp.DataClasses.EmployeeAttendance
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentDashBoardBinding
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.repository.AllEmployeesRepository
import com.example.schoolerp.repository.EmloyeesAttendanceRepository
import com.example.schoolerp.repository.GetAttendanceRepository
import com.example.schoolerp.repository.getStudentRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodel.AllEmployeesViewModel
import com.example.schoolerp.viewmodel.AttendanceViewModel
import com.example.schoolerp.viewmodel.EmployeesAttendanceViewModel
import com.example.schoolerp.viewmodel.getStudentViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import com.example.schoolerp.viewmodelfactory.AllEmployeesViewModelFactory
import com.example.schoolerp.viewmodelfactory.AttendanceViewModelFactory
import com.example.schoolerp.viewmodelfactory.EmployeesAttendanceViewModelFactory
import com.example.schoolerp.viewmodelfactory.getStudentViewModelFactory
import com.example.student.student_dash_board
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.HorizontalBarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DashBoard : Fragment() {
    private lateinit var binding: FragmentDashBoardBinding
    private lateinit var lineChart: LineChart
    private lateinit var barChart: BarChart
    private lateinit var lineChartEstimationRemaining: HorizontalBarChart
    private lateinit var horizontalBarChart: BarChart
    private lateinit var horizontalBarChartPresently: HorizontalBarChart
    private lateinit var absentStudentAdapter: AbsentStudentAdapter
    private var absentStudents = mutableListOf<AbsentStudent>()
    private lateinit var viewModelAllStudent: getStudentViewModel
    private lateinit var absentEmployeesAdapter: EmployeeAttandanceAdapter
    private var absentEmployees = mutableListOf<EmployeeAttendance>()

    private lateinit var viewModelAllEmployees: AllEmployeesViewModel
    private lateinit var viewModelAllAttendance: AttendanceViewModel
    private lateinit var viewModelAttendanceEmployees: EmployeesAttendanceViewModel
    private lateinit var viewModelAllClasses: AllClassViewModel
    private val estimationEntries = ArrayList<BarEntry>()
    private val remainingEntries = ArrayList<BarEntry>()
    private val plannedEntries = ArrayList<BarEntry>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentDashBoardBinding.bind(inflater.inflate(R.layout.fragment_dash_board, null))

        lineChart = binding.lineChartAccountOverview
        barChart = binding.pieChartClassStrength
        // lineChartEstimationRemaining = binding.horizontalBarChartFees
        horizontalBarChart = binding.horizontalBarChartFees
        horizontalBarChartPresently = binding.horizontalBarChartPresently

        when (SchoolId().getLoginRole(requireContext())) {
            "Student" -> studentDetails()
            "Admin" -> adminDetails()
            "Principal" -> principalDetails()
        }

        binding.showmypersonalinfo.setOnClickListener {
            // Toggle visibility of the layout
            extendShowMyProfile()
        }





        // Inflate and add Layout 1
        val layout1 = inflater.inflate(R.layout.principal_dash_board, binding.root, false)
        binding.root.addView(layout1)

        val textView1: TextView = layout1.findViewById(R.id.PricipaledashBoard)
        textView1.text = "This is principal dash board"

        return binding.root
    }

    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
        }

        return schoolId ?: "defaultSchoolId" // Return the schoolId or a default value
    }

    private fun setupViewModelAllStudent() {
        val apiService = RetrofitHelper.getApiService()
        val repository = getStudentRepository(apiService)
        val factory = getStudentViewModelFactory(repository)
        viewModelAllStudent = ViewModelProvider(this, factory).get(getStudentViewModel::class.java)

    }

    private fun fetchStudent() {
        val schoolId = getSchoolId() // Assuming you have a method to get school ID
        viewModelAllStudent.fetchStudentsBySchoolId(schoolId.trim()) // Fetch employees and observe the count
    }


    private fun observeStudents() {
        viewModelAllStudent.students.observe(viewLifecycleOwner) { students ->
            val studentCount = students.size
            if (studentCount > 0) {
                binding.studentCountText.text = "$studentCount"
            } else {
                binding.studentCountText.text = "No students available"
            }
            Log.d("DashBoard", "Total student count observed: $studentCount")

            // Filter students added in the current month
            val currentMonthStudentCount = getCurrentMonthStudentCount(students)
            binding.currentMonthStudentCountText.text = "$currentMonthStudentCount"
            Log.d("DashBoard", "Current month student count observed: $currentMonthStudentCount")
        }
    }

    private fun getCurrentMonthStudentCount(students: List<Student>): Int {
        // Get current month using Calendar
        val currentMonth =
            Calendar.getInstance().get(Calendar.MONTH) + 1  // Calendar.MONTH is 0-based (Jan = 0)

        val dateFormat = SimpleDateFormat(
            "yyyy-MM-dd HH:mm:ss",
            Locale.getDefault()
        ) // Adjust the format to match the input string

        return students.count { student ->
            // Assuming `created_at` is a String with date and time format "yyyy-MM-dd HH:mm:ss"
            val registrationMonth = student.created_at?.let {
                try {
                    val date = dateFormat.parse(it) // Parse the full date-time string
                    val calendar = Calendar.getInstance()
                    calendar.time = date
                    calendar.get(Calendar.MONTH) + 1 // Convert to 1-based month
                } catch (e: Exception) {
                    Log.e("DashBoard", "Error parsing created_at date: ${student.created_at}", e)
                    null // In case of error, return null to not count the student
                }
            }

            registrationMonth == currentMonth
        }
    }


    private fun SetUPListners() {
        // Listener for all students
        binding.TotalStudent.setOnClickListener {
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(
                R.id.fragment_container,
                AllStudent()
            )
            transaction.addToBackStack(null)
            transaction.commit()
        }

        // Listener for all employees
        binding.TotalEmployees.setOnClickListener {
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(
                R.id.fragment_container,
                AllEmployees()
            )
            transaction.addToBackStack(null)
            transaction.commit()
        }

        // Listener for adding a student
        binding.btnAddStudent.setOnClickListener {
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, AddStudent())
            transaction.addToBackStack(null)
            transaction.commit()
        }
    }


    private fun setupViewModelAllEmployees() {
        val apiService = RetrofitHelper.getApiService()
        val repository = AllEmployeesRepository(apiService)
        val factory = AllEmployeesViewModelFactory(repository)
        viewModelAllEmployees =
            ViewModelProvider(this, factory).get(AllEmployeesViewModel::class.java)
    }


    private fun observeTotalEmployeeCount() {
        viewModelAllEmployees.employeeResponse.observe(viewLifecycleOwner) { response ->
            // Safely handle null and empty employee list
            if (response != null && response.employee != null && response.employee.isNotEmpty()) {
                val totalEmployeeCount = response.employee.size
                val currentMonthEmployeeCount = getEmployeesCountForCurrentMonth(response.employee)

                binding.totalEmployeeCountTextView.text = "$totalEmployeeCount"

                binding.currentMonthEmployeeCountTextView.text =
                    if (currentMonthEmployeeCount > 0) {
                        "$currentMonthEmployeeCount"
                    } else {
                        "No employees this month"
                    }
            } else {
                // Handle case when response.employee is null or empty
                binding.totalEmployeeCountTextView.text = "No employees available"
                binding.currentMonthEmployeeCountTextView.text = "No employees this month"
            }
        }
    }


    private fun fetchEmployees() {
        val schoolId = getSchoolId() // Assuming you have a method to get school ID
        viewModelAllEmployees.getAllEmployees(schoolId.trim()) // Fetch employees and observe the count
    }

    private fun getEmployeesCountForCurrentMonth(employees: List<AllEmployee>): Int {
        val currentMonth = SimpleDateFormat("MM", Locale.getDefault()).format(Date())

        return employees.count { employee ->
            employee.created_at.substring(
                5,
                7
            ) == currentMonth // Compare month part of "yyyy-MM-dd"
        }
    }

    private fun setupViewModelAllAttadance() {
        val apiService = RetrofitHelper.getApiService()
        val repository = GetAttendanceRepository(apiService)
        val factory = AttendanceViewModelFactory(repository)
        viewModelAllAttendance =
            ViewModelProvider(this, factory).get(AttendanceViewModel::class.java)

        val schoolId =
            getSchoolId() // Retrieve the schoolId here (e.g., from SharedPreferences or passed as an argument)
        viewModelAllAttendance.fetchStudentAttendance(schoolId.trim()) // Pass schoolId here
    }

    private fun initViewAbsentStudent() {
        // Initialize RecyclerViews with GridLayoutManager
        binding.recyclerViewStudents.layoutManager =
            GridLayoutManager(context, 2, GridLayoutManager.HORIZONTAL, false)
        //  binding.recyclerViewStudentPresent.layoutManager = GridLayoutManager(context, 2, GridLayoutManager.HORIZONTAL, false)
        //  binding.recyclerViewStudentLate.layoutManager = GridLayoutManager(context, 2, GridLayoutManager.HORIZONTAL, false)

        // Initialize the adapters
        absentStudentAdapter = AbsentStudentAdapter(absentStudents)
        //  presentStudentAdapter = AbsentStudentAdapter(presentStudents)
        // lateStudentAdapter = AbsentStudentAdapter(lateStudents)

        // Set the adapters to respective RecyclerViews
        binding.recyclerViewStudents.adapter = absentStudentAdapter
        //binding.recyclerViewStudentPresent.adapter = presentStudentAdapter
        //binding.recyclerViewStudentLate.adapter = lateStudentAdapter
        checkForNoAbsentStudents()

    }

    private fun observeAttendanceData() {
        viewModelAllAttendance.studentAttendance.observe(viewLifecycleOwner, Observer { response ->
            if (response != null) {
                if (response.status) {
                    // Log the full data for debugging
                    Log.d("AttendanceData", "Received student attendance data: ${response.data}")

                    // Get today's date
                    val currentDate = getCurrentDate()

                    // Filter the data for today's attendance
                    val todayData = response.data.filter { it.date == currentDate }

                    if (todayData.isNotEmpty()) {
                        // Calculate total students for today
                        val totalStudents = todayData.size

                        // Count present students
                        val presentStudents = todayData.count { it.status.equals("P", ignoreCase = true) }

                        // Check if there are any present students
                        if (presentStudents > 0) {
                            // Calculate present students' percentage
                            val presentStudentsPercentage = if (totalStudents > 0) {
                                (presentStudents.toFloat() / totalStudents.toFloat()) * 100
                            } else {
                                0f
                            }

                            // Update the graph with the calculated percentage
                            updateEstimationEntries(presentStudentsPercentage)

                            // Show the graph
                            binding.horizontalBarChartPresently.visibility = View.VISIBLE
                            binding.noPresentStudentsTextView.visibility = View.GONE // Hide the no data message
                        } else {
                            // No present students, show a message
                            showNoPresentStudentsMessage()
                        }

                        // Filter students based on today's data (Absent Students)
                        filterStudentsByStatus(todayData)

                        // Check for absent students
                        if (absentStudents.isEmpty()) {
                            showNoAbsentStudentsMessage()
                        } else {
                            // Update the adapter with absent students
                            absentStudentAdapter.updateData(absentStudents)
                            showAbsentStudents()
                        }

                        // Log present students' names for debugging
                        val studentNames = todayData.map { it.st_name }
                        Log.d("StudentNames", "Present Students: $studentNames")

                        Log.d("AttendanceData", "Today's attendance data processed successfully.")
                    } else {
                        // Handle case where no data is available for today
                        showNoTodayDataMessage()
                    }
                } else {
                    // Handle cases where the response status is false
                    Toast.makeText(context, "No data available", Toast.LENGTH_SHORT).show()
                    Log.d("AttendanceData", "No attendance data available.")
                }
            } else {
                // Handle case when response is null
                Toast.makeText(context, "Failed to fetch data", Toast.LENGTH_SHORT).show()
                Log.e("AttendanceData", "Failed to fetch attendance data: response is null.")
            }
        })
    }

    private fun filterStudentsByStatus(students: List<AbsentStudent>) {
        // Clear the previous data
        absentStudents.clear()

        // Get today's date
        val currentDate = getCurrentDate()

        // Iterate over each student and categorize them by status and date
        for (student in students) {
            if (student.status == "A" && student.date == currentDate) {
                absentStudents.add(student)  // Only consider absent students for today
            }
        }

    }

    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1 // Calendar month is 0-based
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        return String.format("%04d-%02d-%02d", year, month, day)
    }

    private fun showNoTodayDataMessage() {
        binding.recyclerViewStudents.visibility = View.GONE  // Hide RecyclerView
        binding.noAbsentStudentsTextView.text = "Today's students are not marked."
        binding.noAbsentStudentsTextView.visibility = View.VISIBLE  // Show the message
    }

    private fun showNoAbsentStudentsMessage() {
        binding.recyclerViewStudents.visibility = View.GONE  // Hide RecyclerView
        binding.noAbsentStudentsTextView.text = "No absent students."
        binding.noAbsentStudentsTextView.visibility = View.VISIBLE  // Show the message
    }

    private fun showAbsentStudents() {
        binding.recyclerViewStudents.visibility = View.VISIBLE // Show RecyclerView
        binding.noAbsentStudentsTextView.visibility = View.GONE  // Hide the message
    }

    private fun checkForNoAbsentStudents() {
        // If there are no absent students, show a message
        if (absentStudents.isEmpty()) {
            binding.recyclerViewStudents.visibility = View.GONE  // Hide RecyclerView
            binding.noAbsentStudentsTextView.visibility =
                View.VISIBLE // Show the "No absent students" message
        } else {
            binding.recyclerViewStudents.visibility = View.VISIBLE // Show RecyclerView
            binding.noAbsentStudentsTextView.visibility =
                View.GONE  // Hide the "No absent students" message
        }
    }

    private fun setupViewModelAttendanceEmployee() {
        val apiService = RetrofitHelper.getApiService()
        val repository = EmloyeesAttendanceRepository(apiService)
        val factory = EmployeesAttendanceViewModelFactory(repository)
        viewModelAttendanceEmployees =
            ViewModelProvider(this, factory).get(EmployeesAttendanceViewModel::class.java)

        val schoolId =
            getSchoolId() // Retrieve the schoolId (e.g., from SharedPreferences or passed as an argument)
        viewModelAttendanceEmployees.getEmployeeAttendance(schoolId.trim())
    }

    private fun initViewAbsentEmployees() {
        // Log the data being passed to the adapter
        // Log.d("AttendanceData", "Absent employees list before setting adapter: $absentEmployees")

        // Ensure RecyclerView is properly set up
        binding.recyclerViewEmployeeAbsent.layoutManager =
            GridLayoutManager(context, 2, GridLayoutManager.HORIZONTAL, false)

        // Log the adapter creation and data assignment
        absentEmployeesAdapter = EmployeeAttandanceAdapter(absentEmployees)
        binding.recyclerViewEmployeeAbsent.adapter = absentEmployeesAdapter

        // Log after setting the adapter
        Log.d("AttendanceData", "Adapter set with data: $absentEmployees")
    }

    private fun observeEmployeesAttendanceData() {
        viewModelAttendanceEmployees.employeeAttendanceData.observe(
            viewLifecycleOwner,
            Observer { response ->
                if (response != null && response.status) {
                    // Log the full response for debugging
                    Log.d("AttendanceData", "Received employee attendance data: ${response.data}")

                    // Get today's date
                    val currentDate = getCurrentDate()

                    // Filter data for today's attendance
                    val todayData = response.data.filter { it.date == currentDate }

                    if (todayData.isNotEmpty()) {
                        // Calculate total employees for today
                        val totalEmployees = todayData.size

                        // Count present employees
                        val presentEmployeesCount =
                            todayData.count { it.status.equals("P", ignoreCase = true) }

                        // Calculate present employees percentage
                        val presentEmployeesPercentage = if (totalEmployees > 0) {
                            (presentEmployeesCount.toFloat() / totalEmployees.toFloat()) * 100
                        } else {
                            0f
                        }

                        // Log the calculated percentage
                        Log.d(
                            "AttendanceData",
                            "Present Employees Percentage: $presentEmployeesPercentage"
                        )

                        // Now check if there are any present employees
                        if (presentEmployeesCount > 0) {
                            // If present employees exist, update the chart with the calculated percentage
                            updateRemainingEntries(presentEmployeesPercentage)
                            binding.horizontalBarChartPresently.visibility = View.VISIBLE // Show the graph
                            binding.noPresentEmployeesTextView.visibility = View.GONE // Hide the text message
                        } else {
                            // If no present employees, show the text message
                            showNoPresentEmployeesMessage()
                        }

                        // Filter and display absent employees
                        filterEmployeesByStatus(todayData)

                        if (absentEmployees.isEmpty()) {
                            showNoAbsentEmployeesMessage()
                        } else {
                            updateAbsentEmployeesList()
                        }

                    } else {
                        // No data available for today
                        showNoTodayDataEmpMessage()
                    }
                } else {
                    // Handle cases where response is null or status is false
                    showDataFetchErrorMessage()
                }
            }
        )
    }
    private fun showNoTodayDataEmpMessage() {
        binding.recyclerViewEmployeeAbsent.visibility = View.GONE
        binding.noAbsentEmployeesTextView.text = "Today's employees are not marked."
        binding.noAbsentEmployeesTextView.visibility = View.VISIBLE
    }

    private fun updateAbsentEmployeesList() {
        binding.recyclerViewEmployeeAbsent.visibility = View.VISIBLE
        binding.noAbsentEmployeesTextView.visibility = View.GONE
        absentEmployeesAdapter.updateData(absentEmployees)
    }

    private fun showDataFetchErrorMessage() {
        binding.recyclerViewEmployeeAbsent.visibility = View.GONE
        binding.noAbsentEmployeesTextView.text = "Failed to fetch attendance data."
        binding.noAbsentEmployeesTextView.visibility = View.VISIBLE
        Toast.makeText(context, "Failed to fetch data", Toast.LENGTH_SHORT).show()
        Log.e(
            "AttendanceData",
            "Failed to fetch employee attendance data: response is null or invalid."
        )
    }


    private fun showNoAbsentEmployeesMessage() {
        binding.recyclerViewEmployeeAbsent.visibility = View.GONE
        binding.noAbsentEmployeesTextView.text = "No absent employees."
        binding.noAbsentEmployeesTextView.visibility = View.VISIBLE
    }


    private fun filterEmployeesByStatus(employees: List<EmployeeAttendance>) {
        absentEmployees.clear()

        val currentDate = getCurrentDate()

        for (employee in employees) {
            if (employee.status == "A" && employee.date == currentDate) {
                absentEmployees.add(employee)
            }
        }

        Log.d("AttendanceData", "Filtered absent employees for today: $absentEmployees")
    }


    private fun initData() {
    }

    private fun setUpListeners() {
    }

    private fun initLineChartData() {
        val entries = ArrayList<Entry>()
        entries.add(Entry(0f, 2f))
        entries.add(Entry(1f, 5f))
        entries.add(Entry(2f, 3f))
        entries.add(Entry(3f, 6f))
        entries.add(Entry(4f, 4f))

        val lineDataSet = LineDataSet(entries, "Sample Data")
        lineDataSet.color = resources.getColor(R.color.teal_200)
        lineDataSet.valueTextColor = resources.getColor(R.color.white)
        lineDataSet.lineWidth = 2f

        val lineData = LineData(lineDataSet)
        lineChart.data = lineData

        // Configure X and Y axis
        val xAxis = lineChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.labelRotationAngle = -45f
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "Point $value"
            }
        }

        val yAxis: YAxis = lineChart.axisLeft
        yAxis.axisMinimum = 0f
        lineChart.axisRight.isEnabled = false

        lineChart.invalidate() // Refresh chart
    }

    private fun setupViewModelAllClasses() {
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewModelAllClasses = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)


    }

    private fun observeAllClasses() {
        // Get the school ID
        val schoolId = getSchoolId()?.trim() ?: ""

        // Observe the LiveData returned by the ViewModel
        viewModelAllClasses.getClasses(schoolId).observe(viewLifecycleOwner) { response ->
            response?.data?.let {
                // Pass the class data to the chart initialization method
                initBarChartAllClassesData(it)
            }
        }
    }


    private fun initBarChartAllClassesData(classData: List<ClassItem>) {
        val barEntries = ArrayList<BarEntry>()
        val classLabels = ArrayList<String>()

        classData.forEachIndexed { index, data ->
            data.total_students?.let {
                barEntries.add(BarEntry(index.toFloat(), it.toFloat()))
                classLabels.add(data.class_name ?: "Class ${index + 1}")
            }
        }

        val barDataSet = BarDataSet(barEntries, "Classes Strength")
        barDataSet.color = resources.getColor(R.color.studentColor)
        barDataSet.valueTextColor = resources.getColor(R.color.white)
        barDataSet.valueTextSize = 12f

        val barData = BarData(barDataSet)
        barChart.data = barData

        val xAxis = barChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.valueFormatter = IndexAxisValueFormatter(classLabels)
        xAxis.setLabelCount(classData.size, false)

        val yAxis = barChart.axisLeft
        yAxis.axisMinimum = 0f
        barChart.axisRight.isEnabled = false

        barChart.setVisibleXRangeMaximum(4f)
        barChart.isDragEnabled = true
        barChart.setScaleEnabled(false)

        barChart.invalidate()
    }


    private fun initEstimationRemainingData() {
        val estimationEntries = ArrayList<BarEntry>().apply {
            add(BarEntry(0f, 30f))
        }

        val remainingEntries = ArrayList<BarEntry>().apply {
            add(BarEntry(1f, 50f))
        }

        val plannedEntries = ArrayList<BarEntry>().apply {
            add(BarEntry(2f, 60f))
        }

        val context = requireContext()

        val estimationDataSet = BarDataSet(estimationEntries, "Estimation").apply {
            color = ContextCompat.getColor(context, R.color.red)
            valueTextColor = ContextCompat.getColor(context, R.color.white)
        }

        val remainingDataSet = BarDataSet(remainingEntries, "Remaining").apply {
            setGradientColor(
                Color.parseColor("#FFFF00"),
                Color.parseColor("#FFAA00")
            )
            valueTextColor = ContextCompat.getColor(context, R.color.white)
        }

        val plannedDataSet = BarDataSet(plannedEntries, "Collection").apply {
            color = ContextCompat.getColor(context, R.color.global_button_background)
            valueTextColor = ContextCompat.getColor(context, R.color.white)
        }

        val barData = BarData(estimationDataSet, remainingDataSet, plannedDataSet)
        barData.barWidth = 0.3f

        horizontalBarChart.data = barData

        val xAxis = horizontalBarChart.xAxis
        xAxis.position = XAxis.XAxisPosition.TOP
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return when (value.toInt()) {
                    0 -> "Estimation"
                    1 -> "Remaining"
                    2 -> "Collection"
                    else -> ""
                }
            }
        }

        val yAxisLeft = horizontalBarChart.axisLeft
        yAxisLeft.granularity = 1f
        yAxisLeft.setDrawGridLines(true)

        horizontalBarChart.axisRight.isEnabled = false

        horizontalBarChart.description.isEnabled = false
        horizontalBarChart.setFitBars(true)

        horizontalBarChart.invalidate()
    }

    private fun showNoPresentStudentsMessage() {
        // Hide RecyclerView if no data available
        binding.horizontalBarChartPresently.visibility = View.GONE
        // Show the message indicating no present students today
        binding.noPresentStudentsTextView.text = "Today's students are not present."
        binding.noPresentStudentsTextView.visibility = View.VISIBLE
    }

    private fun showNoPresentEmployeesMessage() {
        // Hide RecyclerView if no data available
        binding.horizontalBarChartPresently.visibility = View.GONE
        // Show the message indicating no present employees today
        binding.noPresentEmployeesTextView.text = "No present employees today."
        binding.noPresentEmployeesTextView.visibility = View.VISIBLE
    }

    private fun showNoPresentStudentsMessageAreNotMark() {
        binding.horizontalBarChartPresently.visibility = View.GONE  // Hide RecyclerView
        binding.noPresentStudentsTextView.text = "Today's students are not marked."
        binding.noPresentStudentsTextView.visibility = View.VISIBLE  // Show the message
    }

    private fun showNoTodayDataEmp() {
        binding.recyclerViewEmployeeAbsent.visibility = View.GONE
        binding.noPresentEmployeesTextView.text = "Today's employees are not marked."
        binding.noPresentEmployeesTextView.visibility = View.VISIBLE
    }


    /*private fun showNoFeesCollectionMessage() {
        // Hide RecyclerView if no data available
        binding.recyclerViewFees.visibility = View.GONE
        // Show the message indicating no fees collection
        binding.noFeesCollectionTextView.text = "No fees collected today."
        binding.noFeesCollectionTextView.visibility = View.VISIBLE
    }
*/

    private fun updateEstimationEntries(presentStudentsPercentage: Float) {
        // Clear the old data and add the new one
        estimationEntries.clear()
        estimationEntries.add(BarEntry(0f, presentStudentsPercentage))
        updateChart() // Refresh the chart after adding the new data
    }

    // Update Remaining Entries with the data for Present Employees
    private fun updateRemainingEntries(presentEmployeesPercentage: Float) {
        // Clear the old data and add the new one
        remainingEntries.clear()
        remainingEntries.add(BarEntry(1f, presentEmployeesPercentage))
        updateChart() // Refresh the chart after adding the new data
    }

    // Update Planned Entries with the data for Fees Collection
    private fun updatePlannedEntries(feesCollectionPercentage: Float) {
        // Clear the old data and add the new one
        plannedEntries.clear()
        plannedEntries.add(BarEntry(2f, feesCollectionPercentage))
        updateChart() // Refresh the chart after adding the new data
    }


    private fun updateChart() {
        val context = requireContext()

        // Check if data for Present Students, Present Employees, and Fees Collection is available
        val isPresentStudentsAvailable = estimationEntries.isNotEmpty()
        val isPresentEmployeesAvailable = remainingEntries.isNotEmpty()
        val isFeesCollectionAvailable = plannedEntries.isNotEmpty()

        // Show appropriate message if no data is available
        if (!isPresentStudentsAvailable) {
            showNoPresentStudentsMessage()
        } else {
            binding.horizontalBarChartPresently.visibility = View.VISIBLE // Ensure chart is visible if data is available
        }

        if (!isPresentEmployeesAvailable) {
            showNoPresentEmployeesMessage()
        } else {
            binding.horizontalBarChartPresently.visibility = View.VISIBLE // Ensure chart is visible if data is available
        }

        // You can add a similar function for Fees Collection if needed

        // Creating BarDataSet for each category
        val estimationDataSet = BarDataSet(estimationEntries, "Present Students").apply {
            color = ContextCompat.getColor(context, R.color.studentColor)
            valueTextColor = ContextCompat.getColor(context, R.color.white)
            valueTextSize = 14f
            setDrawValues(true)
        }

        val remainingDataSet = BarDataSet(remainingEntries, "Present Employees").apply {
            color = ContextCompat.getColor(context, R.color.employeeColor)
            valueTextColor = ContextCompat.getColor(context, R.color.white)
            valueTextSize = 14f
            setDrawValues(true)
        }

        val plannedDataSet = BarDataSet(plannedEntries, "Fees Collection").apply {
            color = ContextCompat.getColor(context, R.color.global_button_background)
            valueTextColor = ContextCompat.getColor(context, R.color.white)
            valueTextSize = 14f
            setDrawValues(true)
        }

        // Add datasets only if data is available
        val datasets = mutableListOf<IBarDataSet>()
        if (isPresentStudentsAvailable) datasets.add(estimationDataSet)
        if (isPresentEmployeesAvailable) datasets.add(remainingDataSet)
        if (isFeesCollectionAvailable) datasets.add(plannedDataSet)

        // If no data is available for all categories, hide the chart
        if (datasets.isEmpty()) {
            binding.horizontalBarChartPresently.visibility = View.GONE
            Toast.makeText(context, "No data available", Toast.LENGTH_SHORT).show()
            return
        }

        // Continue with your BarData setup
        val barData = BarData(datasets)
        barData.barWidth = 0.3f

        // Update chart with new data
        horizontalBarChartPresently.data = barData
        horizontalBarChartPresently.invalidate()  // Refresh the chart view

        // Configure the X-Axis
        val xAxis = horizontalBarChartPresently.xAxis
        xAxis.position = XAxis.XAxisPosition.TOP
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return when (value.toInt()) {
                    0 -> if (isPresentStudentsAvailable) "Today Present Students" else "Not Available"
                    1 -> if (isPresentEmployeesAvailable) "Today Present Employees" else "Not Available"
                    2 -> if (isFeesCollectionAvailable) "Fees Collection" else "Not Available"
                    else -> ""
                }
            }
        }

        // Configure the Y-Axis
        val yAxisLeft = horizontalBarChartPresently.axisLeft
        yAxisLeft.granularity = 1f
        yAxisLeft.setDrawGridLines(true)
        horizontalBarChartPresently.axisRight.isEnabled = false

        // Disable chart description
        horizontalBarChartPresently.description.isEnabled = false
        horizontalBarChartPresently.setFitBars(true)
        horizontalBarChartPresently.setDrawValueAboveBar(true)

        // Ensure chart is refreshed with new data
        horizontalBarChartPresently.invalidate()
    }

    //   ----------------Admin dash visible------------------
    private fun adminDetails(){
        binding.scrollViewAdmin.visibility = View.VISIBLE
        setupViewModelAllAttadance()
        setupViewModelAllStudent()
        setupViewModelAllEmployees()
        setupViewModelAttendanceEmployee()
        observeEmployeesAttendanceData()
        setupViewModelAllClasses()
        observeAllClasses()
        //  loadStudentCount()
        // observeStudentCount()
        observeAttendanceData()
        initViewAbsentEmployees()
        initViewAbsentStudent()
        initData()
        setUpListeners()
        observeStudents()
        SetUPListners()
        initLineChartData()
        //initBarChartAllClassesData()
        initEstimationRemainingData()
        // initPresentlyData()
        getSchoolId()
        fetchEmployees()
        fetchStudent()
        observeTotalEmployeeCount()
        observeAttendanceData()
    }

    //   ----------------student dash visible------------------
    private fun studentDetails(){
        binding.scrollViewAdmin.visibility = View.GONE
        binding.scrollViewStudent.visibility = View.VISIBLE
    }

    //   ----------------principal dash visible------------------
    private fun principalDetails(){
        binding.scrollViewAdmin.visibility = View.GONE
        binding.scrollViewStudent.visibility = View.GONE
        binding.scrollViewPrincipal.visibility = View.VISIBLE
    }

    //   ----------------method show my profile for student ------------------
    private fun extendShowMyProfile(){
            // Toggle visibility of the layout
            if (binding.layoutstudentpersonalinfo.visibility == View.GONE) {
                binding.layoutstudentpersonalinfo.visibility = View.VISIBLE
                binding.showmypersonalinfo.text = "Hide My Personal Information"
//                binding.arrowdown.setImageResource(R.drawable.arrow_up)
            } else {
                binding.layoutstudentpersonalinfo.visibility = View.GONE
                binding.showmypersonalinfo.text = "Show My Personal Information"
//                binding.arrowdown.setImageResource(R.drawable.arrow_down)
            }

    }
}
