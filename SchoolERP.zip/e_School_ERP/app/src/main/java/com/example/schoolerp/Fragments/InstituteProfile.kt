package com.example.schoolerp.Fragments.Fragment

import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.databinding.FragmentInstituteProfileBinding
import com.example.schoolerp.repository.InstituteProfileRepository
import com.example.schoolerp.viewmodel.InstituteProfileViewModel
import com.example.schoolerp.viewmodelfactory.InstituteProfileViewModelFactory
import java.io.ByteArrayOutputStream

class InstituteProfile : Fragment() {
    private var _binding: FragmentInstituteProfileBinding? = null
    private val binding get() = _binding!!
    var schoolId = ""

    val ab = SchoolId()
    private val instituteViewModel: InstituteProfileViewModel by viewModels {
        InstituteProfileViewModelFactory(InstituteProfileRepository(RetrofitHelper.getApiService()))
    }

    private var selectedImageUri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInstituteProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Button click listener for uploading logo
        binding.btnUploadLogo.setOnClickListener {
            openImageChooser()
        }

        // Button click listener for submitting data
        binding.btnSubmitInstituteProfile.setOnClickListener {
            submitInstituteData()
        }


//      ----------------set Text From API--------------------------
        binding.etNameOfInstitute.setText(ab.getSchoolName(requireContext()))
        binding.etPhoneNumber.setText(ab.getSchoolNumber(requireContext()))
        binding.etAddress.setText(ab.getSchoolAdress(requireContext()))
        binding.etWebsite.setText(ab.getSchoolWebSite(requireContext()))
        binding.etTargetLine.setText(ab.getSchoolTagLine(requireContext()))
//        val editTextInstituteName = view.findViewById<TextInputEditText>(R.id.etTargetLine)
//        editTextInstituteName.setText(ab.getSchoolTagLine(requireContext()))


        observeViewModel()
    }

    private fun openImageChooser() {
        val intent = Intent().apply {
            type = "image/*"
            action = Intent.ACTION_GET_CONTENT
        }
        imagePickerLauncher.launch(intent)
    }

    private val imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val data = result.data
            selectedImageUri = data?.data
            binding.ivImageLog.setImageURI(selectedImageUri)
        }
    }

    private fun submitInstituteData() {
        val nameOfInstitute = binding.etNameOfInstitute.text.toString().trim()
        val phoneNumber = binding.etPhoneNumber.text.toString().trim()
        val schoolId = SchoolId().getSchoolId(requireContext())
        val address = binding.etAddress.text.toString().trim()
        val targetLine = binding.etTargetLine.text.toString().trim()
        val website = binding.etWebsite.text.toString().trim()
        val country = binding.edtCountry.selectedItem.toString()
        val imageLog = selectedImageUri?.let { uri ->
            convertImageToBase64(uri)
        } ?: ""

        Log.d(TAG, "Submitting Institute Data: nameOfInstitute=$nameOfInstitute, phoneNumber=$phoneNumber, address=$address, imageLog=$imageLog")

        if (nameOfInstitute.isNotEmpty() && phoneNumber.isNotEmpty() && address.isNotEmpty()) {
            instituteViewModel.submitInstitute(nameOfInstitute, phoneNumber, schoolId, address, targetLine, website, country, imageLog)
        } else {
            Toast.makeText(requireContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show()
        }
    }

    private fun convertImageToBase64(uri: Uri): String {
        val bitmap = binding.ivImageLog.drawable.toBitmap()
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 50, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    private fun observeViewModel() {
        instituteViewModel.instituteResponse.observe(viewLifecycleOwner) { response ->
            if (response?.status == true) {
                Toast.makeText(requireContext(), "Institute added successfully", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Failed to add institute", Toast.LENGTH_SHORT).show()
            }
        }

        instituteViewModel.errorMessage.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(requireContext(), it, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
