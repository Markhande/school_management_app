package com.example.schoolerp.DataClasses




data class AddExpenseData (
    val status : Boolean,
    val Message: String,
)