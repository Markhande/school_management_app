package com.example.schoolerp.DataClasses

class AttendanceStudentDateWise(
    val class_name: String,
    val student_names: List<String>
)
