package com.example.schoolerp.models.responses

data class ClassWithResposne(
    val status: Boolean,
    val message: String
)
