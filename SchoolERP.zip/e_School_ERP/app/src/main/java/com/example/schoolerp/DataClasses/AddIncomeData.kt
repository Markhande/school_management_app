package com.example.schoolerp.DataClasses

data class AddIncomeData (
val status : Boolean,
val Message: String,
)