package com.example.schoolerp.Fragments.Fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentFeeParticularBinding
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory

class FeeParticular : Fragment() {
    private lateinit var binding:FragmentFeeParticularBinding
    private lateinit var viewmodelAllClass: AllClassViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentFeeParticularBinding.bind(inflater.inflate(R.layout.fragment_fee_particular,null))
        setupViewModelClassNameStudent()
        getSchoolId()
        observeDataAllClass()
        return binding.root
    }
    private fun setupViewModelClassNameStudent() {
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewmodelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)
    }
    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
        }

        return schoolId ?: "defaultSchoolId"
    }

    private fun observeDataAllClass() {
        val schoolId = getSchoolId() ?: run {
            Log.e("MarksStudentAttendance", "School ID is null or blank. Cannot fetch data.")
            return
        }

        viewmodelAllClass.getClasses(schoolId.trim())
            .observe(viewLifecycleOwner, Observer { response ->
                if (response != null && response.status) {
                    Log.d(
                        "MarksStudentAttendance",
                        "Classes fetched successfully: ${response.data}"
                    )
                    val classList =
                        response.data.map { it.class_name } // Assuming class_name is a field in ClassItem
                    setupSpinner(classList)
                } else {
                    Log.e(
                        "MarksStudentAttendance",
                        "Failed to fetch class data or no data available."
                    )
                }
            })
    }
    private fun setupSpinner(classList: List<String>) {
        val spinner = binding.spStudentSelectClass // Assuming `spinnerClass` is your Spinner's ID
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item, // Default layout for Spinner items
            classList
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        // Optional: Handle Spinner selection
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedClass = classList[position]
                Log.d("SpinnerSelection", "Selected class: $selectedClass")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                Log.d("SpinnerSelection", "No class selected")
            }
        }
    }

}