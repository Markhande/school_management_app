package com.example.schoolerp.models.responses

data class EditEmpResponse(
    val status: String,
    val message: String
)
