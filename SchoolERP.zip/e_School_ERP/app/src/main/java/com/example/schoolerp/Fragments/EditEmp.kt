package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.AllEmployee
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentEditEmpBinding
import com.example.schoolerp.repository.AllEmployeesRepository
import com.example.schoolerp.viewmodel.AllEmployeesViewModel
import com.example.schoolerp.viewmodelfactory.AllEmployeesViewModelFactory


class EditEmp : Fragment() {
    private lateinit var binding: FragmentEditEmpBinding
    private lateinit var viewModel: AllEmployeesViewModel


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentEditEmpBinding.bind(inflater.inflate(R.layout.fragment_edit_emp, null))
        val apiService = RetrofitHelper.getApiService()
        val repository = AllEmployeesRepository(apiService)
        val factory = AllEmployeesViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(AllEmployeesViewModel::class.java)

        arguments?.getParcelable<AllEmployee>("employee")?.let { employee ->
            populateFields(employee)
        }

        setupListeners()
        return binding.root
    }

    private fun populateFields(employee: AllEmployee) {
        // Populate text fields
        binding.etEmployeesName.setText(employee.employee_name ?: "")
        binding.edtMobileNumber.setText(employee.mobile ?: "")
        binding.edtdateofjoining.setText(employee.date_of_joining ?: "")
        binding.edtMonthlysalary.setText(employee.monthly_salary ?: "")
        binding.edtfatherhasband.setText(employee.f_h_name ?: "")
        binding.edtedacation.setText(employee.education ?: "")
        binding.edtexperience.setText(employee.experience ?: "")
        binding.edtdateofbirth.setText(employee.date_of_birth ?: "")
        binding.edthomeaddress.setText(employee.home_address ?: "")
        binding.edtnationalId.setText(employee.national_id ?: "")

    }

    private fun setupListeners() {
        binding.btnSubmit.setOnClickListener {
            val sharedPreferences = requireActivity().getSharedPreferences(
                "onboarding_prefs",
                AppCompatActivity.MODE_PRIVATE
            )
            val schoolId = sharedPreferences.getString("school_id", "") ?: ""

            val employeeId =
                arguments?.getString("employee_id")?.toIntOrNull() ?: return@setOnClickListener

            // Ensure that the values passed are Strings (nullable)
            val editEmployeeData = mapOf(
                "employee_name" to binding.etEmployeesName.text.toString(),
                "mobile" to binding.edtMobileNumber.text.toString(),
                "employee_role" to binding.edtemployeesroll.selectedItem.toString(),
                "picture" to "Not image found", // This can be updated to a real image path later
                "date_of_joining" to binding.edtdateofjoining.text.toString(),
                "monthly_salary" to binding.edtMonthlysalary.text.toString(),
                "f_h_name" to binding.edtfatherhasband.text.toString(),
                "education" to binding.edtedacation.text.toString(),
                "gender" to binding.edtgender.selectedItem.toString(),
                "blood_group" to binding.edtbloodgroup.selectedItem.toString(),
                "experience" to binding.edtexperience.text.toString(),
                "date_of_birth" to binding.edtdateofbirth.text.toString(),
                "home_address" to binding.edthomeaddress.text.toString(),
                "national_id" to binding.edtnationalId.text.toString(),
                "school_id" to schoolId,
                "id" to employeeId.toString()  // Ensure the value is a String
            )
            Toast.makeText(requireContext(), "Employee updated successfully!", Toast.LENGTH_SHORT).show()


            Log.d("EditEmployeeRequest", "Request Data: $editEmployeeData")

            // Pass the data to the ViewModel for editing the employee
            viewModel.editEmployee(schoolId.trim(), employeeId.toString(), editEmployeeData)
        }
    }
}