package com.example.schoolerp.models.responses

class ClassWithSubjectUpdateRequest (
    val subject_name: String,
    val classes: String,
    val marks: String
)