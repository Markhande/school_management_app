package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.schoolerp.Adapter.ClassWithSubjectsAdapter
import com.example.schoolerp.DataClasses.ClassWithSubjects
import com.example.schoolerp.databinding.FragmentClassWithSubjectBinding
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.repository.getSubjectRepository
import com.example.schoolerp.viewmodel.getSubjectViewModel
import com.example.schoolerp.viewmodelfactory.getSubjectViewModelFactory

class ClassWithSubject : Fragment() {
    private lateinit var binding: FragmentClassWithSubjectBinding
    private lateinit var adapter: ClassWithSubjectsAdapter
    private var classList = mutableListOf<ClassWithSubjects>()
    private lateinit var viewModel: getSubjectViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentClassWithSubjectBinding.inflate(inflater, container, false)

        val apiService = RetrofitHelper.getApiService()
        val repository = getSubjectRepository(apiService)
        val factory = getSubjectViewModelFactory(repository , SchoolId().getSchoolId(requireContext()))
        viewModel = ViewModelProvider(this, factory).get(getSubjectViewModel::class.java)

        initView()  // Initialize the RecyclerView and adapter
        observeData()
        return binding.root
    }

    private fun initView() {
        // Initialize RecyclerView with LinearLayoutManager
        binding.recyclerclasswithsubject.layoutManager = LinearLayoutManager(requireContext())

        // Ensure that the adapter is initialized with a non-null classList
        adapter = ClassWithSubjectsAdapter(classList)

        // Set the adapter to the RecyclerView
        binding.recyclerclasswithsubject.adapter = adapter

        Log.d("ClassWithSubject", "RecyclerView and Adapter initialized.")
    }

    private fun observeData() {
        // Observe the LiveData from the ViewModel
        viewModel.classWithSubjects.observe(viewLifecycleOwner, ) { subjects ->
            Log.d("ClassWithSubject", "Subjects fetched from ViewModel: $subjects")

            // Check if the fetched data is not empty
            if (subjects.isNotEmpty()) {
                classList.clear()  // Clear any old data
                classList.addAll(subjects)  // Add the new data to the list
                adapter.notifyDataSetChanged()  // Notify the adapter to refresh the view
                Log.d("ClassWithSubject", "Data added to adapter: ${classList.size} items.")
            } else {
                Log.d("ClassWithSubject", "No subjects found.")
            }
        }
    }
}

