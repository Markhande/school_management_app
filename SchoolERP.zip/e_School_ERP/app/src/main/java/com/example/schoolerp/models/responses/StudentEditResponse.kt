package com.example.schoolerp.models.responses

data class StudentEditResponse(
    val status: String,
    val message: String
)
