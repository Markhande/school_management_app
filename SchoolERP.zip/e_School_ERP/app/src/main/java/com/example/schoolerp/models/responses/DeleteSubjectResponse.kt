package com.example.schoolerp.models.responses

data class DeleteSubjectResponse(
    val success: Boolean,
    val message: String,
)
