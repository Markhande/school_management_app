package com.example.schoolerp.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.Api.ApiService
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.databinding.FragmentChartOfAccountBinding
import com.example.schoolerp.models.responses.AllClassNameResponse
import com.example.schoolerp.models.responses.SubjectResponse
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChartOfAccount : Fragment() {

    private lateinit var binding: FragmentChartOfAccountBinding
    private lateinit var viewModelAllClassChartOfAccount: AllClassViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentChartOfAccountBinding.inflate(inflater, container, false) // Correct binding initialization
        viewModelAllClass()
        setupAllClassObserver()

        return binding.root
    }

    //  ---------------Start Calling class API to show all class data in spinner ----------
    private fun viewModelAllClass(){
        val factory = AllClassViewModelFactory(AllClassRepository())
        viewModelAllClassChartOfAccount = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)

    }
    private fun setupAllClassObserver() {
        // Observe the LiveData from ViewModel
        viewModelAllClassChartOfAccount.getClasses(SchoolId().getSchoolId(requireContext())).observe(viewLifecycleOwner) { response ->
            response?.data?.let { classList ->
                if (classList.isNotEmpty()) {
                    // Extract the class names and class IDs from the classList
                    val classNames = mutableListOf("Select Class") // Add "Select Class" as the default item
                    val classIds = mutableListOf("Select Class ID") // Add "Select Class ID" as the default item

                    // Add class names and class IDs from the class list
                    classNames.addAll(classList.map { it.class_name })
                    classIds.addAll(classList.map { it.class_id.toString() })

                    // Create adapter for the first spinner with class names (including "Select Class")
                    val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classNames)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                    // Create adapter for the second spinner with class IDs (including "Select Class ID")
                    val adapter2 = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classIds)
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                    // Set the adapters to the respective Spinners
                    binding.spinnerSelectClass.adapter = adapter
                    binding.spinnerSelectClassIDChartofAccount.adapter = adapter2

                    // Set the OnItemSelectedListener for the first Spinner
                    binding.spinnerSelectClass.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parentView: AdapterView<*>, view: View?, position: Int, id: Long) {
                            // Get the selected class name (from first spinner)
                            val selectedClassName = parentView.getItemAtPosition(position) as String

                            // Filter class IDs based on the selected class name
                            val filteredClassIds = classList.filter { it.class_name == selectedClassName }
                                .map { it.class_id }

                            // Update the second spinner with the filtered class IDs
                            val updatedAdapter2 = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, filteredClassIds)
                            updatedAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                            binding.spinnerSelectClassIDChartofAccount.adapter = updatedAdapter2
                        }

                        override fun onNothingSelected(parentView: AdapterView<*>) {
                            // Handle case when nothing is selected (optional)
                            // Set a default empty list or a default message for the second spinner
                            binding.spinnerSelectClassIDChartofAccount.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, emptyList<String>())
                        }
                    }
                } else {
                    // If no classes are found, show a Toast
                    Toast.makeText(requireContext(), "No classes found", Toast.LENGTH_SHORT).show()
                }
            } ?: run {
                // Handle case when response or data is null
                Toast.makeText(requireContext(), "Failed to load classes", Toast.LENGTH_SHORT).show()
            }
        }
    }
    //  ---------------Start Calling class API to show all class data in spinner ----------
}
