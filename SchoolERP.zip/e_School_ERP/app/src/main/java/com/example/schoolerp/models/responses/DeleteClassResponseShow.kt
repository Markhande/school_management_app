package com.example.schoolerp.models.responses

class DeleteClassResponseShow (
    val status: Boolean,
    val message: String,
)