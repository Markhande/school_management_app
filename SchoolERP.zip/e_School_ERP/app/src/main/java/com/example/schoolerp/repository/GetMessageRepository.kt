package com.example.schoolerp.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.schoolerp.Api.ApiService
import com.example.schoolerp.models.responses.GetMessageResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class GetMessageRepository(private val apiService: ApiService) {

    fun getMessages(schoolId: String): LiveData<GetMessageResponse?> {
        val result = MutableLiveData<GetMessageResponse?>()

        apiService.getMessage(schoolId).enqueue(object : Callback<GetMessageResponse> {
            override fun onResponse(
                call: Call<GetMessageResponse>,
                response: Response<GetMessageResponse>
            ) {
                if (response.isSuccessful) {
                    result.postValue(response.body())
                } else {
                    result.postValue(null)
                }
            }

            override fun onFailure(call: Call<GetMessageResponse>, t: Throwable) {
                result.postValue(null)
            }
        })

        return result
    }
}
