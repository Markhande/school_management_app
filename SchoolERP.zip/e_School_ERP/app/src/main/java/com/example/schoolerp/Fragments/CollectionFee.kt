package com.example.schoolerp.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentCollectionFeeBinding


class CollectionFee : Fragment() {
    private lateinit var binding:FragmentCollectionFeeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentCollectionFeeBinding.bind(inflater.inflate(R.layout.fragment_collection_fee,null))
        return binding.root
    }
}