package com.example.schoolerp.Fragments

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.DataClasses.AllEmployee
import com.example.schoolerp.Api.RetrofitHelper.getApiService
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentAddNewEmployeesBinding
import com.example.schoolerp.repository.EmployeeRepository
import com.example.schoolerp.util.ImageUtil
import com.example.schoolerp.viewmodel.AddNewEmployeesViewModel
import com.example.schoolerp.viewmodel.AddNewEmployeesViewModelFactory
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class AddNewEmployees : Fragment() {
    companion object {
        private const val REQUEST_CAMERA = 100
        private const val REQUEST_GALLERY = 101
        private const val REQUEST_PERMISSIONS = 100
    }
    private var currentPhotoPath: String? = null
    private lateinit var binding: FragmentAddNewEmployeesBinding
    private lateinit var viewModel: AddNewEmployeesViewModel

    private lateinit var selectedReligion :String

    private val calendar = Calendar.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAddNewEmployeesBinding.inflate(inflater, container, false)
        val sharedPreferences = requireActivity().getSharedPreferences("onboarding_prefs", AppCompatActivity.MODE_PRIVATE)
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
        }

        val repository = EmployeeRepository(getApiService())  // Retrofit instance is injected here
        val factory = AddNewEmployeesViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(AddNewEmployeesViewModel::class.java)
        // Retrieve employee data from arguments
        arguments?.getParcelable<AllEmployee>("employee")?.let { employee ->
            populateFields(employee)
        }
        initObservers()
        setupListeners()
        setupDatePickers()


        binding.edtreligion.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedReligion = parent?.getItemAtPosition(position).toString()
                if (selectedReligion == "Other") {
                    binding.edtOtherReligion.visibility = View.VISIBLE
                    selectedReligion = "Other"
                } else
                    binding.edtOtherReligion.visibility = GONE
                selectedReligion = binding.edtreligion.selectedItem.toString()
                selectedReligion = selectedReligion
//                Toast.makeText(requireContext(), "Selected", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                Toast.makeText(requireContext(), "Nothing Selected", Toast.LENGTH_SHORT).show()

            }
        }

        return binding.root


    }
    private fun populateFields(employee: AllEmployee) {
        // Populate text fields
        binding.etEmployeesName.setText(employee.employee_name ?: "")
        binding.edtMobileNumber.setText(employee.mobile ?: "")
        binding.edtdateofjoining.setText(employee.date_of_joining ?: "")
        binding.edtMonthlysalary.setText(employee.monthly_salary ?: "")
        binding.edtfatherhasband.setText(employee.f_h_name ?: "")
        binding.edtedacation.setText(employee.education ?: "")
        binding.edtexperience.setText(employee.experience ?: "")
        binding.edtdateofbirth.setText(employee.date_of_birth ?: "")
        binding.edthomeaddress.setText(employee.home_address ?: "")
        binding.edtnationalId.setText(employee.national_id ?: "")
        binding.edtemailaddres.setText(employee.email ?: "")



        // Set Spinners
       /* setSpinnerSelection(binding.edtemployeesroll, employee.employee_role)
        setSpinnerSelection(binding.edtgender, employee.gender)
        setSpinnerSelection(binding.edtreligion, employee.religion)
        setSpinnerSelection(binding.edtbloodgroup, employee.blood_group)

        // Load the image if available
        if (!employee.picture.isNullOrEmpty() && employee.picture != "Not image found") {
            val imageUri = Uri.parse(employee.picture)
            binding.imageView.setImageURI(imageUri)  // Assuming `imageView*/

    }
    private fun initObservers() {
        viewModel.apiResponse.observe(viewLifecycleOwner) { response ->
            Toast.makeText(requireContext(), response.message, Toast.LENGTH_SHORT).show()
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
           // binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    private fun setupListeners() {
        binding.btnSubmit.setOnClickListener {
            val sharedPreferences = requireActivity().getSharedPreferences("onboarding_prefs", AppCompatActivity.MODE_PRIVATE)
            val schoolId = sharedPreferences.getString("school_id", "")

            val employeeData = mapOf(
                "employee_name" to binding.etEmployeesName.text.toString(),
                "number" to binding.edtMobileNumber.text.toString(),
                "employee_role" to binding.edtemployeesroll.selectedItem.toString(),
                "picture" to "Not image found",
                "date_of_joining" to binding.edtdateofjoining.text.toString(),
                "monthly_salary" to binding.edtMonthlysalary.text.toString(),
                "f_h_name" to binding.edtfatherhasband.text.toString(),
                "education" to binding.edtedacation.text.toString(),
                "gender" to binding.edtgender.selectedItem.toString(),
                "religion" to selectedReligion,
                "blood_group" to binding.edtbloodgroup.selectedItem.toString(),
                "experience" to binding.edtexperience.text.toString(),
                "date_of_birth" to binding.edtdateofbirth.text.toString(),
                "home_address" to binding.edthomeaddress.text.toString(),
                "email" to binding.edtemailaddres.text.toString(),
                "national_id" to binding.edtnationalId.text.toString(),
                "username" to binding.edtMobileNumber.text.toString(),
                "password" to binding.etEmployeesName.text.toString().substring(0,3)+binding.edtMobileNumber.text.toString().substring(6),
                "status" to "Active",
                "school_id" to SchoolId().getSchoolId(requireContext())
            )
            Log.d("AddClassRequest", "Request Data: $employeeData")

            Log.d("AddClassRequest", "Request Data: $employeeData")
            viewModel.addNewEmployee(employeeData)
        }

    binding.edtChooseFile.setOnClickListener {
            showImagePickerDialog()
        }
    }
       private fun setupDatePickers() {
        binding.edtdateofjoining.setOnClickListener {
            showDatePickerDialog { date -> binding.edtdateofjoining.setText(date) }
        }

        binding.edtdateofbirth.setOnClickListener {
            showDatePickerDialog { date -> binding.edtdateofbirth.setText(date) }
        }
    }

    private fun showDatePickerDialog(onDateSet: (String) -> Unit) {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(calendar.apply {
                    set(Calendar.YEAR, selectedYear)
                    set(Calendar.MONTH, selectedMonth)
                    set(Calendar.DAY_OF_MONTH, selectedDay)
                }.time)

            onDateSet(formattedDate)
        }, year, month, day).show()
    }

    private fun showImagePickerDialog() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        val builder = android.app.AlertDialog.Builder(requireContext())
        builder.setTitle("Choose an action")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> openCamera()
                1 -> openGallery()
            }
        }
        builder.show()
    }

    private fun checkPermissions(onPermissionsGranted: () -> Unit) {
        val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)

        val permissionsNeeded = permissions.filter {
            ContextCompat.checkSelfPermission(requireContext(), it) != PackageManager.PERMISSION_GRANTED
        }

        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(requireActivity(), permissionsNeeded.toTypedArray(), REQUEST_PERMISSIONS)
        } else {
            onPermissionsGranted()
        }
    }

    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun openCamera() {
        checkPermissions {
            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            takePictureIntent.resolveActivity(requireContext().packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    null
                }

                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(requireContext(), "com.example.schoolerp.fileprovider", it)
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_CAMERA)
                }
            }
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_GALLERY)
    }
    private fun getRealPathFromURI(uri: Uri): String {
        var result: String? = null
        val cursor = requireContext().contentResolver.query(uri, null, null, null, null)
        if (cursor != null) {
            cursor.moveToFirst()
            val idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
            result = cursor.getString(idx)
            cursor.close()
        }
        return result ?: uri.path.toString()  // Fallback to URI path if unable to resolve
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    // Set the image path in TextView
                    binding.tvNoFilesChosen.text = currentPhotoPath

                    // Convert the image to Base64 using the utility method
                   // val base64Image = currentPhotoPath?.let { ImageUtil.encodeImageToBase64(it) }

/*
                    if (base64Image != null) {
                        Log.d("ImageBase64", "Base64 String: $base64Image")
                        // You can now use base64Image for further operations, e.g., sending it to the server
                    } else {
                        Log.e("ImageBase64", "Failed to convert image to Base64")
                    }
*/
                }
                REQUEST_GALLERY -> {
                    data?.data?.let { uri ->
                        val filePath = getRealPathFromURI(uri) // Convert URI to file path

                        // Set the image path in TextView
                        binding.tvNoFilesChosen.text = filePath

                        // Convert the image to Base64 using the utility method
                       // val base64Image = ImageUtil.encodeImageToBase64(filePath)

                      /*  if (base64Image != null) {
                            Log.d("ImageBase64", "Base64 String: $base64Image")
                            // You can now use base64Image for further operations, e.g., sending it to the server
                        } else {
                            Log.e("ImageBase64", "Failed to convert image to Base64")
                        }*/
                    }
                }
            }
        }
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera() // Call openCamera again to continue the flow
            } else {
                Toast.makeText(requireContext(), "Camera permission is required to take photos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
