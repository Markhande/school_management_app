package com.example.schoolerp.DataClasses

class StudentIDData
    (
        val name: String,
        val studentId: String,
        val dob: String,
        val address: String
    )


