// AllClass.kt
package com.example.schoolerp.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.schoolerp.DataClasses.ClassItem
import com.example.schoolerp.R
import com.example.schoolerp.adapters.AllClassAdapter
import com.example.schoolerp.databinding.FragmentAllClassBinding
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory

class AllClass : Fragment() {
    private lateinit var binding: FragmentAllClassBinding
    private lateinit var allClassAdapter: AllClassAdapter
    private val classList = mutableListOf<ClassItem>()
    private lateinit var viewModel: AllClassViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAllClassBinding.inflate(inflater, container, false)

        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)

        initRecyclerView()
        observeData()
        return binding.root
    }

    private fun initRecyclerView() {
        allClassAdapter = AllClassAdapter(classList, { classItem ->
            // Handle the edit click to navigate to the edit fragment and pass data
            navigateToEditFragment(classItem)
        }, { classId, schoolId ->
            // Handle the delete click
            deleteClass(schoolId, classId)
        })

        binding.recyclerViewClasses.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewClasses.adapter = allClassAdapter
    }

    private fun observeData() {
        val schoolId = getSchoolId()
        viewModel.getClasses(schoolId).observe(viewLifecycleOwner) { response ->
            response?.data?.let {
                classList.clear()
                classList.addAll(it)
                allClassAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun getSchoolId(): String {
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs", AppCompatActivity.MODE_PRIVATE
        )
        return sharedPreferences.getString("school_id", "").orEmpty()
    }

    private fun navigateToEditFragment(classItem: ClassItem) {
        val bundle = Bundle().apply {
            putSerializable("class_data", classItem) // Pass classItem data to the edit fragment
        }

        val fragmentB = UpdateClass().apply {
            arguments = bundle
        }

        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragmentB)
            .addToBackStack(null) // Optional: add fragment to backstack
            .commit()
    }

    private fun deleteClass(schoolId: String, classId: String) {
        // Show confirmation dialog
        AlertDialog.Builder(requireContext())
            .setTitle("Confirm Deletion")
            .setMessage("Are you sure you want to delete this class?")
            .setPositiveButton("Yes") { dialog, _ ->
                // Proceed with deletion if the user confirms
                viewModel.deleteClass(schoolId, classId).observe(viewLifecycleOwner) { isSuccess ->
                    if (isSuccess) {
                        val classItem = classList.find { it.class_id == classId }
                        classItem?.let {
                            classList.remove(it)
                            allClassAdapter.notifyDataSetChanged()
                            Toast.makeText(requireContext(), "Class deleted successfully", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(requireContext(), "Failed to delete the class. It may already exist.", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ ->
                // Do nothing if the user cancels
                dialog.dismiss()
            }
            .create()
            .show()
    }

}






