package com.example.schoolerp.models.requests

data class LoginRequest(
    val employee_id: String,
    val password: String
)
