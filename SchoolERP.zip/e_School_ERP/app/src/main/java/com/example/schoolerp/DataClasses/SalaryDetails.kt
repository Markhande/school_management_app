package com.example.schoolerp.DataClasses

data class SalaryDetails(
    val salary_month: String?,
    val salary_amount: String?,
    val date_of_pay: String?,
    val bouns: String?,
    val deduction: String?,
    val employee_id: String?,
    val employee_name: String?,
    val employee_role: String?,
    val f_h_name: String?,
    val net_paid: String?,
    val id: Int?
)