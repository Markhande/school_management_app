package com.example.schoolerp.models.requests

data class Subject(
    val subject_name: String
)
