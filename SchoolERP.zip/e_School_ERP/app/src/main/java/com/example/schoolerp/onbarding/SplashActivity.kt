// SplashActivity.kt
package com.example.schoolerp.onboarding

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.onboardingschool.LoginPage
import com.example.schoolerp.Activities.MainActivity
import com.example.schoolerp.R
import com.example.schoolerp.databinding.ActivitySplashBinding
import com.example.schoolerp.onbarding.Onboarding

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("onboarding_prefs", MODE_PRIVATE)

        Handler(Looper.getMainLooper()).postDelayed({
            when {
                !sharedPreferences.getBoolean("onboarding_completed", false) -> {
                    navigateToOnboarding()
                }
                !sharedPreferences.getBoolean("is_logged_in", false) -> {
                    navigateToLoginPage()
                }
                else -> {
                    navigateToMainActivity()
                }
            }
        }, 1500)
    }

    private fun navigateToOnboarding() {
        startActivity(Intent(this, Onboarding::class.java))
        finish()
    }

    private fun navigateToLoginPage() {
        startActivity(Intent(this, LoginPage::class.java))
        finish()
    }

    private fun navigateToMainActivity() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
