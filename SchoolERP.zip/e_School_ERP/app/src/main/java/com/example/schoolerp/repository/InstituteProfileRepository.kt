package com.example.schoolerp.repository

import android.util.Log
import com.example.schoolerp.Api.ApiService
import com.example.schoolerp.DataClasses.InstituteProfileDataClass
import retrofit2.Response

class InstituteProfileRepository(private val apiService: ApiService) {

    suspend fun submitInstitute(
        nameOfInstitute: String,
        phoneNumber: String,
        schoolId: String,
        address: String,
        targetLine: String,
        website: String?,
        country: String?,
        imageLog: String,
    ): Response<InstituteProfileDataClass> {
        // Create a map to hold the field data
        val fields = mapOf(
            "school_id" to schoolId,
            "name_of_institute" to nameOfInstitute,
            "phone_number" to phoneNumber,
            "address" to address,
            "target_line" to targetLine,
            "website" to website,
            "country" to country,
            "institute_logo" to imageLog
        )

        // Pass the map to the API service method
        Log.d("InstituteProfileRepository", "Submitting institute data: $fields")
        return apiService.submitInstitute(fields)
    }
}