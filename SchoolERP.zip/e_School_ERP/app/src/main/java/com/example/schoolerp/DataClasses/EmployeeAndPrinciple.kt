package com.example.schoolerp.DataClasses

class EmployeeAndPrinciple (
    val id: String,
    val employee_name: String,
    val employee_role: String,
    val school_id: String
)