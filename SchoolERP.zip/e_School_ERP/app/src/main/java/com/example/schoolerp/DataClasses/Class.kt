package com.example.schoolerp.DataClasses

data class Class(
    val id: String,
    val class_name: String,
    val tution_fees: String,
    val class_teacher: String,
    val school_id: String
)