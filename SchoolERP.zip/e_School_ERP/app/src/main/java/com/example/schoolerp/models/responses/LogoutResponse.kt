package com.example.schoolerp.models.responses

data class LogoutResponse(
    val status: Boolean,
    val message: String
)


