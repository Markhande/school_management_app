package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentNewClassBinding
import com.example.schoolerp.models.responses.AllClassNameResponse
import com.example.schoolerp.models.responses.TeacherNameResponse
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.repository.ClassRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodel.ClassViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import com.example.schoolerp.viewmodelfactory.ClassViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class NewClass : Fragment() {
    private lateinit var binding: FragmentNewClassBinding
    private var teacherName: String = ""
    private val stringList: ArrayList<String> = arrayListOf()
    private lateinit var viewModelAllClass:AllClassViewModel

    // List to store fetched class names from the API
    private val classNamesList = mutableListOf<String>()

    // Initialize ViewModel
    private val viewModel: ClassViewModel by viewModels {
        ClassViewModelFactory(ClassRepository())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentNewClassBinding.inflate(inflater, container, false)

        // Set up submit button click listener
        binding.btnCreateClas.setOnClickListener {
            if(!binding.etClassTeacher.selectedItem.toString().equals("Select Teacher")){
                fetchClassNames(SchoolId().getSchoolId(requireContext()))
                stringList.addAll(classNamesList)
                submitClassData()
            }else{
                Toast.makeText(requireContext(), "Please select a teacher", Toast.LENGTH_SHORT).show()
            }

        }


        fetchTeacherNames(SchoolId().getSchoolId(requireContext()))

        setupviewmodel()

        return binding.root
    }
    private fun setupviewmodel(){
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewModelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)


    }

    private fun submitClassData() {
        // Collect form data from input fields
        val className = binding.spClass.text.toString().trim()  // Ensure we trim whitespace
        val tuitionFees = binding.edtTuitionfees.text.toString().trim()
        val selectedTeacher = binding.etClassTeacher.selectedItem.toString()  // Get the selected teacher's name from the Spinner

        // Validate input data

        if (className.isEmpty() || tuitionFees.isEmpty() || selectedTeacher.isEmpty()) {
            // Show an error message for empty fields
            binding.edtTuitionfees.error = "Please enter tuition fees"
            Toast.makeText(activity, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Check if the class name already exists in the list of class names fetched from API
//        if (classNamesList.contains(className)) {
//            Toast.makeText(requireContext(), "Class already created", Toast.LENGTH_SHORT).show()
//            return
//        }

        // Disable the button to prevent multiple clicks
        binding.btnCreateClas.isEnabled = false

        // Prepare data to be sent to the ViewModel
        val classData = HashMap<String, String>().apply {
            put("class_name", className)
            put("tution_fees", tuitionFees)
            put("class_teacher", selectedTeacher)  // Use the selected teacher from Spinner
            put("school_id", SchoolId().getSchoolId(requireContext()))  // Example School ID, replace as needed
        }

//      Method not allowed
        // Observe LiveData from ViewModel for class creation
        viewModel.addClass(classData).observe(viewLifecycleOwner) { apiResponse ->
            val message = apiResponse?.message ?: "Failed to add class"
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()

            // Re-enable the button after the operation completes
            binding.btnCreateClas.isEnabled = true
        }

    }

    private fun fetchTeacherNames(SchoolID: String) {
        RetrofitHelper.getApiService().getEmployeeData(SchoolID).enqueue(object : Callback<TeacherNameResponse> {
            override fun onResponse(call: Call<TeacherNameResponse>, response: Response<TeacherNameResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val employees = response.body()!!.data
                    val roles = mutableListOf<String>()
                    roles.add("Select Teacher")

                    // Extracting employee names and populating the roles list
                    for (employee in employees) {
                        employee.employeeName?.let {
                            roles.add(it)  // Add employee names to the list
                        }
                    }

                    if (roles.isEmpty()) {
                        Toast.makeText(requireContext(), "No employee names available", Toast.LENGTH_SHORT).show()
                    }

                    // Set up the adapter to populate the Teacher Spinner
                    val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, roles)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.etClassTeacher.adapter = adapter

                } else {
                    Toast.makeText(requireContext(), "Failed to load data: ${response.message()}", Toast.LENGTH_SHORT).show()
                    Log.e("NewClass", "Error: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<TeacherNameResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("NewClass", "Network error: ${t.message}")
            }
        })
    }

    private fun fetchClassNames(schoolId: String) {
        RetrofitHelper.getApiService().getClassList(schoolId).enqueue(object : Callback<AllClassNameResponse> {
            override fun onResponse(call: Call<AllClassNameResponse>, response: Response<AllClassNameResponse>) {
                if (response.isSuccessful) {
                    val allClassNameResponse = response.body()

                    if (allClassNameResponse != null && allClassNameResponse.status) {
                        // Extract class names and store them in the list
                        val classNames = allClassNameResponse.classes.map { it.class_name }

                        // Update the classNamesList
                        classNamesList.clear()
                        classNamesList.addAll(classNames)

                        // Set up the adapter for the class names Spinner
                        val adapter = ArrayAdapter(
                            requireContext(),
                            android.R.layout.simple_spinner_item,
                            classNames
                        )
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        binding.sampleSpinner.adapter = adapter
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to load class names", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<AllClassNameResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("NewClass", "Network error: ${t.message}")
            }
        })
    }
}

