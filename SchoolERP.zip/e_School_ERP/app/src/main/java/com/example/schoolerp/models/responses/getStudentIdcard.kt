package com.example.schoolerp.models.responses

data class getStudentIdcardResponse(
    val status: Boolean,
    val message: String,
    val StudentIdCardRespones: List<StudentIdCardRespones>
)

data class StudentIdCardRespones(
    val st_name: String,
    val id: String,
    val dt_of_birth: String?,
    val st_class: String,
    val school_name: String,
    val address: String
)


