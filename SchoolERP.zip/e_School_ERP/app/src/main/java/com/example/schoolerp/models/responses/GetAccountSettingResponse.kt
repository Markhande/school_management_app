package com.example.schoolerp.models.responses

data class  GetAccountSettingResponse(
    val status: Boolean,
    val message: String,
    val data: List<GetAccountSetting>
)
