package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.example.schoolerp.Adapter.AllEmployeeAdapter
import com.example.schoolerp.DataClasses.AllEmployee
import com.example.schoolerp.R
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.databinding.FragmentAllEmployeesBinding
import com.example.schoolerp.repository.AllEmployeesRepository
import com.example.schoolerp.viewmodel.AllEmployeesViewModel
import com.example.schoolerp.viewmodelfactory.AllEmployeesViewModelFactory

class AllEmployees : Fragment(), AllEmployeeAdapter.OnEmployeeActionListener {
    private lateinit var binding: FragmentAllEmployeesBinding
    private lateinit var employeeAdapter: AllEmployeeAdapter
    private val employeeList = mutableListOf<AllEmployee>()

    private lateinit var viewModel: AllEmployeesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAllEmployeesBinding.bind(
            inflater.inflate(
                R.layout.fragment_all_employees,
                null
            )
        )
        val apiService = RetrofitHelper.getApiService()
        val repository = AllEmployeesRepository(apiService)
        val factory = AllEmployeesViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(AllEmployeesViewModel::class.java)


        initView()
        observeData()
        getSchoolId()
        return binding.root
    }
    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
            // Optionally, return a default value if not found
        }

        return schoolId ?: "defaultSchoolId" // Return the schoolId or a default value
    }


    private fun initView() {
        val gridLayoutManager = GridLayoutManager(activity, 2)
        binding.recyclerViewAllEmployees.layoutManager = gridLayoutManager

        // Pass 'this' as the listener for the adapter
        employeeAdapter = AllEmployeeAdapter(employeeList, this)
        binding.recyclerViewAllEmployees.adapter = employeeAdapter


       /* binding.searchViewEmployees.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                // Optional: Hide keyboard or add additional action here
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                Log.d("SearchView", "Search query changed: $newText")
                employeeAdapter.filter(newText.orEmpty())
                return true
            }
        })*/

    }

    private fun observeData() {
        val schoolId = getSchoolId()  // Get the dynamic school_id

        viewModel.getAllEmployees(schoolId.trim()).observe(viewLifecycleOwner) { response ->
            employeeAdapter.updateEmp(employeeList)
            if (response != null) {

                // Check if response.employee is null or empty
                if (response.employee != null && response.employee.isNotEmpty()) {
                    employeeList.clear()
                    for (employee in response.employee) {
                        employeeList.add(
                            AllEmployee(
                                name = employee.employee_name,
                                title = employee.employee_role,
                                img = R.drawable.teacherprofile,
                                id = employee.id,
                                employee_name = employee.employee_name,
                                mobile = employee.mobile ?: "N/A",  // Default value if mobile is null
                                employee_role = employee.employee_role,
                                picture = employee.picture ?: "default_picture_url_or_path", // Default for picture
                                date_of_joining = employee.date_of_joining ?: "N/A", // Default for date_of_joining
                                monthly_salary = employee.monthly_salary ?: "0",  // Default for salary if null
                                f_h_name = employee.f_h_name ?: "Unknown", // Default for f_h_name if null
                                national_id = employee.national_id ?: "N/A",
                                education = employee.education ?: "N/A",
                                gender = employee.gender ?: "N/A",
                                religion = employee.religion ?: "N/A",
                                blood_group = employee.blood_group ?: "N/A",
                                experience = employee.experience ?: "N/A",
                                date_of_birth = employee.date_of_birth ?: "N/A",
                                home_address = employee.home_address ?: "N/A",
                                email = employee.email ?: "N/A",
                                username = employee.username ?: "N/A",
                                password = employee.password ?: "N/A",
                                status = employee.status ?: "N/A",
                                school_id = employee.school_id ?: "N/A",
                                created_at = employee.created_at ?: "N/A"
                            )
                        )

                    }
                    employeeAdapter.notifyDataSetChanged()
                   // employeeAdapter.updateEmp(employeeList)
                   // employeeAdapter.updateEmp(employeeList)


                } else {
                    // Handle the case when employee list is empty or null
                    Toast.makeText(requireContext(), "No employees found", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Error fetching employee data", Toast.LENGTH_SHORT).show()
            }
        }
    }


    /* override fun onEditEmployee(employee: AddEmployeeRequest) {
        val bundle = Bundle().apply {
            putParcelable("employee", employee)
        }

        val addStudentFragment = AddStudent().apply {
            arguments = bundle
        }
        (context as AppCompatActivity).supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, addStudentFragment)
            .addToBackStack(null)
            .commit()
    }*/

    /*  override fun onEditEmployee(employee: Employee) {
        val bundle = Bundle().apply {
            putParcelable("employee", employee)
        }

        val AllEmployeesFragment = AddStudent().apply {
            arguments = bundle
        }
        (context as AppCompatActivity).supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, AllEmployeesFragment)
            .addToBackStack(null)
            .commit()
    }*/

    /* override fun onDeleteEmployee(employee: Employee.CREATOR) {
        TODO("Not yet implemented")
    }
*/
    override fun onEditEmployee(employee: AllEmployee) {
        val schoolId = employee.school_id.trim()
        val employeeId = employee.id

        val bundle = Bundle().apply {
            putParcelable("employee", employee) // Pass the employee data as arguments
            putString("school_id", schoolId) // Pass schoolId
            putString("employee_id", employeeId) // Pass employeeId
        }

        val editEmpFragment = EditEmp().apply {
            arguments = bundle
        }

        (context as AppCompatActivity).supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, editEmpFragment)
            .addToBackStack(null)
            .commit()
    }


    override fun onDeleteEmployee(employee: AllEmployee, position: Int) {
        val schoolId = employee.school_id.trim()
        val employeeId = employee.id
        val employeeName = employee.name

        AlertDialog.Builder(requireContext())
            .setTitle("Delete : $employeeName") // Use the employee's name in the title
            .setMessage("Are you sure you want to delete this employee?")
            .setPositiveButton("Yes") { dialog, which ->
                Log.d(
                    "DeleteEmployee",
                    "Attempting to delete employee with ID: $employeeId, School ID: $schoolId"
                )

                viewModel.deleteEmployee(schoolId, employeeId)
                    .observe(viewLifecycleOwner) { response ->
                        if (response != null) {
                            if (response.status == "success") {
                                employeeAdapter.removeEmployee(position)
                                Toast.makeText(
                                    requireContext(),
                                    response.message,
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    requireContext(),
                                    response.message,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            Toast.makeText(
                                requireContext(),
                                "Failed to delete employee",
                                Toast.LENGTH_SHORT
                            )
                                .show()
                        }
                    }
            }
            .setNegativeButton("No") { dialog, which ->
                dialog.dismiss()
            }
            .show()
    }
}