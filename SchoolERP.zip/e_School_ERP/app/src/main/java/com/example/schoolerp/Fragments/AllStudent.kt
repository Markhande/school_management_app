package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.example.schoolerp.Adapter.AllStudentAdapter
import com.example.schoolerp.DataClasses.Student
import com.example.schoolerp.Fragments.Fragment.AddStudent
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentAllStudentBinding
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.repository.getStudentRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodel.getStudentViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import com.example.schoolerp.viewmodelfactory.getStudentViewModelFactory

class AllStudent : Fragment(), AllStudentAdapter.OnItemClickListener {

    private lateinit var binding: FragmentAllStudentBinding
    private lateinit var allStudentAdapter: AllStudentAdapter

    private lateinit var viewModel: getStudentViewModel
    private lateinit var viewModelAllClass: AllClassViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAllStudentBinding.inflate(inflater, container, false)
        setupViewModel()
        setupRecyclerView()
        fetchData()
        viewModelAllClass()
        return binding.root
    }

    private fun viewModelAllClass() {
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewModelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)

    }


    private fun setupViewModel() {
        val apiService = RetrofitHelper.getApiService()
        val repository = getStudentRepository(apiService)
        val factory = getStudentViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(getStudentViewModel::class.java)

        viewModel.students.observe(viewLifecycleOwner, { students ->
            allStudentAdapter.updateStudents(students)
        })

        viewModel.errorMessage.observe(viewLifecycleOwner, { message ->
            // Handle error message
        })
    }

    private fun setupRecyclerView() {
        allStudentAdapter = AllStudentAdapter(mutableListOf(), this)
        binding.recyclerViewAllStudent.layoutManager = GridLayoutManager(activity, 2)
        binding.recyclerViewAllStudent.adapter = allStudentAdapter

        binding.searchViewSudent.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                // Optional: Hide keyboard or add additional action here
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                Log.d("SearchView", "Search query changed: $newText")
                allStudentAdapter.filter(newText.orEmpty())
                return true
            }
        })

    }

    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
        }

        return schoolId ?: "defaultSchoolId" // Return the schoolId or a default value
    }

    private fun fetchData() {
        val schoolId = getSchoolId() // Assuming you have a method to get school ID
        viewModel.fetchStudentsBySchoolId(schoolId.trim()) // Fetch employees and observe the count
    }


    override fun onDeleteClick(student: Student, position: Int) {
        val schoolId = student.school_id.trim()
        val studentId = student.id

        // Display a confirmation dialog before deletion
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Student")
            .setMessage("Are you sure you want to delete ${student.st_name}?")
            .setPositiveButton("Yes") { dialog, _ ->
                // Log both schoolId and studentId before proceeding
                Log.d(
                    "onDeleteClick",
                    "Attempting to delete student with School ID: $schoolId and Student ID: $studentId"
                )

                // Proceed with deletion
                viewModel.deleteStudent(schoolId, studentId)

                viewModel.deleteStatus.observe(viewLifecycleOwner) { success ->
                    if (success) {
                        allStudentAdapter.removeStudent(position)
                        Log.d("onDeleteClick", "Student deleted successfully at position $position")
                    } else {
                        Log.e("onDeleteClick", "Failed to delete student")
                        Toast.makeText(context, "Failed to delete student", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ ->
                // Dismiss dialog if deletion is canceled
                dialog.dismiss()
            }
            .show()
    }


    override fun onEditClick(student: Student) {
        val StudentId = student.id

        val bundle = Bundle().apply {
            putParcelable("student", student)
            putString("Student_id", StudentId) // Pass employeeId

        }

        val EditStudentFragment = EditStudent().apply {
            arguments = bundle
        }
        (context as AppCompatActivity).supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, EditStudentFragment)
            .addToBackStack(null)
            .commit()
    }


    override fun onSearchClick(student: Student) {

        val bundle = Bundle().apply {
            putParcelable("student", student)

        }

        val SerchStudentFragment = SearchStudent().apply {
            arguments = bundle
        }
        (context as AppCompatActivity).supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, SerchStudentFragment)
            .addToBackStack(null)
            .commit()
    }
}
