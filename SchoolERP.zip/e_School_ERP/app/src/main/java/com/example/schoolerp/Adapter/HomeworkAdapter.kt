package com.example.schoolerp.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolerp.DataClasses.Homework
import com.example.schoolerp.R

class HomeworkAdapter(
    private val homeworkList: List<Homework>,
    private val onEditClick: (Homework) -> Unit,
    private val onDeleteClick: (Homework) -> Unit
) : RecyclerView.Adapter<HomeworkAdapter.HomeworkViewHolder>() {

    class HomeworkViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val teacher = itemView.findViewById<TextView>(R.id.tvTeacher)
        val className = itemView.findViewById<TextView>(R.id.tvClass)
        val date = itemView.findViewById<TextView>(R.id.tvDate)
        val subject = itemView.findViewById<TextView>(R.id.tvSubject)
        val description = itemView.findViewById<TextView>(R.id.tvDescription)
        val detail = itemView.findViewById<TextView>(R.id.tvDetail)
        val editIcon = itemView.findViewById<ImageView>(R.id.ivEdit)
        val deleteIcon = itemView.findViewById<ImageView>(R.id.ivDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeworkViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_homework, parent, false)
        return HomeworkViewHolder(view)
    }

    override fun onBindViewHolder(holder: HomeworkViewHolder, position: Int) {
        val homework = homeworkList[position]

        // Binding the new fields to the views
        holder.teacher.text = "Teacher: ${homework.set_by}"
        holder.className.text = "Class: ${homework.classes}"
        holder.date.text = "Date: ${homework.homework_date}"
        holder.subject.text = "Subject: ${homework.subject}"
        holder.detail.text = "homework: ${homework.homework_detail}"

        holder.editIcon.setOnClickListener {
            onEditClick(homework)
        }

        holder.deleteIcon.setOnClickListener {
            onDeleteClick(homework)
        }
    }

    override fun getItemCount(): Int {
        return homeworkList.size
    }
}
