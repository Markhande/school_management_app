package com.example.schoolerp.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolerp.DataClasses.AllEmployee
import com.example.schoolerp.databinding.ItemAllemployeeBinding


class AllEmployeeAdapter(
    private val employeeList: MutableList<AllEmployee>, // Use MutableList here
    private val listener: OnEmployeeActionListener
) : RecyclerView.Adapter<AllEmployeeAdapter.EmployeeViewHolder>() {
    private var filteredList: MutableList<AllEmployee> = mutableListOf()

    init {
        // Initially, filteredList is a copy of employeeList
        filteredList.addAll(employeeList)
    }


    interface OnEmployeeActionListener {
        fun onEditEmployee(employee: AllEmployee)
        fun onDeleteEmployee(employee: AllEmployee, position: Int)
    }

    inner class EmployeeViewHolder(private val binding: ItemAllemployeeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(employee: AllEmployee) {
            binding.imageViewEmployee.setImageResource(employee.img)
            binding.tvEmployeeName.text = employee.name
            binding.tvEmployeeTitle.text = employee.title

            if (employee.gender == "Female") {
                binding.imageViewEmployee.setImageResource(com.example.schoolerp.R.drawable.femaleemployee)
            }
            else {
               binding.gender.text = employee.gender
                binding.imageViewEmployee.setImageResource(com.example.schoolerp.R.drawable.maleemployee)
            }

            binding.iconEdit.setOnClickListener {
                listener.onEditEmployee(employee)
            }
            binding.iconDelete.setOnClickListener {
                listener.onDeleteEmployee(employee, adapterPosition) // Use adapterPosition
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmployeeViewHolder {
        val binding = ItemAllemployeeBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return EmployeeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EmployeeViewHolder, position: Int) {
        val employee = employeeList[position]
        holder.bind(employee)
    }

    override fun getItemCount(): Int {
        return employeeList.size
    }

    fun updateEmp(newEMP: List<AllEmployee>) {
        employeeList.clear()
        employeeList.addAll(newEMP)
        filter("")

    }


    fun filter(query: String) {
        filteredList.clear()
        if (query.isEmpty()) {
            filteredList.addAll(employeeList)
        } else {
            filteredList.addAll(employeeList.filter {
                it.employee_name.contains(query, ignoreCase = true)
            })
        }
        notifyDataSetChanged() // Refresh the adapter after filtering

        //  Log.d("SearchFilter", "Query: \"$query\", Filtered size: ${filteredList.size}")
    }


    // Method to remove an employee by position
    /*fun removeEmployee(position: Int) {
        if (position in filteredList.indices) {
            val employeeToRemove = filteredList[position]
            employeeList.remove(employeeToRemove) // Remove from the original list
            filteredList.removeAt(position) // Remove from the filtered list
            notifyItemRemoved(position) // Notify the adapter about item removal
            notifyItemRangeChanged(position, filteredList.size) // Update positions
        }
    }
}*/
fun removeEmployee(position: Int) {
        if (position in employeeList.indices) {
            employeeList.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, employeeList.size)
        }
    }
}
