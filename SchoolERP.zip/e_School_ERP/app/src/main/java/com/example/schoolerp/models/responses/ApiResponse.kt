package com.example.schoolerp.models.responses

data class ApiResponse(
    val message: String,
)