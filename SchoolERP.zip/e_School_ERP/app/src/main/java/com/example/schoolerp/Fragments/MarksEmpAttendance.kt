package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.schoolerp.Adapter.AddEmpAttandanceAdapter
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.AllEmployee
import com.example.schoolerp.databinding.FragmentMarksEmpAttendanceBinding
import com.example.schoolerp.repository.AllEmployeesRepository
import com.example.schoolerp.repository.EmployeeAttendanceRepository
import com.example.schoolerp.viewmodel.AllEmployeesViewModel
import com.example.schoolerp.viewmodel.EmployeeAttendanceViewModel
import com.example.schoolerp.viewmodelfactory.AllEmployeesViewModelFactory
import com.example.schoolerp.viewmodelfactory.EmployeeAttendanceViewModelFactory
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class MarksEmpAttendance : Fragment() {

    private lateinit var binding: FragmentMarksEmpAttendanceBinding
    private lateinit var viewModelAllEmp: AllEmployeesViewModel
    private lateinit var adapter: AddEmpAttandanceAdapter
    private lateinit var attendanceViewModel: EmployeeAttendanceViewModel
    private val attendanceMap = mutableMapOf<String, String>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMarksEmpAttendanceBinding.inflate(inflater, container, false)

        setupViewModel()
        setupRecyclerView()
        observeViewModel()
        fetchEmployees()
        setupViewModelAddEmp()
        btnEmpSetUpListners()

        return binding.root
    }

    private fun setupRecyclerView() {
        adapter = AddEmpAttandanceAdapter(mutableListOf()) { employeeId, status ->
            attendanceMap[employeeId] = status // Update attendance map with employee status
            Log.d("AttendanceMap", "Updated attendance for employee $employeeId: $status")
        }
        binding.EmpRecylerView.adapter = adapter
        binding.EmpRecylerView.layoutManager = LinearLayoutManager(requireContext())
    }

    private fun setupViewModel() {
        val apiService = RetrofitHelper.getApiService()
        val repository = AllEmployeesRepository(apiService)
        val factory = AllEmployeesViewModelFactory(repository)
        viewModelAllEmp = ViewModelProvider(this, factory).get(AllEmployeesViewModel::class.java)
    }

    private fun observeViewModel() {
        viewModelAllEmp.employeeResponse.observe(viewLifecycleOwner) { response ->
            val employees = response?.employee?.toMutableList() ?: mutableListOf()
            Log.d("EmployeesData", "Employees retrieved: ${employees.size}")
            if (employees.isNotEmpty()) {
                adapter.updateData(employees) // Update adapter data
            }
        }
    }

    private fun fetchEmployees() {
        val schoolId = getSchoolId()
        viewModelAllEmp.getAllEmployees(schoolId.trim())
    }

    private fun getSchoolId(): String {
        val sharedPreferences = requireActivity().getSharedPreferences("onboarding_prefs", 0)
        return sharedPreferences.getString("school_id", "defaultSchoolId") ?: "defaultSchoolId"
    }

    private fun setupViewModelAddEmp() {
        val apiService = RetrofitHelper.getApiService()
        val repository = EmployeeAttendanceRepository(apiService)
        val factory = EmployeeAttendanceViewModelFactory(repository)
        attendanceViewModel =
            ViewModelProvider(this, factory).get(EmployeeAttendanceViewModel::class.java)
    }

    private fun observeAttendanceResponse() {
        attendanceViewModel.attendanceResponse.observe(viewLifecycleOwner) { response ->
            if (response.status) {
                Toast.makeText(requireContext(), response.message, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Error: ${response.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        }

        attendanceViewModel.error.observe(viewLifecycleOwner) { error ->
            Toast.makeText(requireContext(), error, Toast.LENGTH_SHORT).show()
        }
    }

    private fun btnEmpSetUpListners() {
        binding.btnSubmit.setOnClickListener {
            // Ensure all employees have an attendance status, defaulting to "A" if not marked
            val attendanceList = mutableListOf<Map<String, String>>()

            // Add marked attendance from the map
            attendanceMap.forEach { (employeeName, status) ->
                val attendanceData = mapOf(
                    "employee_name" to employeeName,
                    "status" to status,
                    "date" to (getCurrentDate()),
                    "school_id" to getSchoolId()
                )
                attendanceList.add(attendanceData)
                Log.d("Attendance", "Added school_id for employee $employeeName: ${getSchoolId()}")

            }

            // Add employees not marked in the attendance map with default "A" status
            adapter.getEmployeeNames().forEach { employeeName ->
                if (!attendanceMap.contains(employeeName)) {
                    val attendanceData = mapOf(
                        "employee_name" to employeeName,
                        "status" to "P",  // Default to "A" (Absent)
                        "date" to (getCurrentDate()), // Use current date if selectedDate is null
                        "school_id" to getSchoolId()
                    )
                    attendanceList.add(attendanceData)
                    Log.d("Attendance", "Added school_id for employee $employeeName: ${getSchoolId()}")

                }
            }

            // Submit each attendance record
            if (attendanceList.isNotEmpty()) {
                attendanceList.forEach { attendanceData ->
                    Log.d("AttendanceData", "Submitting attendance: $attendanceData")
                    attendanceViewModel.addEmployeeAttendance(attendanceData)
                }

                observeAttendanceResponse() // Observe the response after submission
                Toast.makeText(
                    requireContext(),
                    "Attendance submitted for ${attendanceList.size} employees.",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    requireContext(),
                    "No employees to submit attendance for",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        sdf.timeZone =
            TimeZone.getDefault() // Ensure the timezone is set to the device's default timezone

        val currentDate = sdf.format(calendar.time)

        // Log for debugging purposes
        Log.d("Timezone", "Current timezone: ${TimeZone.getDefault().id}")
        Log.d("CurrentDate", "The current date is: $currentDate")

        return currentDate
    }
}