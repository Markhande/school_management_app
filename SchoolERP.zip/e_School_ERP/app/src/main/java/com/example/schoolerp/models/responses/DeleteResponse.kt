package com.example.schoolerp.models.responses

data class DeleteResponse(
    val status: String,
    val message: String
)
