package com.example.schoolerp.Fragments.Fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.onboardingschool.LoginPage
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.models.responses.LogoutResponse
import com.example.schoolerp.models.responses.passwordResponse
import com.example.schoolerp.repository.GeneralSettingRepository
import com.example.schoolerp.viewmodel.GeneralSettingViewModel
import com.example.schoolerp.viewmodelfactory.GeneralSettingViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AccountSettings : Fragment() {

    private lateinit var viewModel: GeneralSettingViewModel

    // Instance variables to hold the API response data

//    val schoolIdEditText = EditText
    private lateinit var schoolIdEditText: EditText
    private lateinit var passwordEditText: EditText

    private var id: String = ""
    private var schoolName: String = ""
    private var password: String = ""
    private var number: String = ""
    private var createdAt: String = ""
    private var schoolId: String = ""
    private var role: String = ""
    private var email: String = ""

    private lateinit var schoolNameTextView: TextView
    private lateinit var roleTextView: TextView
    private lateinit var passwordTextView: TextView
    private lateinit var activationDate: TextView

    private val REQUEST_CALL_PERMISSION = 1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_account_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize TextViews
        schoolNameTextView = view.findViewById(R.id.txtUsername)
        roleTextView = view.findViewById(R.id.txtDestination)
        activationDate = view.findViewById(R.id.txtActivationDate)
        passwordTextView = view.findViewById(R.id.txtPassword)

        // Set up the ViewModel
        val repository = GeneralSettingRepository(RetrofitHelper.getApiService() , SchoolId().getSchoolId(requireContext()))
        val viewModelFactory = GeneralSettingViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory)[GeneralSettingViewModel::class.java]

        // Observe data
        viewModel.accountSettings.observe(viewLifecycleOwner) { response ->
            if (response != null && response.status) {
                // Filter to find the first account with the specific schoolId "eraAbc"
                val account = response.data.firstOrNull { it.school_id == SchoolId().getSchoolId(requireContext()) }

                if (account != null) {
                    // Set instance variables
                    id = account.id
                    schoolName = account.school_name
                    password = account.password
                    number = account.number
                    createdAt = account.created_at
                    schoolId = account.school_id
                    role = account.role
                    email = account.email

                    // Update UI
                    updateUI()
                } else {
                    Toast.makeText(context, "No account data found for school ID 'eraAbc'", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Failed to fetch account settings", Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.error.observe(viewLifecycleOwner) { error ->
            Toast.makeText(context, "Error: $error", Toast.LENGTH_SHORT).show()
        }

        // Set up the Delete Account button click listener
        view.findViewById<Button>(R.id.btnDeleteAccount).setOnClickListener {
//            showDeleteAccountDialog()
//            showConfirmationDialog()
            openEmailWithAdminInfo()

        }

        // Fetch account settings
        viewModel.fetchAccountSettings()

        // Set up password reset button click listener
        passwordEditText = view.findViewById(R.id.password)

        view.findViewById<Button>(R.id.btnUpdateAccountSetting).setOnClickListener {

            if ( passwordEditText.text.toString().trim().isNotEmpty()) {
                resetPassword(SchoolId().getSchoolId(requireContext()),  passwordEditText.text.toString().trim())
            } else {
                Toast.makeText(requireContext(), "Please enter new password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateUI() {
        schoolNameTextView.text = email
        roleTextView.text = role
        passwordTextView.text = password
        activationDate.text = createdAt.substring(0, 10)
    }

    private fun showDeleteAccountDialog() {
        // Create an AlertDialog
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("If you want to delete this account, kindly contact Admin.")
            .setTitle("Account Deletion")
            .setPositiveButton("Contact Admin") { _, _ ->
                openCallWithAdminPhone()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }

        // Show the dialog
        builder.create().show()
    }

    private fun openCallWithAdminPhone() {
        val adminPhoneNumber = "tel:+9975231"

        // Check if the CALL_PHONE permission is granted
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // If permission is not granted, request it
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.CALL_PHONE),
                REQUEST_CALL_PERMISSION
            )
        } else {
            // If permission is already granted, make the call
            val callIntent = Intent(Intent.ACTION_CALL, Uri.parse(adminPhoneNumber))
            startActivity(callIntent)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CALL_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                val adminPhoneNumber = "69975231" // Replace with actual phone number
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse(adminPhoneNumber))
                startActivity(callIntent)
            } else {
                Toast.makeText(requireContext(), "Permission denied to make the call", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun resetPassword(schoolId: String, password: String) {
        // Create a map of parameters
        val fields = mapOf(
            "school_id" to schoolId,
            "password" to password
        )

        // Make the API call using Retrofit
        RetrofitHelper.getApiService().updatePassword(fields).enqueue(object : Callback<passwordResponse> {
            override fun onResponse(call: Call<passwordResponse>, response: Response<passwordResponse>) {
                if (response.isSuccessful) {
                    val passwordResponse = response.body()
                    if (passwordResponse != null && passwordResponse.status) {
//                        Toast.makeText(requireContext(), "Password updated successfully", Toast.LENGTH_SHORT).show()
                        showConfirmationDialog()

                    } else {
                        // Show error message from the API
                        Toast.makeText(requireContext(), "Error: ${passwordResponse?.message ?: "Unknown error"}", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Request failed. Please try again.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<passwordResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Network error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun logoutUser() {
        // Call the logout API
        RetrofitHelper.getApiService().logout().enqueue(object : Callback<LogoutResponse> {
            override fun onResponse(call: Call<LogoutResponse>, response: Response<LogoutResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val logoutResponse = response.body()!!

                    if (logoutResponse.status) {
                        var sharedPreferences = requireContext().getSharedPreferences("onboarding_prefs", MODE_PRIVATE)
                        // Clear SharedPreferences
                        sharedPreferences.edit().clear().apply()

                        // Show a toast message
                        Toast.makeText(requireContext(), "Logout successful", Toast.LENGTH_SHORT).show()

                        // Redirect to login page
                        val intent = Intent(requireContext(), LoginPage::class.java)
                        startActivity(intent)
                        requireActivity().finish()

                    } else {
                        Toast.makeText(requireContext(), logoutResponse.message, Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to logout", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<LogoutResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Logout failed: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

//    ----------------------Are you sure you want to change your password? ----------------
    private fun showConfirmationDialog() {
    val builder = AlertDialog.Builder(requireContext())
    builder.setTitle("Password has changed successfully")
//        .setMessage("")
        .setCancelable(false)
        .setPositiveButton("Login") { dialog, which -> // Action when 'Yes' is clicked
            logoutUser()
        }
//        .setNegativeButton("No") { dialog, which -> // Action when 'No' is clicked
//            Toast.makeText(requireContext(), "You selected No", Toast.LENGTH_SHORT)
//                .show()
//        }

    // Create and show the dialog
    val dialog = builder.create()
    dialog.show()
}


    private fun openEmailWithAdminInfo() {
        val adminEmail = "hemantmarkhande590@gmail.com"

        // Create an intent to send an email
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            // Target Gmail explicitly
            setPackage("com.google.android.gm")
            data = Uri.parse("mailto:$adminEmail") // Set the recipient email address
        }

        // Check if the Gmail app is available
        if (emailIntent.resolveActivity(requireContext().packageManager) != null) {
            startActivity(emailIntent) // Open Gmail with the pre-filled "To" field
        } else {
            // Custom action if Gmail is not installed:

            // Show custom Toast
            Toast.makeText(requireContext(), "No Gmail app found. Please install it.", Toast.LENGTH_LONG).show()

            // Alternatively, you can open the Play Store to download Gmail
            val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.gm"))
            startActivity(playStoreIntent)
        }
    }
}
