package com.example.schoolerp.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.schoolerp.DataClasses.GetMessageData
import com.example.schoolerp.R
import com.example.schoolerp.databinding.ItemGetmessageBinding

class GetMessageAdapter(
    private var messages: List<GetMessageData> = listOf()
) : RecyclerView.Adapter<GetMessageAdapter.MessageViewHolder>() {

    // Submit a new list of messages to the adapter
    fun submitList(data: List<GetMessageData>) {
        messages = data
        notifyDataSetChanged()
    }

    // Create a new view holder for each item
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemGetmessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MessageViewHolder(binding)
    }

    // Bind the data to the view holder
    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(messages[position])
    }

    // Return the size of the message list
    override fun getItemCount(): Int = messages.size

    // ViewHolder class to bind data to the individual list item
    class MessageViewHolder(private val binding: ItemGetmessageBinding) :
        RecyclerView.ViewHolder(binding.root) {

        // Bind the message data to the views
        fun bind(message: GetMessageData) {
            binding.recipientType.text = message.recipient_type
            binding.searchSpecific.text = message.search_specific
            binding.messageContent.text = message.message

            // If there's an attachment, load it into the ImageView using Glide
            if (message.attachment?.isNotEmpty() == true) {
                Glide.with(binding.attachmentImage.context)
                    .load("https://your-server-url/${message.attachment}") // Replace with actual URL
                    .into(binding.attachmentImage)
            } else {
                // Set a placeholder image if no attachment is found
             //   binding.attachmentImage.setImageResource(R.drawable.placeholder_image)
            }
        }
    }
}
