package com.example.schoolerp.models.responses

import com.example.schoolerp.DataClasses.AttendanceStudentDateWise

class GetStudentAttandadanceDateWiseResponse (
    val status: Boolean,
    val data: AttendanceStudentDateWise
)