package com.example.schoolerp.Fragments.Fragment

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.DataClasses.Student
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.ViewModels.AddStudentViewModel
import com.example.schoolerp.ViewModels.AddStudentViewModelFactory
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.databinding.FragmentAddStudentBinding
import com.example.schoolerp.models.responses.AllClassNameResponse
import com.example.schoolerp.models.responses.SubjectResponse
import com.example.schoolerp.repository.AddStudentRepository
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Calendar

class AddStudent : Fragment() {

    private lateinit var binding: FragmentAddStudentBinding
    private var selectedGender: String? = null
    private lateinit var edDateOfBirth: EditText
    private lateinit var edDateOfAdmission: EditText
    private lateinit var sharedPreferences: SharedPreferences;
    private lateinit var shoolID: String
    private lateinit var viewModelAllClass: AllClassViewModel


    private lateinit var imageView: ImageView
    private var selectedImageUri: Uri? = null

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 1
        private const val PICK_IMAGE_REQUEST = 2
    }

    // Initialize ViewModel using a factory
    private val viewModel: AddStudentViewModel by viewModels {
        AddStudentViewModelFactory(AddStudentRepository(RetrofitHelper.getApiService()))
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout using View Binding
        binding = FragmentAddStudentBinding.inflate(inflater, container, false)

        // Initialize the EditTexts and ImageView
        edDateOfBirth = binding.edDateOfBirth
        edDateOfAdmission = binding.etDateOfAdmission
        imageView = binding.imageStudent  // Correctly reference the ImageView ID

        edDateOfBirth.setOnClickListener { showDatePicker(true) }
        edDateOfAdmission.setOnClickListener { showDatePicker(false) }

        binding.btnSubmit.setOnClickListener {
            if (!binding.spStudentSelectClass.selectedItem.toString().equals("Select Class")){
                if(binding.etPhoneNumber.text.toString().length == 10){
                    handleGenderSelection()
                    addStudent()
                }else{
                    Toast.makeText(requireContext(), "Enter Valid Phone Number", Toast.LENGTH_SHORT).show()
                }

            }else{
                Toast.makeText(requireContext(), "Select Class", Toast.LENGTH_SHORT).show()
            }

        }

        binding.btnUpload.setOnClickListener { openImageChooser() }

        observeViewModel()
        arguments?.getParcelable<Student>("student")?.let { student ->
            populateFields(student)
        }
        getSchoolId()
        (SchoolId().getSchoolId(requireContext()))
        viewModelAllClass()
        setupAllClassObserver()

        binding.btnResetButton.setOnClickListener(){
            Toast.makeText(requireContext(), binding.spStudentSelectClass2.selectedItem.toString(), Toast.LENGTH_SHORT).show()
        }

        return binding.root
    }
    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
            // Optionally, return a default value if not found
        }

        return schoolId ?: "defaultSchoolId" // Return the schoolId or a default value
    }
    private fun populateFields(student: Student) {
        // Populate the fields with the data from the `Student` object
        binding.etschoolId.setText(student.school_id)
        binding.etStudentName.setText(student.st_name)
        binding.etregistrationNo.setText(student.registration_no)
        binding.spStudentSelectClass.setSelection(getSpinnerIndex(binding.spStudentSelectClass, student.st_class))
        binding.etDateOfAdmission.setText(student.dt_of_admission)
        binding.etDiscountFees.setText(student.discount_fee)
        binding.etPhoneNumber.setText(student.number)
        binding.edDateOfBirth.setText(student.dt_of_birth)
        binding.spSelectReligion.setSelection(getSpinnerIndex(binding.spSelectReligion, student.religion))
        binding.spSelectBloodGroup.setSelection(getSpinnerIndex(binding.spSelectBloodGroup, student.blood_group))
        binding.etOrphanStudent.setText(student.orphan_student.toString())
        binding.etOSC.setText(student.osc)
        binding.etPreviousId.setText(student.previous_id)
        binding.etSelectFamily.setText(student.family)
        binding.edDiseaseIfAny.setText(student.disease_if_any)
        binding.etAnyAdditionalNote.setText(student.additional_note)
        binding.etTotalSibling.setText(student.siblings)
        binding.etAddress.setText(student.address)
        binding.etFatherName.setText(student.father_name)
        binding.etFatherID.setText(student.father_id)
        binding.etFatherEducatino.setText(student.father_education)
        binding.etFatherOccupation.setText(student.father_occupation)
        binding.etMotherName.setText(student.mother_name)
        binding.etMotherID.setText(student.mother_id)
        binding.etIdentityMark.setText(student.identification_mark)
        binding.etPreviousSchool.setText(student.st_previous_school)
        binding.etcreatedAt.setText(student.created_at)

        // Handle setting gender (assuming radio buttons or dropdown)
        setSelectedGender(student.gender)

        // Load the image if available
        /*if (student.picture.isNotEmpty()) {
            val imageUri = Uri.parse(student.picture)
            binding.imageView.setImageURI(imageUri)  // Assuming `imageView` is the ImageView for the picture
        }*/
    }

    // Helper function to get spinner index
    private fun getSpinnerIndex(spinner: Spinner, value: String): Int {
        for (i in 0 until spinner.count) {
            if (spinner.getItemAtPosition(i).toString().equals(value, ignoreCase = true)) {
                return i
            }
        }
        return 0
    }

    // Assuming you have a function to set the selected gender (for RadioButtons or Spinner)
    private fun setSelectedGender(gender: String) {
        when (gender) {
            "Male" -> binding.radioMale.isChecked = true
            "Female" -> binding.radioFemale.isChecked = true
            // Add other cases if needed
        }
    }


    private fun handleGenderSelection() {
        val selectedId: Int = binding.radioGroupGender.checkedRadioButtonId
        if (selectedId != -1) {
            val selectedRadioButton: RadioButton = binding.root.findViewById(selectedId)
            selectedGender = selectedRadioButton.text.toString()
            Toast.makeText(activity, "Selected: $selectedGender", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(activity, "No gender selected", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showDatePicker(isBirthDate: Boolean) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
            val date = "$selectedDay/${selectedMonth + 1}/$selectedYear"
            if (isBirthDate) {
                edDateOfBirth.setText(date)
            } else {
                edDateOfAdmission.setText(date)
            }
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun getSelectedGender(): String {
        return selectedGender ?: "Not specified"
    }

    private fun addStudent() {
        val schoolId = SchoolId().getSchoolId(requireContext())
        if(
            !binding.etStudentName.text.toString().isEmpty() &&
            !binding.etregistrationNo.text.toString().isEmpty() &&
            !binding.spStudentSelectClass.selectedItem.toString().isEmpty()&&
            !binding.etPhoneNumber.text.toString().isEmpty() &&
            !binding.etDateOfAdmission.text.toString().isEmpty())
        {

        val studentMap = mapOf(
            "school_id" to schoolId,
            "st_name" to binding.etStudentName.text.toString(),
            "registration_no" to binding.etregistrationNo.text.toString(),
            "st_class" to binding.spStudentSelectClass2.selectedItem.toString(),
            "picture" to (selectedImageUri?.toString() ?: "No picture selected"),
            "dt_of_admission" to binding.etDateOfAdmission.text.toString(),
            "discount_fee" to binding.etDiscountFees.text.toString(),
            "number" to binding.etPhoneNumber.text.toString(),
            "dt_of_birth" to edDateOfBirth.text.toString(),
            "religion" to binding.spSelectReligion.selectedItem.toString(),
            "blood_group" to binding.spSelectBloodGroup.selectedItem.toString(),
            "orphan_student" to binding.etOrphanStudent.text.toString(),
            "gender" to getSelectedGender(),
            "cast" to binding.spSelectCast.selectedItem.toString(),
            "osc" to binding.etOSC.text.toString(),
            "previous_id" to binding.etPreviousId.text.toString(),
            "family" to binding.etSelectFamily.text.toString(),
            "disease_if_any" to binding.edDiseaseIfAny.text.toString(),
            "additional_note" to binding.etAnyAdditionalNote.text.toString(),
            "siblings" to binding.etTotalSibling.text.toString(),
            "address" to binding.etAddress.text.toString(),
            "st_birth_id" to binding.etBirthId.text.toString(),

            "father_name" to binding.etFatherName.text.toString(),
            "father_id" to binding.etFatherID.text.toString(),
            "father_education" to binding.etFatherEducatino.text.toString(),
            "father_occupation" to binding.etFatherOccupation.text.toString(),
            "father_mobile" to binding.etFatherMobile.text.toString(),
            "father_profession" to binding.etFatherProfession.text.toString(),
            "father_income" to binding.etFatherIncome.selectedItem.toString(),

            "mother_name" to binding.etMotherName.text.toString(),
            "mother_id" to binding.etMotherID.text.toString(),
            "mother_mobile" to binding.etMotherMobile.text.toString(),
            "mother_occupation" to binding.etMotherOccupation.text.toString(),
            "mother_profession" to binding.etMotherProfession.text.toString(),
            "mother_income" to binding.etMotherIncome.selectedItem.toString(),
            "mother_education" to binding.etMotherEducation.text.toString(),

            "username" to binding.etPhoneNumber.text.toString(),
            "password" to binding.etStudentName.text.toString().substring(0,3)+binding.etPhoneNumber.text.toString().substring(6),
            "status" to "Active",

            "identification_mark" to binding.etIdentityMark.text.toString(),
            "st_previous_school" to binding.etPreviousSchool.text.toString(),
            "created_at" to binding.etcreatedAt.text.toString(),

        )
        Log.d("AddStudent", "Student data as Map: $studentMap")
        viewModel.addStudent(studentMap)

        } else{
            Toast.makeText(requireContext(), "Fill all the fields", Toast.LENGTH_SHORT).show()
        }
    }

    private fun observeViewModel() {
        viewModel.response.observe(viewLifecycleOwner, Observer { apiResponse ->
            apiResponse?.let {
                Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
            }
        })

        viewModel.error.observe(viewLifecycleOwner, Observer { errorMessage ->
            Toast.makeText(requireContext(), "Error: $errorMessage", Toast.LENGTH_SHORT).show()
        })
    }

    private fun openImageChooser() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            val imageUri = data.data
            imageUri?.let {
                selectedImageUri = it
                imageView.setImageURI(it)  // Display the selected image
            } ?: run {
                Toast.makeText(context, "Failed to load image", Toast.LENGTH_SHORT).show()
            }
        }
    }


    //  ---------------Start Calling class API to show all class data in spinner ----------
    private fun viewModelAllClass(){
        val factory = AllClassViewModelFactory(AllClassRepository())
        viewModelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)

    }
    private fun setupAllClassObserver() {
        // Observe the LiveData from ViewModel
        viewModelAllClass.getClasses(SchoolId().getSchoolId(requireContext())).observe(viewLifecycleOwner) { response ->
            response?.data?.let { classList ->
                if (classList.isNotEmpty()) {
                    // Extract the class names and class IDs from the classList
                    val classNames = mutableListOf("Select Class") // Add "Select Class" as the default item
                    val classIds = mutableListOf("Select Class ID") // Add "Select Class ID" as the default item

                    // Add class names and class IDs from the class list
                    classNames.addAll(classList.map { it.class_name })
                    classIds.addAll(classList.map { it.class_id.toString() })

                    // Create adapter for the first spinner with class names (including "Select Class")
                    val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classNames)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                    // Create adapter for the second spinner with class IDs (including "Select Class ID")
                    val adapter2 = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classIds)
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                    // Set the adapters to the respective Spinners
                    binding.spStudentSelectClass.adapter = adapter
                    binding.spStudentSelectClass2.adapter = adapter2

                    // Set the OnItemSelectedListener for the first Spinner
                    binding.spStudentSelectClass.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parentView: AdapterView<*>, view: View?, position: Int, id: Long) {
                            // Get the selected class name (from first spinner)
                            val selectedClassName = parentView.getItemAtPosition(position) as String

                            // Filter class IDs based on the selected class name
                            val filteredClassIds = classList.filter { it.class_name == selectedClassName }
                                .map { it.class_id.toString() }

                            // Ensure filteredClassIds is not empty before updating the second spinner
                            if (filteredClassIds.isNotEmpty()) {
                                // Update the second spinner with the filtered class IDs
                                val updatedAdapter2 = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, filteredClassIds)
                                updatedAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                                binding.spStudentSelectClass2.adapter = updatedAdapter2
                            } else {
                                // If no matching class IDs, set the default "Select Class ID"
                                binding.spStudentSelectClass2.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listOf("Select Class ID"))
                            }
                        }

                        override fun onNothingSelected(parentView: AdapterView<*>) {
                            // Handle case when nothing is selected (optional)
                            // Set the default "Select Class ID" in the second spinner
                            binding.spStudentSelectClass2.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listOf("Select Class ID"))
                        }
                    }
                } else {
                    // If no classes are found, show a Toast
                    Toast.makeText(requireContext(), "No classes found", Toast.LENGTH_SHORT).show()
                }
            } ?: run {
                // Handle case when response or data is null
                Toast.makeText(requireContext(), "Failed to load classes", Toast.LENGTH_SHORT).show()
            }
        }
    }
    //  ---------------Start Calling class API to show all class data in spinner ----------

    //  ---------------Calling class API to show all class data in spinner ----------
//    private fun fetchClassNames(schoolId: String) {
//        RetrofitHelper.getApiService().getClassList(schoolId).enqueue(object : Callback<AllClassNameResponse> {
//            override fun onResponse(call: Call<AllClassNameResponse>, response: Response<AllClassNameResponse>) {
//                if (response.isSuccessful) {
//                    val allClassNameResponse = response.body()
//
//                    if (allClassNameResponse != null && allClassNameResponse.status) {
//                        // Extract the class names from the response
//                        val classNames = allClassNameResponse.classes.map { it.class_name }
//
//                        if(classNames.isEmpty()){}
//
//                        // Set the class names to the Spinner
//                        val adapter = ArrayAdapter(
//                            requireContext(),
//                            android.R.layout.simple_spinner_item,
//                            classNames
//                        )
//
//                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                        binding.spStudentSelectClass.adapter = adapter
//                    }
//                }
//            }
//
//            override fun onFailure(call: Call<AllClassNameResponse>, t: Throwable) {
//                // Handle failure
//                t.printStackTrace()
//            }
//        })
//    }
    
    fun fieldValidation(){
      

    }
}
