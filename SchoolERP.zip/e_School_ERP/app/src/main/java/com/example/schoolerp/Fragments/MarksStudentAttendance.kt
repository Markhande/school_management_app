package com.example.schoolerp.Fragments

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.R
import com.example.schoolerp.adapter.StudentNamesAdapter
import com.example.schoolerp.databinding.FragmentMarksStudentAttendanceBinding
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.repository.DateWiseStudentAttendanceRepository
import com.example.schoolerp.repository.StudentAttendanceRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodel.DateWiseStudentAttendanceViewModel
import com.example.schoolerp.viewmodel.StudentAttendanceViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import com.example.schoolerp.viewmodelfactory.DateWiseStudentAttendanceViewModelFactory
import com.example.schoolerp.viewmodelfactory.StudentAttendanceViewModelFactory
import java.util.Calendar

class MarksStudentAttendance : Fragment() {
    private lateinit var binding: FragmentMarksStudentAttendanceBinding
    private lateinit var viewmodelAllClass: AllClassViewModel
    private lateinit var viewmodelDateWise: DateWiseStudentAttendanceViewModel
    private lateinit var viewmodelAddStudentAttandance: StudentAttendanceViewModel


    private var selectedDate: String = getCurrentDate()
    private var selectedClassName: String? = null // Variable to store selected class name
    private var classNameList: List<String> =
        emptyList() // Declare this variable to store student names
    private lateinit var studentNamesAdapter: StudentNamesAdapter
    private lateinit var viewModel: StudentAttendanceViewModel
    private val attendanceMap = mutableMapOf<String, String>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMarksStudentAttendanceBinding.bind(
            inflater.inflate(R.layout.fragment_marks_student_attendance, null)
        )
        setupViewModelAllClass()
        setupViewModelClassNameStudent()
        // setupListeners()
        observeDataAllClass()
        setupListenerss() // Ensure listeners are set up correctly
        observeDataAllName() // Start observing student data
        setupViewModel()
        setupSubmitButton()
        return binding.root
    }

    private fun setupViewModelClassNameStudent() {
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewmodelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)
    }

    private fun getSchoolId(): String? {
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)
        if (schoolId != null) {
            Log.d("MarksStudentAttendance", "School ID: $schoolId")
        } else {
            Log.d("MarksStudentAttendance", "School ID not found in SharedPreferences")
        }
        return schoolId
    }

    private fun setupViewModelAllClass() {
        val apiService = RetrofitHelper.getApiService()
        val repository = DateWiseStudentAttendanceRepository(apiService)
        val factory = DateWiseStudentAttendanceViewModelFactory(repository)
        viewmodelDateWise =
            ViewModelProvider(this, factory).get(DateWiseStudentAttendanceViewModel::class.java)
    }

    private fun observeDataAllClass() {
        val schoolId = getSchoolId() ?: run {
            Log.e("MarksStudentAttendance", "School ID is null or blank. Cannot fetch data.")
            return
        }

        viewmodelAllClass.getClasses(schoolId.trim())
            .observe(viewLifecycleOwner, Observer { response ->
                if (response != null && response.status) {
                    Log.d(
                        "MarksStudentAttendance",
                        "Classes fetched successfully: ${response.data}"
                    )
                    val classList =
                        response.data.map { it.class_name } // Assuming class_name is a field in ClassItem
                    setupSpinner(classList)
                } else {
                    Log.e(
                        "MarksStudentAttendance",
                        "Failed to fetch class data or no data available."
                    )
                }
            })
    }

    private fun setupSpinner(classList: List<String>) {
        if (classList.isEmpty()) {
            Log.d("MarksStudentAttendance", "No classes found.")
            binding.txtClassName.isEnabled = false
            return
        }

        val adapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.txtClassName.adapter = adapter

        binding.txtClassName.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                selectedClassName = classList[position]
                Log.d("MarksStudentAttendance", "Selected class: $selectedClassName")
                // Fetch attendance data for the selected class
                fetchAttendanceData()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.d("MarksStudentAttendance", "No class selected.")
            }
        }
    }


    private fun setupViewModel() {
        val apiService = RetrofitHelper.getApiService()
        val repository = StudentAttendanceRepository(apiService)
        val factory = StudentAttendanceViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(StudentAttendanceViewModel::class.java)
    }

    private fun setupSubmitButton() {
        binding.submitAttendanceButton.setOnClickListener {
            // Collect attendance data for all students
            val attendanceList = mutableListOf<Map<String, String>>()

            // Ensure that every student has an attendance status, defaulting to "A" if not updated
            attendanceMap.forEach { (studentName, status) ->
                val attendanceData = mapOf(
                    "st_name" to studentName,
                    "status" to status,
                    "date" to selectedDate.orEmpty(),
                    "school_id" to getSchoolId().orEmpty(),
                    "class" to selectedClassName.orEmpty()
                )
                attendanceList.add(attendanceData)
            }

            // In case there are any students whose attendance was not updated in the map,
            // make sure to add them with the default "A" status.
            studentNamesAdapter.studentNames.forEach { studentName ->
                if (!attendanceMap.contains(studentName)) {
                    // If the student was not added, assume the attendance is "A"
                    val attendanceData = mapOf(
                        "st_name" to studentName,
                        "status" to "P",
                        "date" to selectedDate.orEmpty(),
                        "school_id" to getSchoolId().orEmpty(),
                        "class" to selectedClassName.orEmpty()
                    )
                    attendanceList.add(attendanceData as Map<String, String>)
                }
            }

            // Submit the attendance data for each student
            submitAttendanceForStudents(attendanceList)
            Toast.makeText(
                requireContext(),
                "Attendance successfully submitted for ${attendanceList.size} students.",
                Toast.LENGTH_SHORT
            ).show()


            Log.d("MarksStudentAttendance", "Attendance submitted: $attendanceList")
        }
    }

    private fun submitAttendanceForStudents(attendanceList: List<Map<String, String>>) {
        // Submit each student's attendance data one by one
        attendanceList.forEach { attendanceData ->
            viewModel.addStudentAttendance(attendanceData)
        }
    }


    private fun observeDataAllName() {
        // Observe attendance data from ViewModel
        viewmodelDateWise.attendanceData.observe(viewLifecycleOwner, Observer { response ->
            if (response != null && response.status) {
                Log.d(
                    "MarksStudentAttendance",
                    "Attendance data fetched successfully: ${response.data}"
                )
                val studentNames = response.data.student_names // Assuming student_names is a list
                setupRecyclerView(studentNames) // Use the unified setupRecyclerView
            } else {
                Log.e(
                    "MarksStudentAttendance",
                    "Failed to fetch attendance data or no data available."
                )
            }
        })
    }

    private fun setupRecyclerView(studentNames: List<String>) {
        studentNamesAdapter = StudentNamesAdapter(studentNames) { name, status ->
            attendanceMap[name] = status
            Log.d("MarksStudentAttendance", "Updated attendance: $name -> $status")
        }
        binding.recyclerViewStudentNames.apply {
            layoutManager = LinearLayoutManager(context)
            this.adapter = studentNamesAdapter
        }
    }

    private fun fetchAttendanceData() {
        val schoolId = getSchoolId()?.trim()
        val className = selectedClassName?.trim()

        if (!schoolId.isNullOrEmpty() && !className.isNullOrEmpty()) {
            viewmodelDateWise.fetchAttendance(schoolId, className)
            Log.d(
                "MarksStudentAttendance",
                "Fetching attendance for school ID: $schoolId, class: $className"
            )
        } else {
            Log.e(
                "MarksStudentAttendance",
                "Cannot fetch attendance. Missing or invalid school ID or class name."
            )
        }
    }

    private fun displayStudentNames(classNameList: List<String>) {
        // Check if the list is not empty
        if (classNameList.isNotEmpty()) {
            // Convert the list of student names into a comma-separated string
            val studentNames = classNameList.joinToString(", ")
            // Set the text of the TextView with the student names
            binding.classNameText.text = studentNames
        } else {
            // If no student names are available, display a default message
            binding.classNameText.text = "No students available"
        }
    }

    private fun setupListenerss() {
        binding.btnSearch.setOnClickListener {
            if (!selectedClassName.isNullOrEmpty() && classNameList.isNotEmpty()) {
                // Get the selected date (replace this with the actual selected date)
                // val selectedDate = "2024-11-16"  // Replace with your actual selected date

                // Convert the list of student names into a comma-separated string
                val studentNames = classNameList.joinToString(", ")

                // Navigate to MarksStudentAttendanceAllClassStudent with the selected class, date, and student names
                val fragment = MarksStudentAttendanceAllClassStudent()
                val bundle = Bundle()
                bundle.putString("className", selectedClassName)
                bundle.putString("selectedDate", selectedDate)
                bundle.putString(
                    "studentNames",
                    studentNames
                )  // Pass the student names to the fragment
                fragment.arguments = bundle

                // Use FragmentTransaction to replace the current fragment
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    /* private fun setupListeners() {
        // Set the current date as the default value when the fragment is created
        setDefaultDate()

        binding.dateofDateWise.setOnClickListener {
            openDatePicker()
        }
    }

    private fun setDefaultDate() {
        // Get the current date
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1 // Months are 0-based, so add 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        // Format the date as "yyyy-MM-dd"
        selectedDate = String.format("%04d-%02d-%02d", year, month, day)
        binding.dateofDateWise.setText(selectedDate) // Set it to the TextView
        Log.d("MarksStudentAttendance", "Default date set: $selectedDate")
    }

    private fun openDatePicker() {
        val calendar = Calendar.getInstance()
        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                // Update the selectedDate with the user's choice
                selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
                binding.dateofDateWise.setText(selectedDate)
                Log.d("MarksStudentAttendance", "Selected date: $selectedDate")
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }*/
    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val currentDate = String.format("%04d-%02d-%02d", year, month, day)

        // Add Log.d to print the current date
        Log.d("CurrentDate", "The current date is: $currentDate")

        return currentDate
    }
}
