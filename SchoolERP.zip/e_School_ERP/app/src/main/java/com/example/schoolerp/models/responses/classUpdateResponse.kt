package com.example.schoolerp.models.responses

class classUpdateResponse (
    val status: Boolean,
    val message: String

)