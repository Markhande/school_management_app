package com.example.schoolerp.DataClasses

class paySalaryData (
    val status: Boolean,
    val Message: String?,
    val data: SalaryDetails?
)
