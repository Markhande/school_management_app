package com.example.schoolerp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.schoolerp.models.responses.ClassDataResponse
import com.example.schoolerp.models.responses.classUpdateResponse
import com.example.schoolerp.repository.AllClassRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AllClassViewModel(private val repository: AllClassRepository) : ViewModel() {

    // Fetch all classes from the repository
    fun getClasses(schoolID: String): LiveData<ClassDataResponse?> {
        return repository.fetchAllClasses(schoolID)
    }

    // Delete class from the repository
    fun deleteClass(schoolId: String, classId: String): LiveData<Boolean> {
        return repository.deleteClass(schoolId, classId)
    }

    // Update class details in the repository
    fun updateClass(schoolId: String, classId: String, classDetails: Map<String, String>): LiveData<classUpdateResponse> {
        return repository.updateClass(schoolId, classId, classDetails)
    }
}




