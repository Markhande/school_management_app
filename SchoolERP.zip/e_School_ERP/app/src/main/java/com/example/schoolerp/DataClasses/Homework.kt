package com.example.schoolerp.DataClasses

data  class Homework(
    val id: String,
    var homework_date: String,
    var set_by: String,
    var classes: String, // 'class' is a reserved keyword in Kotlin
    var subject: String,
    var homework_detail: String,
    val school_id: String,
    val created_at: String
)