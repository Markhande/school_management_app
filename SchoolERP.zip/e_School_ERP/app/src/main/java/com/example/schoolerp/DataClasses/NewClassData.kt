package com.example.schoolerp.DataClasses

data class NewClassData(
    val status: Boolean,
    val classes: List<Class>
)


