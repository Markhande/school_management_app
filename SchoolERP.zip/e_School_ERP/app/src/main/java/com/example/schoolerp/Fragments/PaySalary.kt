package com.example.schoolerp.Fragments

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.schoolerp.DataClasses.paySalaryData
import com.example.schoolerp.databinding.FragmentPaySalaryBinding
import com.example.schoolerp.repository.PaySalaryRepository
import com.example.schoolerp.viewmodel.PaySalaryViewModel
import com.example.schoolerp.viewmodelfactory.PaySalaryViewModelFactory
import java.util.Calendar

class PaySalary : Fragment() {
    private lateinit var binding: FragmentPaySalaryBinding
    private lateinit var etSalaryDate: EditText

    // Initialize ViewModel with Factory
    private val viewModel: PaySalaryViewModel by viewModels {
        PaySalaryViewModelFactory(PaySalaryRepository())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPaySalaryBinding.inflate(inflater, container, false)

        // Initialize the date field and show the date picker dialog when clicked
        etSalaryDate = binding.etEmployeesDateOfPay
        etSalaryDate.setOnClickListener {
            showDatePickerDialog()
        }

        // Set up the button's OnClickListener
        binding.btnSubmitSalary.setOnClickListener {
            submitSalary()
        }

        return binding.root
    }

    private fun submitSalary() {
        // Get user input data
        val employeeId = binding.etEmployeeId.text.toString()
        val employeeName = binding.etEmployeesName.text.toString()
        val employeeRole = binding.etEmployeesRole.text.toString()
        val fhName = binding.etFHName.text.toString()
        val salaryMonth = binding.etSalaryMonth.text.toString()
        val salaryAmount = binding.etSalaryAmount.text.toString()
        val salaryDate = etSalaryDate.text.toString()
        val bonus = binding.etAnyBonus.text.toString()
        val deduction = binding.etAnyDeduction.text.toString()
        val netPaid = binding.etNetPaid.text.toString()

        // Call ViewModel's function and observe the result
       /* viewModel.paySalary(employeeId, employeeName, employeeRole, fhName, salaryMonth, salaryAmount, salaryDate, bonus, deduction, netPaid)
            .observe(viewLifecycleOwner) { salaryResponse ->
                if (salaryResponse != null) {
                    val data = salaryResponse.data
                    if (data != null) {
                        val employeeName = data.employee_name
                        Toast.makeText(requireContext(), "Employee: $employeeName", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(requireContext(), "Data is null", Toast.LENGTH_SHORT).show()
                    }
                    Toast.makeText(requireContext(), salaryResponse.Message.toString(), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Error submitting salary", Toast.LENGTH_SHORT).show()
                }
            }*/
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
            etSalaryDate.setText(formattedDate)
        }, year, month, day)
        datePickerDialog.show()
    }
}