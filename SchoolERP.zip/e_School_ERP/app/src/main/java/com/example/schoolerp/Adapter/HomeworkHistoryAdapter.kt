package com.example.schoolerp.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolerp.R
import com.example.schoolerp.databinding.ItemHomeworkBinding
import com.example.schoolerp.databinding.ItemHomeworkHistoryBinding
import com.example.schoolerp.models.requests.HomeworkHistory

class HomeworkHistoryAdapter(
    private var homeworkList: List<HomeworkHistory>
) : RecyclerView.Adapter<HomeworkHistoryAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemHomeworkHistoryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(homework: HomeworkHistory) {
            binding.tvDate.text = homework.homework_date
            binding.tvTeacher.text = homework.set_by
            binding.tvClass.text = homework.classes
            binding.tvDetail.text = homework.homework_detail
            binding.tvSubject.text = homework.subject

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHomeworkHistoryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(homeworkList[position])
    }

    override fun getItemCount(): Int = homeworkList.size

    fun updateData(newData: List<HomeworkHistory>) {
        homeworkList = newData
        notifyDataSetChanged()
    }
    fun clearData() {
        homeworkList = emptyList()
        notifyDataSetChanged()
    }
}
