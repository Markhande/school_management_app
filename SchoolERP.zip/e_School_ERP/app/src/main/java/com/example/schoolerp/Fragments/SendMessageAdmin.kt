package com.example.schoolerp.Fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.schoolerp.Adapter.GetMessageAdapter
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.GetMessageData
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentSendMessageAdminBinding
import com.example.schoolerp.models.responses.Classes
import com.example.schoolerp.models.responses.Employees
import com.example.schoolerp.models.responses.GetMessageResponse
import com.example.schoolerp.models.responses.Students
import com.example.schoolerp.repository.AddMessageRepository
import com.example.schoolerp.repository.BaseOnInputeMessageRepository
import com.example.schoolerp.repository.GetMessageRepository
import com.example.schoolerp.util.ImageUtil
import com.example.schoolerp.viewmodel.AddMessageViewModel
import com.example.schoolerp.viewmodel.BaseOnInputMessageViewModel
import com.example.schoolerp.viewmodel.GetMessageViewModel
import com.example.schoolerp.viewmodelfactory.AddMessageViewModelFactory
import com.example.schoolerp.viewmodelfactory.BaseOnInputeMessageViewModelFactory
import com.example.schoolerp.viewmodelfactory.GetMessageViewModelFactory
import kotlinx.coroutines.CoroutineStart
import java.io.ByteArrayOutputStream
import kotlin.io.encoding.Base64

class SendMessageAdmin : Fragment() {
    private lateinit var binding: FragmentSendMessageAdminBinding
    private lateinit var viewModelSendMessage: AddMessageViewModel
    private lateinit var viewModelInputeMessage: BaseOnInputMessageViewModel
    private lateinit var viewModelGetmessage:GetMessageViewModel
    private val CAMERA_REQUEST_CODE = 1001
    private val GALLERY_REQUEST_CODE = 1002
    private var imageUri: Uri? = null
    private lateinit var getMessageData: List<GetMessageData>
private lateinit var getmessageadapter: GetMessageAdapter
    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {




        binding = FragmentSendMessageAdminBinding.bind(
            inflater.inflate(
                R.layout.fragment_send_message_admin,
                null
            )
        )


        ModeViewSendMessage()
        ModelViewBaseonInpute()
        AddMessage()
        setupSpinners()
        ModelViewGetMessage()
        initview()
        initobserval()
        getSchoolId()

        binding.layoutVisible.setOnClickListener {
            binding.layoutSendmessage.visibility =
                if (binding.layoutSendmessage.visibility == View.GONE) {
                    View.VISIBLE
                } else {
                    binding.edtwriteMessage.text.clear()
                    View.GONE
                }
        }
        binding.edtwriteMessage.setOnTouchListener { v, event ->
            if (v.id == R.id.edtwriteMessage) {
                v.parent.requestDisallowInterceptTouchEvent(true)
                when (event.action and MotionEvent.ACTION_MASK) {
                    MotionEvent.ACTION_UP -> v.parent.requestDisallowInterceptTouchEvent(false)
                }
            }
            false
        }


        return binding.root
    }
    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
        }

        return schoolId ?: "defaultSchoolId"
    }

    private fun ModelViewGetMessage(){
    val apiService=RetrofitHelper.getApiService()
    val repository=GetMessageRepository(apiService)
    val factory=GetMessageViewModelFactory(repository)
    viewModelGetmessage=ViewModelProvider(this,factory).get(GetMessageViewModel::class.java)


    }
    private fun initview() {
        getMessageData = mutableListOf()

        binding.GetMessageRecycler.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        getmessageadapter = GetMessageAdapter(getMessageData)
        binding.GetMessageRecycler.adapter = getmessageadapter
    }

    private fun initobserval() {
        val schoolId = getSchoolId().trim() // Replace with actual school ID retrieval logic
        Log.d("GetMessageFragment", "Fetching messages for schoolId: $schoolId") // Log schoolId
        viewModelGetmessage.fetchMessages(schoolId.trim()) // Call fetchMessages from the ViewModel



        viewModelGetmessage.messages.observe(viewLifecycleOwner) { response ->
            if (response != null) {
                val data = response.data ?: emptyList()
                Log.d("GetMessageFragment", "Fetched ${data.size} messages.") // Log the number of messages

                if (data.isNotEmpty()) {
                    getmessageadapter.submitList(data) // Pass data to the adapter
                    Log.d("GetMessageFragment", "Messages passed to adapter.")
                } else {
                    Log.d("GetMessageFragment", "No messages found.")
                }
            } else {
                // Handle null response
                val errorMessage = "Failed to fetch messages."
                Log.e("GetMessageFragment", errorMessage) // Log the error
                // Optionally, show an error message to the user
                // showError(errorMessage)
            }
        }
    }
    private fun ModelViewBaseonInpute() {
        val apiService = RetrofitHelper.getApiService()
        val repository = BaseOnInputeMessageRepository(apiService)
        val factory = BaseOnInputeMessageViewModelFactory(repository)
        viewModelInputeMessage =
            ViewModelProvider(this, factory).get(BaseOnInputMessageViewModel::class.java)
    }

    private fun setupSpinners() {
        val spinner = binding.spSendBy // First spinner
        val availableDataSpinner = binding.AvailableData // Second spinner

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                handleSelection(selectedItem, availableDataSpinner)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed here
            }
        }
    }

    private fun handleSelection(selectedItem: String, availableDataSpinner: Spinner) {
        fetchDataBasedOnSelection(selectedItem) { data ->
            Log.d("SpinnerSetup", "Fetched data for $selectedItem: $data")

            // If no data, display a message
            val dataToDisplay = if (data.isEmpty()) listOf("No data available") else data

            // Log the data to ensure it is correct
            Log.d("SpinnerSetup", "Data to display in spinner: $dataToDisplay")

            // Update the spinner adapter with data on the UI thread
            requireActivity().runOnUiThread {
                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    dataToDisplay
                )
                availableDataSpinner.adapter = adapter

                // Set spinner visibility based on the data
                availableDataSpinner.visibility = if (data.isNotEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun fetchDataBasedOnSelection(selectedItem: String, callback: (List<String>) -> Unit) {
        val schoolId = SchoolId().getSchoolId(requireContext())
        Log.d("SpinnerSetup", "School ID: $schoolId")  // Log the school ID being used

        val inputMap = mapOf(
            "classes" to selectedItem,
            "students" to selectedItem,
            "employees" to selectedItem,
            "school_id" to schoolId
        )

        Log.d("SpinnerSetup", "Input Map: $inputMap")  // Log the input map

        // Make the API call
        viewModelInputeMessage.getBaseOnInputMessage(inputMap)

        // Observe the API response
        viewModelInputeMessage.baseOnInputMessageResponse.observe(viewLifecycleOwner) { result ->
            result.onSuccess { response ->
                Log.d(
                    "SpinnerSetup",
                    "API response received: ${response.data}"
                )  // Log the entire response data

                if (response.status) {
                    Log.d("SpinnerSetup", "API response status is true, data: ${response.data}")

                    // Process the data based on the selected item
                    val dataToDisplay = when (selectedItem) {
                        "specific_class" -> {
                            val classesData = handleClassesData(response.data.classes)
                            Log.d("SpinnerSetup", "Classes Data: $classesData")
                            classesData
                        }

                        "specific_student" -> {
                            val studentsData = handleStudentsData(response.data.students)
                            Log.d("SpinnerSetup", "Students Data: $studentsData")
                            studentsData
                        }

                        "specific_employees" -> {
                            val employeesData = handleEmployeesData(response.data.employees)
                            Log.d("SpinnerSetup", "Employees Data: $employeesData")
                            employeesData
                        }

                        else -> {
                            Log.d("SpinnerSetup", "No matching selection for: $selectedItem")
                            emptyList()
                        }
                    }
                    callback(dataToDisplay)  // Callback with the processed data
                } else {
                    Log.e("SpinnerSetup", "API response status is false: ${response.Message}")
                    callback(emptyList())  // Callback with an empty list if the response is not successful
                }
            }
            result.onFailure { error ->
                Log.e("SpinnerSetup", "API call failed: ${error.message}")
                callback(emptyList())  // Callback with an empty list in case of failure
            }
        }
    }

    private fun handleClassesData(classesData: Any?): List<String> {
        return when (classesData) {
            is List<*> -> {
                // Check if it's a list of Maps
                if (classesData.isNotEmpty() && classesData[0] is Map<*, *>) {
                    // Map the list of maps to class names
                    classesData.mapNotNull { (it as? Map<*, *>)?.get("class_name") as? String }
                } else {
                    Log.d("SpinnerSetup", "Classes data is empty or malformed: $classesData")
                    emptyList()
                }
            }

            else -> {
                Log.d("SpinnerSetup", "Classes data is not a List: $classesData")
                emptyList()
            }
        }
    }

    private fun handleStudentsData(studentsData: Any?): List<String> {
        return when (studentsData) {
            is List<*> -> {
                // Check if it's a list of Maps
                if (studentsData.isNotEmpty() && studentsData[0] is Map<*, *>) {
                    // Map the list of maps to student names
                    studentsData.mapNotNull { (it as? Map<*, *>)?.get("st_name") as? String }
                } else {
                    Log.d("SpinnerSetup", "Students data is empty or malformed: $studentsData")
                    emptyList()
                }
            }

            else -> {
                Log.d("SpinnerSetup", "Students data is not a List: $studentsData")
                emptyList()
            }
        }
    }

    private fun handleEmployeesData(employeesData: Any?): List<String> {
        return when (employeesData) {
            is List<*> -> {
                // Check if it's a list of Maps
                if (employeesData.isNotEmpty() && employeesData[0] is Map<*, *>) {
                    // Map the list of maps to employee names
                    employeesData.mapNotNull { (it as? Map<*, *>)?.get("employee_name") as? String }
                } else {
                    Log.d("SpinnerSetup", "Employees data is empty or malformed: $employeesData")
                    emptyList()
                }
            }

            else -> {
                Log.d("SpinnerSetup", "Employees data is not a List: $employeesData")
                emptyList()
            }
        }
    }

    private fun ModeViewSendMessage() {
        val apiService = RetrofitHelper.getApiService()
        val repository = AddMessageRepository(apiService)
        val factory = AddMessageViewModelFactory(repository)
        viewModelSendMessage = ViewModelProvider(this, factory).get(AddMessageViewModel::class.java)
    }

    private fun AddMessage() {
        // When the attachment text is clicked, show options to either take a photo or open the gallery
        binding.textAttach.setOnClickListener { showImagePickerOptions() }

        val schoolId = SchoolId().getSchoolId(requireContext())

        binding.btnAddMessage.setOnClickListener {
            // Prepare the send message data
            val sendMessage = mapOf(
                "recipient_type" to binding.spSendBy.selectedItem.toString(),
                "search_specific" to binding.AvailableData.selectedItem.toString(),
                "message" to binding.edtwriteMessage.text.toString(),
                "attachment" to binding.textAttach.text.toString(), // This will be the Base64 string
                "school_id" to schoolId
            )
            initobserval()
            Toast.makeText(context, "Message Sent successfully!", Toast.LENGTH_SHORT).show()
            binding.layoutSendmessage.visibility = GONE
            // Show confirmation dialog
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Massage Has Sent.")
                .setMessage(binding.edtwriteMessage.text.toString())
                .setPositiveButton("Ok") { dialog, _ ->
                    // Proceed with deletion if the user confirms
                    binding.edtwriteMessage.text.clear()
                    dialog.dismiss()
                }
                .create()
                .show()
            // Call the view model to send the message
            viewModelSendMessage.sendMessage(sendMessage)
        }
    }

    // Show dialog to pick camera or gallery
    private fun showImagePickerOptions() {
        val options = arrayOf("Open Camera", "Open Gallery")
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Pick an option")
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> openCamera()  // Camera option
                1 -> openGallery() // Gallery option
            }
        }
        builder.show()
    }

    // Open camera to take a photo
    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST_CODE)
    }

    // Open gallery to select an image
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                CAMERA_REQUEST_CODE -> {
                    // Handle image from camera
                    val bitmap = data?.extras?.get("data") as Bitmap
                    imageUri =
                        getImageUri(requireContext(), bitmap) // Convert Bitmap to URI if needed
                    // Convert Bitmap to Base64 string
                 //   val base64String = encodeImageToBase64(bitmap)
                //    binding.textAttach.text = base64String // Set Base64 string as text
                }

                GALLERY_REQUEST_CODE -> {
                    // Handle image from gallery
                    imageUri = data?.data // URI of the selected image
                    // Convert URI to Bitmap, then to Base64
                    val bitmap = MediaStore.Images.Media.getBitmap(
                        requireContext().contentResolver,
                        imageUri
                    )
                  //  val base64String = encodeImageToBase64(bitmap)
                  //  binding.textAttach.text = base64String // Set Base64 string as text
                }
            }
        }
    }

// Convert Bitmap to Base64 string
/*
    private fun encodeImageToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        // Use the stable Base64 encoding from android.util.Base64
        //  return Base64.encodeToString(byteArray, Base64.DEFAULT)
}
*/
    // Convert Bitmap to Uri (This part can remain if needed for other purposes)
    private fun getImageUri(context: Context, bitmap: Bitmap): Uri {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path =
            MediaStore.Images.Media.insertImage(context.contentResolver, bitmap, "Title", null)
        return Uri.parse(path)
    }
}