package com.example.schoolerp.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Spinner
import com.example.schoolerp.DataClasses.Student
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentSearchStudentBinding

class SearchStudent : Fragment() {
    private lateinit var  binding:FragmentSearchStudentBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentSearchStudentBinding.bind(inflater.inflate(R.layout.fragment_search_student,null))
        arguments?.getParcelable<Student>("student")?.let { student ->
            populateFields(student)
        }
        return binding.root
    }

    private fun populateFields(student: Student) {
        binding.etschoolId.setText(student.school_id)
        binding.etStudentName.setText(student.st_name)
        binding.etregistrationNo.setText(student.registration_no)
        binding.spStudentSelectClass.setText(student.st_class)
        binding.etDateOfAdmission.setText(student.dt_of_admission)
        binding.etDiscountFees.setText(student.discount_fee)
        binding.etPhoneNumber.setText(student.number)
        binding.etUsername.setText(student.username)
        binding.etPassword.setText(student.password)
        binding.etStatus.setText(student.status)
        binding.edDateOfBirth.setText(student.dt_of_birth)
        binding.spSelectCast.setText(student.cast)
        binding.spSelectReligion.setText(student.religion)
        binding.spSelectBloodGroup.setText(student.blood_group)
        binding.etOrphanStudent.setText(student.orphan_student.toString())
        binding.etOSC.setText(student.osc)
        binding.etPreviousId.setText(student.previous_id)
        binding.etSelectFamily.setText(student.family)
        binding.edDiseaseIfAny.setText(student.disease_if_any)
        binding.etTotalSibling.setText(student.siblings)
        binding.etAddress.setText(student.address)
        binding.etFatherName.setText(student.father_name)
        binding.etFatherID.setText(student.father_id)
        binding.etFatherEducatino.setText(student.father_education)
        binding.etFatherMobile.setText(student.father_mobile)
        binding.etFatherOccupation.setText(student.father_occupation)
        binding.etFatherProfession.setText(student.father_profession)
        binding.etFatherIncome.setText(student.father_income)
        binding.etMotherName.setText(student.mother_name)
        binding.etMotherID.setText(student.mother_id)
        binding.etMotherEducation.setText(student.mother_education)
        binding.etMotherMobile.setText(student.mother_mobile)
        binding.etMotherOccupation.setText(student.mother_occupation)
        binding.etMotherProfession.setText(student.mother_profession)
        binding.etMotherIncome.setText(student.mother_income)
        binding.etIdentityMark.setText(student.identification_mark)
        binding.etPreviousSchool.setText(student.st_previous_school)
        binding.radioGroupGender.setText(student.gender)

        var isPasswordVisible = false
        // Replace with your actual password

        // Set initial state
        binding.etPassword.text = "*".repeat(student.password.length)

        // Handle toggle button click
        binding.togglePasswordVisibility.setOnClickListener {
            isPasswordVisible = !isPasswordVisible

            if (isPasswordVisible) {
                // Show the actual password
                binding.etPassword.text = student.password
                binding.togglePasswordVisibility.setImageResource(R.drawable.eyeonpassword) // Change to "eye-open" icon
            } else {
                // Hide the password
                binding.etPassword.text = "*".repeat(student.password.length)
                binding.togglePasswordVisibility.setImageResource(R.drawable.eyeoffpassword) // Change to "eye-closed" icon
            }
        }


        binding.txtSeeMore.setOnClickListener {
            binding.layoutStInfo.visibility =
                if (binding.layoutStInfo.visibility == View.GONE) {
                    View.VISIBLE
                } else {
                    binding.txtSeeMore.text
                    View.GONE
                }
        }





        // Handle setting gender (assuming radio buttons or dropdown)
//        setSelectedGender(student.gender)

        // Load the image if available
        /*if (student.picture.isNotEmpty()) {
            val imageUri = Uri.parse(student.picture)
            binding.imageView.setImageURI(imageUri)  // Assuming imageView is the ImageView for the picture
        }*/
    }

    private fun getSpinnerIndex(spinner: Spinner, value: String): Int {
        for (i in 0 until spinner.count) {
            if (spinner.getItemAtPosition(i).toString().equals(value, ignoreCase = true)) {
                return i
            }
        }
        return 0
    }
//    private fun setSelectedGender(gender: String) {
//        when (gender) {
//            "Male" -> binding.radioMale.isChecked = true
//            "Female" -> binding.radioFemale.isChecked = true
//            // Add other cases if needed
//        }
//    }

}