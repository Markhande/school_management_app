package com.example.schoolerp.DataClasses

data class InstituteProfileDataClass(
    val status: Boolean,
    val Message: String,
    val data: InstituteDetails
)