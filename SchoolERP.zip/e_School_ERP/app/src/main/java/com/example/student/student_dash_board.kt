package com.example.student

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId

class student_dash_board : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var ab = student_dash_board()

        Toast.makeText(requireContext(), SchoolId().getLoginRole(requireContext()), Toast.LENGTH_SHORT).show()
        Toast.makeText(requireContext(), SchoolId().getSchoolName(requireContext()), Toast.LENGTH_SHORT).show()
        Toast.makeText(requireContext(), SchoolId().getSchoolId(requireContext()), Toast.LENGTH_SHORT).show()
        Toast.makeText(requireContext(), SchoolId().getSchoolAdress(requireContext()), Toast.LENGTH_SHORT).show()

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_student_dash_board, container, false)
    }

}