package com.example.schoolerp.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.ClassItem
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentUpdateClassBinding
import com.example.schoolerp.models.responses.TeacherNameResponse
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class UpdateClass : Fragment() {

    private lateinit var binding: FragmentUpdateClassBinding
    private lateinit var classItem: ClassItem
    private lateinit var viewModel: AllClassViewModel
    private val classNamesList = mutableListOf<String>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentUpdateClassBinding.inflate(inflater, container, false)

        // Retrieve data passed from previous fragment
        arguments?.getSerializable("class_data")?.let {
            classItem = it as ClassItem
            displayClassDetails(classItem)
        }

        // Initialize ViewModel
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)

        // You can get schoolId from SharedPreferences if needed
        val schoolId = SchoolId().getSchoolId(requireContext())  // Replace with actual logic to get school ID
        val classId = classItem.class_id // Use the classId from classItem

        // Set the default values for the fields (you can edit these)
        binding.tvClassTwo.setText(classItem.class_name)
        binding.tvTutionFeesTwo.setText(classItem.total_students)
        binding.tvClassTeacher.setText(classItem.total_boys)
        binding.tvClassTeacher.setText(classItem.total_boys)

        // When the "Update" button is clicked, call the update API
        binding.btnUpdateClass.setOnClickListener {
            val updatedClassName = binding.tvClassTwo.text.toString()
            val updatedTutionFees = binding.tvTutionFeesTwo.text.toString()
            val updatedClassTeacher = binding.tvClassTeacher.text.toString()

            // Map the updated details to pass in the API request
            val classDetails = mapOf(
                "class_name" to updatedClassName,
                "tution_fees" to updatedTutionFees,
                "class_teacher" to updatedClassTeacher,
                "school_id" to SchoolId().getSchoolId(requireContext())
            )

            // Trigger the update API call
            viewModel.updateClass(SchoolId().getSchoolId(requireContext()), classId, classDetails).observe(viewLifecycleOwner) { response ->
                if (response.status) {
                    Toast.makeText(requireContext(), response.message, Toast.LENGTH_SHORT).show()
                    showSuccessDialog()
                } else {
                    Toast.makeText(requireContext(), "Error: ${response.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        fetchTeacherNames(SchoolId().getSchoolId(requireContext()))

        return binding.root
    }

    private fun displayClassDetails(classItem: ClassItem) {
        binding.tvClassTwo.setText(classItem.class_name)
        binding.tvTutionFeesTwo.setText(classItem.total_students)
        binding.tvClassTeacher.setText(classItem.total_boys)

    }

    private fun fetchTeacherNames(SchoolID: String) {
        RetrofitHelper.getApiService().getEmployeeData(SchoolID).enqueue(object : Callback<TeacherNameResponse> {
            override fun onResponse(call: Call<TeacherNameResponse>, response: Response<TeacherNameResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val employees = response.body()!!.data
                    val roles = mutableListOf<String>()

                    // Extracting employee names and populating the roles list
                    for (employee in employees) {
                        employee.employeeName?.let {
                            roles.add(it)  // Add employee names to the list
                        }
                    }

                    if (roles.isEmpty()) {
                        Toast.makeText(requireContext(), "No employee names available", Toast.LENGTH_SHORT).show()
                    }

                    // Set up the adapter to populate the Teacher Spinner
                    val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, roles)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.spAllTeacherName.adapter = adapter

                } else {
                    Toast.makeText(requireContext(), "Failed to load data: ${response.message()}", Toast.LENGTH_SHORT).show()
                    Log.e("NewClass", "Error: ${response.message()}")
                }

            }

            override fun onFailure(call: Call<TeacherNameResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                Log.e("NewClass", "Network error: ${t.message}")
            }
        })
    }

    // Method to show a success dialog after updating the class
    private fun showSuccessDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Class Updated")
        builder.setMessage("The class has been successfully updated.")

        // Set the "OK" button to dismiss the dialog and return to AllClass fragment
        builder.setPositiveButton("OK") { _, _ ->
            returnClassWithSubject() // Navigate to AllClass Fragment after clicking OK
        }

        // Create and show the dialog
        builder.setCancelable(false)  // Makes the dialog non-cancelable, meaning the user has to click OK
        builder.create().show()
    }

    // Updated method to navigate to AllClass Fragment
    fun returnClassWithSubject() {

        val allClassFragment = AllClass() // Replace with your AllClass Fragment class

        // Begin Fragment transaction
        val transaction = parentFragmentManager.beginTransaction()

        // Replace current Fragment with AllClass Fragment
        transaction.replace(R.id.fragment_container, allClassFragment)

        // Optionally, add to back stack if you want to enable back navigation
        transaction.addToBackStack(null)

        // Commit the transaction
        transaction.commit()
    }
}