package com.example.schoolerp.Fragments

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentAddIncomeBinding
import com.example.schoolerp.repository.AddIncomeRepository
import com.example.schoolerp.viewmodelfactory.AddIncomeViewModelFactory
import com.example.schoolerp.viewmodel.AddIncomeViewModel
import java.util.*

class AddIncome : Fragment() {
    private lateinit var binding: FragmentAddIncomeBinding
    private val viewModel: AddIncomeViewModel by viewModels {
        AddIncomeViewModelFactory(AddIncomeRepository())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAddIncomeBinding.bind(inflater.inflate(R.layout.fragment_add_income, null))

        // Set up submit button click listener
        binding.btnCreate.setOnClickListener {
            submitIncomeData()
        }

        // Set up date picker for the EditText
        binding.edtDate.setOnClickListener {
            showDatePickerDialog()
        }

        return binding.root
    }

    private fun showDatePickerDialog() {
        // Get current date
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        // Create DatePickerDialog
        val datePickerDialog = DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
            // Format the date and set it to the EditText
            val formattedDate = String.format("%02d/%02d/%02d", selectedDay, selectedMonth + 1, selectedYear % 100)
            binding.edtDate.setText(formattedDate)
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun submitIncomeData() {
        // Collect form data from input fields
        val incomeDate = binding.edtDate.text.toString()
        val incomeAmount = binding.edtincomeamount.text.toString()
        val incomeDescription = binding.edtincomedescrption.text.toString()

        // Validate input data
        if (incomeDate.isEmpty() || incomeAmount.isEmpty() || incomeDescription.isEmpty()) {
            Toast.makeText(activity, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Prepare data to be sent to the ViewModel
        val incomeData = HashMap<String, String>().apply {
            put("date_of_income", incomeDate)
            put("income_amount", incomeAmount)
            put("income_description", incomeDescription)
        }

        // Observe LiveData from ViewModel
        viewModel.submitIncomeData(incomeData).observe(viewLifecycleOwner) { apiResponse ->
            if (apiResponse != null) {
                // Check if the response indicates success
                val message = apiResponse.Message ?: "Income added successfully"
                if (apiResponse.status) {
                    Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(activity, "Failed to add income: $message", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(activity, "Failed to add income", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
