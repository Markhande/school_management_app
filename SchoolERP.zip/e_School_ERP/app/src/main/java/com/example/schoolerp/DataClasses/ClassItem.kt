package com.example.schoolerp.DataClasses

import java.io.Serializable


data class ClassItem(
    val class_id: String,
    val class_name: String,
    val total_students: String,
    val total_girls: String,
    val total_boys: String
): Serializable
