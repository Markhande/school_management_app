package com.example.schoolerp.DataClasses

class EmpAttendanceData ( val employee_name: String,
val status: String,
val date: String,
val school_id: String,
val id: Int
)