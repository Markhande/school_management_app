package com.example.schoolerp.models.responses

data class LoginResponse(
    val status: Boolean,
    val message: String,
    val role: String,
    val school_id: String,
    val number: String,
    val school_name: String,
    val institute_address: String,
    val institute_logo: String,
    val tag_line: String,
    val phone_number: String,
    val password: String,
    val website: String,
    val country: String,
    val updated_at: String,
    val users: List<User>
)


data class User(
    val id: String,
    val school_name: String,
    val employee_id: String,
    val password: String,
    val number: String,
    val created_at: String,
    val school_id: String,
    val address: String,
    val website: String,
    val tag_line: String,
//    val website: String,
    val role: String
)

data class loginStudentResposne(
    val status: Boolean,
    val message: String,
    val role: String
)
