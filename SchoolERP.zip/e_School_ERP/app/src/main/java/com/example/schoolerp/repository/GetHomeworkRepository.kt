package com.example.schoolerp.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.schoolerp.Api.ApiService
import com.example.schoolerp.models.responses.GetHomeworkResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class GetHomeworkRepository(private val apiService: ApiService)  {

    fun fetchHomeWork(schoolId: String): LiveData<Result<GetHomeworkResponse>> {
        val data = MutableLiveData<Result<GetHomeworkResponse>>()

        apiService.getHomeWork(schoolId).enqueue(object : Callback<GetHomeworkResponse> {
            override fun onResponse(call: Call<GetHomeworkResponse>, response: Response<GetHomeworkResponse>) {
                if (response.isSuccessful) {
                    data.postValue(Result.success(response.body()!!))
                } else {
                    data.postValue(Result.failure(Exception(response.message())))
                }
            }

            override fun onFailure(call: Call<GetHomeworkResponse>, t: Throwable) {
                data.postValue(Result.failure(t))
            }
        })

        return data
    }
}

