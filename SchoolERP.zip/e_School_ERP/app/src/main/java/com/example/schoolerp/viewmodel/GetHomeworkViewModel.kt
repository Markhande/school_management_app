package com.example.schoolerp.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.schoolerp.DataClasses.Homework
import com.example.schoolerp.models.responses.GetHomeworkResponse
import com.example.schoolerp.repository.GetHomeworkRepository

class GetHomeworkViewModel(private val repository: GetHomeworkRepository) : ViewModel() {

    private val _homeworkList = MutableLiveData<List<Homework>>()
    val homeworkList: LiveData<List<Homework>> get() = _homeworkList

    fun getHomeWork(schoolId: String) {
        repository.fetchHomeWork(schoolId).observeForever { result ->
            result.onSuccess { response ->
                // Assuming `response` has a `homeworkList` property
                _homeworkList.postValue(response.data)
            }.onFailure { error ->
                // Handle the error (e.g., show a message to the user)
                Log.e("GetHomeworkViewModel", "Error fetching homework", error)
            }
        }
    }
}
