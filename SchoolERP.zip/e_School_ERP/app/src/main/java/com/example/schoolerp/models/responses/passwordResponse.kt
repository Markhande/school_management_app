package com.example.schoolerp.models.responses

class passwordResponse (
    val status: Boolean,
    val message: String
)