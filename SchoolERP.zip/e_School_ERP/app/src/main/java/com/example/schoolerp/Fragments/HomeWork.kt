package com.example.schoolerp.Fragments

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.schoolerp.Adapter.HomeworkAdapter
import com.example.schoolerp.Adapter.HomeworkHistoryAdapter
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.Homework
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentHomeWorkBinding
import com.example.schoolerp.repository.AddHomeworkRepository
import com.example.schoolerp.repository.AllClassRepository
import com.example.schoolerp.repository.AllEmployeesRepository
import com.example.schoolerp.repository.ClassWiseSubjectRepository
import com.example.schoolerp.repository.EmployeeAndPrincipleRepository
import com.example.schoolerp.repository.GetHomeworkRepository
import com.example.schoolerp.repository.SearchHistoryHomeworkRepository
import com.example.schoolerp.repository.getStudentRepository
import com.example.schoolerp.viewmodel.AddHomeworkViewModel
import com.example.schoolerp.viewmodel.AllClassViewModel
import com.example.schoolerp.viewmodel.AllEmployeesViewModel
import com.example.schoolerp.viewmodel.ClassWiseSubjectViewModel
import com.example.schoolerp.viewmodel.EmployeeAndPrincipleViewModel
import com.example.schoolerp.viewmodel.GetHomeworkViewModel
import com.example.schoolerp.viewmodel.SearchHistoryHomeworkViewModel
import com.example.schoolerp.viewmodel.getStudentViewModel
import com.example.schoolerp.viewmodelfactory.AddHomeworkViewModelFactoryclass
import com.example.schoolerp.viewmodelfactory.AllClassViewModelFactory
import com.example.schoolerp.viewmodelfactory.AllEmployeesViewModelFactory
import com.example.schoolerp.viewmodelfactory.ClassWiseSubjectViewModelFactory
import com.example.schoolerp.viewmodelfactory.EmployeeAndPrincipleViewModelFactory
import com.example.schoolerp.viewmodelfactory.GetHomeworkViewModelFactory
import com.example.schoolerp.viewmodelfactory.SearchHistoryHomeworkViewModelFactory
import com.example.schoolerp.viewmodelfactory.getStudentViewModelFactory
import java.util.Calendar

class HomeWork : Fragment() {
    private lateinit var binding: FragmentHomeWorkBinding
    private val homeworkList = mutableListOf<Homework>()
    private lateinit var adapter: HomeworkAdapter
    private lateinit var viewModelGetHomework: GetHomeworkViewModel
    private lateinit var viewModelAllEmp: AllEmployeesViewModel
    private lateinit var viewModelAddHome:AddHomeworkViewModel

    private lateinit var viewmodelAllClass: AllClassViewModel
    private lateinit var viewModelCalssWise: ClassWiseSubjectViewModel
    private lateinit var viewModelgetTeacher:EmployeeAndPrincipleViewModel
    private lateinit var viewModelSearchHistory:SearchHistoryHomeworkViewModel
    private lateinit var HomeworkHistoryAdapter:HomeworkHistoryAdapter



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeWorkBinding.inflate(inflater, container, false)
        initView()
        setUpListeners()
        // observalAllEmpSpinner()
        viewModelGetHomeWork()
        getSchoolId()
        fetchdata()
        observeHomeworkList()
        viewModelGetEmp()
        viewModelAddHomeWork()
        setupViewModelClassNameStudent()

        modelviewgetteacher()
        setupObserver()
        setupViewModeClassWise()
        viewmodelSearchHomeworkHostory()
        setuplistnersSearchHistery()
        viewModelAllClass()
        setupAllClassObserver()
        return binding.root
    }
    private fun viewmodelSearchHomeworkHostory(){
        val apiService = RetrofitHelper.getApiService()
        val repository = SearchHistoryHomeworkRepository(apiService)
        val factory = SearchHistoryHomeworkViewModelFactory(repository)
        viewModelSearchHistory = ViewModelProvider(this, factory).get(SearchHistoryHomeworkViewModel::class.java)

    }
    private fun searchHomeWork() {
        if (binding.spStudentSelectClassIdAddHomeWork.selectedItem.toString().isNotEmpty() && !binding.spStudentSelectClassIdAddHomeWork.selectedItem.toString().equals(null)) {

        // Get the school ID (assuming you have a method to fetch the school ID)
        val schoolId = SchoolId().getSchoolId(requireContext())

        val homeworkDate = binding.edtDateCurrent.editText?.text.toString() // Homework date
        val setBy = binding.TeacherAndPrincile.selectedItem.toString() // Assuming the 'set_by' field is in edtSetBy
        val classes = binding.spStudentSelectClassIdAddHomeWork.selectedItem.toString() // Spinner for classes

        val homeworkHistoryMap = mapOf(
            "homework_date" to homeworkDate,
            "set_by" to setBy,
            "class" to classes,
            "school_id" to schoolId // Get school ID from the method
        )
        // Log the data for debugging purposes
        Log.d("SearchHomeWork", "Homework data as Map: $homeworkHistoryMap")

        // Pass the map to the ViewModel method
        viewModelSearchHistory.searchHomeworkHistory(homeworkHistoryMap)
        searchHistoryObserval()
        }else{
            Toast.makeText(requireContext(), "Please Enter Date", Toast.LENGTH_SHORT).show()
        }

    }

    private fun searchHistoryObserval() {
        Log.d("SearchHistory", "Observing homework history...")

        // Initialize adapter and set it to RecyclerView
        val adapter = HomeworkHistoryAdapter(emptyList())
        binding.recyclerViewHomeworkHistory.adapter = adapter
        binding.recyclerViewHomeworkHistory.layoutManager = LinearLayoutManager(requireContext())

        // Initially hide RecyclerView and show progress bar
        binding.recyclerViewHomeworkHistory.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        // Observe homework history
        viewModelSearchHistory.homeworkHistory.observe(viewLifecycleOwner) { homeworkList ->
            Log.d("HomeworkHistory", "Number of homework items: ${homeworkList?.size ?: 0}")

            if (!homeworkList.isNullOrEmpty()) {
                // If data exists, update adapter and show RecyclerView
                adapter.updateData(homeworkList)
                binding.recyclerViewHomeworkHistory.visibility = View.VISIBLE
            } else {
                // If no data, clear the adapter and show a message
                adapter.updateData(emptyList())
                binding.recyclerViewHomeworkHistory.visibility = View.GONE
                Toast.makeText(requireContext(), "No homework history found", Toast.LENGTH_SHORT).show()
            }

            // Hide the progress bar in both cases
            binding.progressBar.visibility = View.GONE
        }

        // Observe loading state (optional)
        viewModelSearchHistory.loading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Observe errors
        viewModelSearchHistory.error.observe(viewLifecycleOwner) { errorMessage ->
            errorMessage?.let {
                Toast.makeText(requireContext(), it, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setuplistnersSearchHistery() {
            binding.btnSearchHomeWorkHistory.setOnClickListener {
                if (!binding.spStudentSelectClassIdAddHomeWork.selectedItem.toString().equals("Select Class ID")){
                    binding.recyclerViewHomeworkHistory.visibility = View.GONE
                    binding.progressBar.visibility = View.VISIBLE
                    searchHomeWork() // Trigger search
                }else{
                    Toast.makeText(requireContext(), "Please Select Class", Toast.LENGTH_SHORT).show()
                }

        }
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val currentDate = "$day/$month/$year"

        binding.edtDateCurrent.editText?.setText(currentDate) // Correct reference for TextInputEditText

        binding.edtDateCurrent.setOnClickListener {
            showDatePickerDialog()
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, selectedYear, selectedMonth, selectedDay ->
                // Format the selected date (Month is 0-based, so add 1)
                val formattedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"

                // Set the selected date to the TextInputEditText
                binding.edtDateCurrent.editText?.setText(formattedDate) // Correct reference for TextInputEditText
            },
            year,
            month,
            day
        )

        // Show the dialog
        datePickerDialog.show()


    }
    private fun populateSpinner(employeeNames: List<String>) {
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, employeeNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.TeacherAndPrincile.adapter = adapter

        binding.TeacherAndPrincile.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedName = employeeNames[position]
                // Handle selection if needed
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    //  ---------------Start Calling class API to show all class data in spinner ----------
    private fun viewModelAllClass(){
        val factory = AllClassViewModelFactory(AllClassRepository())
        viewmodelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)

    }

    private fun setupAllClassObserver() {
        // Observe the LiveData from ViewModel
        viewmodelAllClass.getClasses(SchoolId().getSchoolId(requireContext())).observe(viewLifecycleOwner) { response ->
            response?.data?.let { classList ->
                if (classList.isNotEmpty()) {
                    // Extract the class names and class IDs from the classList
                    val classNames = mutableListOf("Select Class") // Add "Select Class" as the default item
                    val classIds = mutableListOf("Select Class ID") // Add "Select Class ID" as the default item

                    // Add class names and class IDs from the class list
                    classNames.addAll(classList.map { it.class_name })
                    classIds.addAll(classList.map { it.class_id.toString() })

                    // Create adapter for the first spinner with class names (including "Select Class")
                    val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classNames)
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                    // Create adapter for the second spinner with class IDs (including "Select Class ID")
                    val adapter2 = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, classIds)
                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                    // Set the adapters to the respective Spinners
                    binding.spStudentSelectClass.adapter = adapter
                    binding.spStudentSelectClassIdAddHomeWork.adapter = adapter2

                    // Set the OnItemSelectedListener for the first Spinner
                    binding.spStudentSelectClass.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parentView: AdapterView<*>, view: View?, position: Int, id: Long) {
                            // Get the selected class name (from first spinner)
                            val selectedClassName = parentView.getItemAtPosition(position) as String

                            // Filter class IDs based on the selected class name
                            val filteredClassIds = classList.filter { it.class_name == selectedClassName }
                                .map { it.class_id.toString() }

                            // Ensure filteredClassIds is not empty before updating the second spinner
                            if (filteredClassIds.isNotEmpty()) {
                                // Update the second spinner with the filtered class IDs
                                val updatedAdapter2 = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, filteredClassIds)
                                updatedAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                                binding.spStudentSelectClassIdAddHomeWork.adapter = updatedAdapter2
                            } else {
                                // If no matching class IDs, set the default "Select Class ID"
                                binding.spStudentSelectClassIdAddHomeWork.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listOf("Select Class ID"))
                            }
                        }

                        override fun onNothingSelected(parentView: AdapterView<*>) {
                            // Handle case when nothing is selected (optional)
                            // Set the default "Select Class ID" in the second spinner
                            binding.spStudentSelectClassIdAddHomeWork.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listOf("Select Class ID"))
                        }
                    }
                } else {
                    // If no classes are found, show a Toast
                    Toast.makeText(requireContext(), "No classes found", Toast.LENGTH_SHORT).show()
                }
            } ?: run {
                // Handle case when response or data is null
                Toast.makeText(requireContext(), "Failed to load classes", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //  ---------------Start Calling class API to show all class data in spinner ----------

    private fun modelviewgetteacher(){
        val apiService = RetrofitHelper.getApiService()
        val repository = EmployeeAndPrincipleRepository(apiService)
        val factory = EmployeeAndPrincipleViewModelFactory(repository)
        viewModelgetTeacher = ViewModelProvider(this, factory).get(EmployeeAndPrincipleViewModel::class.java)


    }
    private fun setupObserver() {
        val schoolId = getSchoolId() // Replace with your method to get the school ID

        viewModelgetTeacher.fetchTeachersAndPrincipals(schoolId)

        viewModelgetTeacher.employees.observe(viewLifecycleOwner) { teacherList ->
            // Populate Spinner when data is fetched
            val employeeNames = teacherList.map { it.employee_name } // Extract names
            populateSpinner(employeeNames)
        }

        viewModelgetTeacher.error.observe(viewLifecycleOwner) { errorMessage ->
            // Show error message
            //showToast("Error: $errorMessage")
        }
    }

    private fun setupViewModeClassWise(){
        val apiService = RetrofitHelper.getApiService() // Initialize Retrofit instance
        val repository = ClassWiseSubjectRepository(apiService)
        val factory = ClassWiseSubjectViewModelFactory(repository)
        viewModelCalssWise = ViewModelProvider(this, factory).get(ClassWiseSubjectViewModel::class.java)

    }

    private fun getSchoolId(): String {
        // Retrieve the school_id from shared preferences
        val sharedPreferences = requireActivity().getSharedPreferences(
            "onboarding_prefs",
            AppCompatActivity.MODE_PRIVATE
        )
        val schoolId = sharedPreferences.getString("school_id", null)

        if (schoolId != null) {
            Log.d("AddNewEmployees", "School ID retrieved from SharedPreferences: $schoolId")
        } else {
            Log.d("AddNewEmployees", "School ID not found in SharedPreferences")
        }

        return schoolId ?: "defaultSchoolId"
    }

    private fun viewModelGetHomeWork() {
        val apiService = RetrofitHelper.getApiService()
        val repository = GetHomeworkRepository(apiService)
        val factory = GetHomeworkViewModelFactory(repository)
        viewModelGetHomework =
            ViewModelProvider(this, factory).get(GetHomeworkViewModel::class.java)


    }

    private fun viewModelGetEmp() {
        // val schoolId = getSchoolId() // Assuming you have a method to get school ID

        val apiService = RetrofitHelper.getApiService()
        val repository = AllEmployeesRepository(apiService)
        val factory = AllEmployeesViewModelFactory(repository)
        viewModelAllEmp = ViewModelProvider(this, factory).get(AllEmployeesViewModel::class.java)
        // viewModelAllEmp.getAllEmployees(schoolId.trim())


    }
    private fun viewModelAddHomeWork() {
        // val schoolId = getSchoolId() // Assuming you have a method to get school ID

        val apiService = RetrofitHelper.getApiService()
        val repository = AddHomeworkRepository(apiService)
        val factory = AddHomeworkViewModelFactoryclass(repository)
        viewModelAddHome = ViewModelProvider(this, factory).get(AddHomeworkViewModel::class.java)
        // viewModelAllEmp.getAllEmployees(schoolId.trim())


    }
    private fun fetchdata() {
        val schoolId = getSchoolId() // Assuming you have a method to get school ID

        viewModelGetHomework.getHomeWork(schoolId.trim())
    }

    private fun observeHomeworkList() {
        viewModelGetHomework.homeworkList.observe(viewLifecycleOwner) { homeworkList ->
            // Show progress bar while data is being fetched
            binding.progressBar.visibility = View.VISIBLE
            binding.RecyclerViewAddHomeWork.visibility = View.GONE // Hide RecyclerView during the search

            if (homeworkList != null) {
                // Data has been fetched, hide progress bar
                binding.progressBar.visibility = View.GONE

                if (homeworkList.isNotEmpty()) {
                    // Update the RecyclerView with data
                    adapter = HomeworkAdapter(homeworkList, ::onEditClick, ::onDeleteClick)
                    binding.RecyclerViewAddHomeWork.adapter = adapter
                    binding.RecyclerViewAddHomeWork.visibility = View.VISIBLE // Show RecyclerView when data is ready
                } else {
                    // Handle empty list (e.g., show a "No Homework Found" message)
                    Toast.makeText(requireContext(), "No homework found", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Handle case where data could not be retrieved (e.g., show error message)
                binding.progressBar.visibility = View.GONE
                Toast.makeText(requireContext(), "Failed to load homework list", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun initView() {
        adapter = HomeworkAdapter(emptyList(), ::onEditClick, ::onDeleteClick)
      binding.RecyclerViewAddHomeWork.adapter = adapter
       binding.RecyclerViewAddHomeWork.layoutManager = LinearLayoutManager(requireContext())
    }

    /*
private fun observalAllEmpSpinner(){
    val schoolId = getSchoolId()  // Get the dynamic school_id

    viewModel.getAllEmployees(schoolId.trim()).observe(viewLifecycleOwner) { response ->

    }
*/




    private fun setupViewModelClassNameStudent() {
        val repository = AllClassRepository()
        val factory = AllClassViewModelFactory(repository)
        viewmodelAllClass = ViewModelProvider(this, factory).get(AllClassViewModel::class.java)
    }

    private fun setUpListeners() {
        binding.btnAddHomeworks1.setOnClickListener {
            showAddHomeworkDialog()
        }
    }

    private fun showAddHomeworkDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_customhome, null)
        val dialogBuilder = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .setCancelable(true)

        val dialog = dialogBuilder.create()

        // Retrieve UI elements
        val etHomeworkDetail = dialogView.findViewById<EditText>(R.id.edtHomeWorkDetail)
        val etClassName = dialogView.findViewById<Spinner>(R.id.edtClass)
        val etSubjectName = dialogView.findViewById<Spinner>(R.id.edtSubject) // Spinner for subjects
        val etDate = dialogView.findViewById<EditText>(R.id.edtDateHomeWork)
        val spnSendBy = dialogView.findViewById<Spinner>(R.id.edtSendBy)
        val btnSubmitHomework = dialogView.findViewById<Button>(R.id.btnAddHomeworks)

        val schoolId = getSchoolId().trim() // Method to fetch school ID
        Log.d("AddHomework", "School ID: $schoolId")

        // Populate the Send By spinner with employee names
        viewModelAllEmp.getAllEmployees(schoolId).observe(viewLifecycleOwner) { response ->
            if (response != null && response.employee.isNotEmpty()) {
                val employeeNames = response.employee.map { it.employee_name }
                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    employeeNames
                )
                spnSendBy.adapter = adapter
            } else {
                Log.d("AddHomework", "No employees found")
            }
        }

        // Fetch and populate the classes spinner
        viewmodelAllClass.getClasses(schoolId).observe(viewLifecycleOwner) { response ->
            if (response != null && response.status) {
                val classList = response.data.map { it.class_name }
                val classAdapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    classList
                )
                etClassName.adapter = classAdapter
            } else {
                Log.d("AddHomework", "No classes found")
            }
        }

        // Setup listener to trigger the subject fetch when class is selected
        etClassName.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedClass = parent.getItemAtPosition(position).toString().trim()
                Log.d("AddHomework", "Selected Class: $selectedClass")

                // Fetch subjects dynamically based on the selected class
                fetchSubjectsForClass(selectedClass, schoolId, etSubjectName)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed when nothing is selected
            }
        }

        // Set default date
        val calendar = Calendar.getInstance()
        val defaultDate = "${calendar.get(Calendar.DAY_OF_MONTH).padToTwoDigits()}/" +
                "${(calendar.get(Calendar.MONTH) + 1).padToTwoDigits()}/" +
                "${calendar.get(Calendar.YEAR)}"
        etDate.setText(defaultDate)

        // Date picker dialog
        etDate.setOnClickListener {
            showDatePickerDialog(etDate)
        }

        // Submit homework
        btnSubmitHomework.setOnClickListener {
            val homeworkDetail = etHomeworkDetail.text.toString().trim()
            val className = etClassName.selectedItem.toString().trim()
            val date = etDate.text.toString().trim()
            val teacher = spnSendBy.selectedItem?.toString()?.trim() ?: ""
            val subject = etSubjectName.selectedItem.toString().trim()

            if (homeworkDetail.isNotEmpty() && className.isNotEmpty() &&
                date.isNotEmpty() && teacher.isNotEmpty() && subject.isNotEmpty()
            ) {
                val homeworkData = mapOf(
                    "homework_detail" to homeworkDetail,
                    "classes" to className,
                    "homework_date" to date,
                    "set_by" to teacher,
                    "school_id" to schoolId,
                    "subject" to subject
                )
                adapter.notifyDataSetChanged()

                Toast.makeText(requireContext(), "Homework Add Successfully", Toast.LENGTH_SHORT).show()

                // Send data to ViewModel for API call
                viewModelAddHome.addHomework(homeworkData)

                // Dismiss the dialog after submission
                fetchdata()

                dialog.dismiss()

                // Fetch the updated homework data after submission
                fetchdata()
                adapter.notifyDataSetChanged()

            } else {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    // Fetch subjects based on the selected class
    private fun fetchSubjectsForClass(className: String, schoolId: String, etSubjectName: Spinner) {
        val classwisesubject = mapOf(
            "class" to className,
            "school_id" to schoolId
        )

        // Call the ViewModel method to fetch subjects
        viewModelCalssWise.getSubjectsByClass(classwisesubject)
            .observe(viewLifecycleOwner) { response ->
                if (response != null && response.status) {
                    // Ensure you are getting a list of subject names here
                    val subjectList = response.data.map { it.subject_name }

                    // Create an ArrayAdapter for the spinner
                    val subjectAdapter = ArrayAdapter(
                        requireContext(),
                        android.R.layout.simple_spinner_dropdown_item,
                        subjectList
                    )

                    // Set the adapter to the subject spinner
                    etSubjectName.adapter = subjectAdapter
                } else {
                    Log.d("AddHomework", "No subjects found for selected class")

                    // Clear the spinner by setting an empty adapter
                    val emptyList = emptyList<String>()
                    val emptyAdapter = ArrayAdapter(
                        requireContext(),
                        android.R.layout.simple_spinner_dropdown_item,
                        emptyList
                    )
                    etSubjectName.adapter = emptyAdapter
                }
            }
    }

        private fun onEditClick(homework: Homework) {
        val dialogView =
            LayoutInflater.from(requireContext()).inflate(R.layout.dialog_customhome, null)
        val dialogBuilder = AlertDialog.Builder(requireContext())
            .setView(dialogView)
        val dialog = dialogBuilder.create()

        val etHomeworkDetail = dialogView.findViewById<EditText>(R.id.edtHomeWorkDetail)
        val etClassName = dialogView.findViewById<EditText>(R.id.edtClass)
        val etSubjectName = dialogView.findViewById<EditText>(R.id.edtSubject)
        val etDate = dialogView.findViewById<EditText>(R.id.edtDateHomeWork)
        val spnSendBy = dialogView.findViewById<Spinner>(R.id.edtSendBy) // Updated to Spinner
        val btnSubmitHomework = dialogView.findViewById<Button>(R.id.btnAddHomeworks)


        etHomeworkDetail.setText(homework.homework_detail)
        etClassName.setText(homework.classes)
        etSubjectName.setText(homework.subject)
        etDate.setText(homework.homework_date)

        btnSubmitHomework.text = "Update Homework"
        etDate.setOnClickListener {
            showDatePickerDialog(etDate)
        }


        btnSubmitHomework.setOnClickListener {
            val updatedHomeworkDetail = etHomeworkDetail.text.toString()
            val updatedClassName = etClassName.text.toString()
            val updatedDate = etDate.text.toString()
            val updatedTeacher = spnSendBy.selectedItem?.toString() ?: ""
            val updatedSubject = etSubjectName.text.toString()

            if (updatedHomeworkDetail.isNotEmpty() && updatedClassName.isNotEmpty() &&
                updatedDate.isNotEmpty() && updatedTeacher.isNotEmpty() && updatedSubject.isNotEmpty()
            ) {

                homework.homework_detail = updatedHomeworkDetail
                homework.classes = updatedClassName
                homework.homework_date = updatedDate
                homework.set_by = updatedTeacher
                homework.subject = updatedSubject

                adapter.notifyDataSetChanged()
                dialog.dismiss()
                Toast.makeText(requireContext(), "Homework Updated", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT)
                    .show()
            }
        }

        dialog.show()
    }


    private fun onDeleteClick(homework: Homework) {
        homeworkList.remove(homework)
        adapter.notifyDataSetChanged()
        Toast.makeText(requireContext(), "Homework deleted", Toast.LENGTH_SHORT).show()
    }

    private fun showDatePickerDialog(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        // Set the current date as the default value in the EditText field
        val defaultDate = "${day.padToTwoDigits()}/${(month + 1).padToTwoDigits()}/$year"
        editText.setText(defaultDate)

        // Create the DatePickerDialog and set the default date as the initial selection
        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, selectedYear, selectedMonth, selectedDay ->
                val formattedDate =
                    "${selectedDay.padToTwoDigits()}/${(selectedMonth + 1).padToTwoDigits()}/$selectedYear"
                editText.setText(formattedDate)
            },
            year, month, day  // Use the current date as the initial date
        )

        // Show the DatePickerDialog
        datePickerDialog.show()
    }

    private fun Int.padToTwoDigits() = if (this < 10) "0$this" else "$this"
}