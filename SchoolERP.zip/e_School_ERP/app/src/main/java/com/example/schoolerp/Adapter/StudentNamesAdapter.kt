package com.example.schoolerp.adapter

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolerp.R
import com.example.schoolerp.databinding.ListItemStudentNameBinding

class StudentNamesAdapter(
    val studentNames: List<String?>, // Allow nullable Strings in the list
    private val onAttendanceChanged: (String, String) -> Unit // Callback for attendance change
) : RecyclerView.Adapter<StudentNamesAdapter.StudentNamesViewHolder>() {

    inner class AttendanceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val btnPresent: TextView = itemView.findViewById(R.id.btnPresent)
        val btnAbsent: TextView = itemView.findViewById(R.id.btnAbsent)
        val btnLeave: TextView = itemView.findViewById(R.id.btnLeave)
        val linearLayout: LinearLayout = itemView.findViewById(R.id.listItemBody)
        val defaultColor = ContextCompat.getColor(itemView.context, android.R.color.transparent)
        val textColor = ContextCompat.getColor(itemView.context, R.color.black)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentNamesViewHolder {
        val binding = ListItemStudentNameBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return StudentNamesViewHolder(binding, onAttendanceChanged)
    }

    override fun onBindViewHolder(holder: StudentNamesViewHolder, position: Int) {
        val studentName = studentNames[position]
        if (studentName != null) {
            holder.bind(studentName, position)
        } else {
            // Handle null case gracefully
        }
    }

    override fun getItemCount(): Int = studentNames.size

    class StudentNamesViewHolder(
        private val binding: ListItemStudentNameBinding,
        private val onAttendanceChanged: (String, String) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(studentName: String, position: Int) {
            // Display the student name
            binding.studentNameText.text = studentName
            // Alternate background color between white and gray
            val color = if (position % 2 == 0) {
                ContextCompat.getColor(itemView.context, R.color.white)
            } else {
                ContextCompat.getColor(itemView.context, R.color.gray)
            }
            // Set the background color
            binding.listItemBody.setBackgroundColor(color)
            // Reset button backgrounds and text colors before setting listeners
            resetButtonStyles()
            // Set attendance buttons logic
            binding.btnPresent.setOnClickListener {
                resetButtonStyles()
//                binding.btnPresent.setBackgroundColor(ContextCompat.getColor(itemView.context, R.color.red))
                binding.btnPresent.setBackgroundResource(R.drawable.attendance_drawable_selected_p)
                binding.btnPresent.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                binding.btnPresent.setTypeface(null, Typeface.BOLD)
                binding.btnAbsent.setBackgroundResource(R.drawable.attendance_drawable_selector)
                binding.btnAbsent.setTypeface(null, Typeface.NORMAL)
                binding.btnLeave.setBackgroundResource(R.drawable.attendance_drawable_selector)
                binding.btnLeave.setTypeface(null, Typeface.NORMAL)
                onAttendanceChanged(studentName, "P")
            }
            binding.btnAbsent.setOnClickListener {
                resetButtonStyles()
                binding.btnAbsent.setBackgroundResource(R.drawable.attendance_drawable_selected_a)
                binding.btnAbsent.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                binding.btnAbsent.setTypeface(null, Typeface.BOLD)
                onAttendanceChanged(studentName, "A")
                binding.btnPresent.setBackgroundResource(R.drawable.attendance_drawable_selector)
                binding.btnPresent.setTypeface(null, Typeface.NORMAL)
                binding.btnLeave.setBackgroundResource(R.drawable.attendance_drawable_selector)
                binding.btnLeave.setTypeface(null, Typeface.NORMAL)
            }
            binding.btnLeave.setOnClickListener {
                resetButtonStyles()
                binding.btnLeave.setBackgroundResource(R.drawable.attendance_drawable_selected_l)
                binding.btnLeave.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                binding.btnLeave.setTypeface(null, Typeface.BOLD)
                val textColor = ContextCompat.getColor(itemView.context, R.color.black)
                binding.btnAbsent.setTextColor(textColor)
                onAttendanceChanged(studentName, "L")
                binding.btnPresent.setBackgroundResource(R.drawable.attendance_drawable_selector)
                binding.btnPresent.setTypeface(null, Typeface.NORMAL)
                binding.btnAbsent.setBackgroundResource(R.drawable.attendance_drawable_selector)
                binding.btnAbsent.setTypeface(null, Typeface.NORMAL)
            }
        }
        // Helper function to reset styles
        private fun resetButtonStyles() {
            val textColor = ContextCompat.getColor(itemView.context, R.color.black)
            binding.btnPresent.setBackgroundResource(R.drawable.attendance_drawable_selected_p)
            binding.btnPresent.setTextColor(textColor)
            binding.btnAbsent.setTextColor(textColor)
            binding.btnLeave.setTextColor(textColor)
        }
    }
}

           // binding.radioGroupStatus.check(binding.radioButtonA.id)  // Set "A" as default

           /* binding.radioGroupStatus.setOnCheckedChangeListener { _, checkedId ->
                val status = when (checkedId) {
                    binding.radioButtonA.id -> "P" // Absent
                    binding.radioButtonB.id -> "A" // Present
                    binding.radioButtonC.id -> "L" // Present

                    else -> ""
                }
                onAttendanceChanged(studentName, status)
            }
        }

        fun clear() {
            binding.studentNameText.text = "No Name Available"
           // binding.radioGroupStatus.setOnCheckedChangeListener(null) // Remove any listener to avoid stale references
        }
    }
}
*/