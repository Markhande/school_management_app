package com.example.schoolerp.repository

import com.example.schoolerp.Api.ApiService
import com.example.schoolerp.Api.RetrofitHelper

class PaySalaryRepository{

    private val apiService: ApiService = RetrofitHelper.getApiService()

  /*  fun paySalary(
        employeeId: String,
        employeeName: String,
        employeeRole: String,
        fhName: String,
        salaryMonth: String,
        salaryAmount: String,
        salaryDate: String,
        bonus: String,
        deduction: String,
        netPaid: String
    ): MutableLiveData<paySalaryData?> {
        val result = MutableLiveData<paySalaryData?>()

        apiService.paySalary(employeeId, employeeName, employeeRole, fhName, salaryMonth, salaryAmount, salaryDate, bonus, deduction, netPaid)
            .enqueue(object : Callback<paySalaryData> {
                override fun onResponse(call: Call<paySalaryData>, response: Response<paySalaryData>) {
                    if (response.isSuccessful && response.body() != null) {
                        result.value = response.body()
                    } else {
                        result.value = null
                    }
                }

                override fun onFailure(call: Call<paySalaryData>, t: Throwable) {
                    result.value = null
                }
            })
*/
      //  return result

}