package com.example.schoolerp.Fragments

import android.app.DatePickerDialog
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.Student
import com.example.schoolerp.R
import com.example.schoolerp.SchoolId.SchoolId
import com.example.schoolerp.databinding.FragmentEditStudentBinding
import com.example.schoolerp.databinding.ListItemStudentNameBinding
import com.example.schoolerp.repository.AllEmployeesRepository
import com.example.schoolerp.repository.EditStudentRepository
import com.example.schoolerp.viewmodel.AllEmployeesViewModel
import com.example.schoolerp.viewmodel.EditStudentViewModel
import com.example.schoolerp.viewmodelfactory.AllEmployeesViewModelFactory
import com.example.schoolerp.viewmodelfactory.EditStudentViewModelFactory
import java.util.Calendar

class EditStudent : Fragment() {
    private lateinit var binding: FragmentEditStudentBinding
    private lateinit var viewModel: EditStudentViewModel
    private var selectedGender: String? = null
    private lateinit var edDateOfBirth: EditText
    private lateinit var edDateOfAdmission: EditText
    private var selectedImageUri: Uri? = null

    private lateinit var imageView: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            FragmentEditStudentBinding.bind(inflater.inflate(R.layout.fragment_edit_student, null))


        val apiService = RetrofitHelper.getApiService()
        val repository = EditStudentRepository(apiService)
        val factory = EditStudentViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory).get(EditStudentViewModel::class.java)
        arguments?.getParcelable<Student>("student")?.let { student ->
            populateFields(student)
        }

        SetUpLisners()
        return binding.root
    }

    private fun populateFields(student: Student) {
        binding.etschoolId.setText(student.school_id)
        binding.etStudentName.setText(student.st_name)
        binding.etregistrationNo.setText(student.registration_no)
        binding.spStudentSelectClass.setSelection(
            getSpinnerIndex(
                binding.spStudentSelectClass,
                student.st_class
            )
        )
        binding.etDateOfAdmission.setText(student.dt_of_admission)
        binding.etDiscountFees.setText(student.discount_fee)
        binding.etPhoneNumber.setText(student.number)
        binding.edDateOfBirth.setText(student.dt_of_birth)
        binding.spSelectReligion.setSelection(
            getSpinnerIndex(
                binding.spSelectReligion,
                student.religion
            )
        )
        binding.spSelectBloodGroup.setSelection(
            getSpinnerIndex(
                binding.spSelectBloodGroup,
                student.blood_group
            )
        )
        binding.etOrphanStudent.setText(student.orphan_student.toString())
        binding.etOSC.setText(student.osc)
        binding.etPreviousId.setText(student.previous_id)
        binding.etSelectFamily.setText(student.family)
        binding.edDiseaseIfAny.setText(student.disease_if_any)
        binding.etAnyAdditionalNote.setText(student.additional_note)
        binding.etTotalSibling.setText(student.siblings)
        binding.etAddress.setText(student.address)
        binding.etFatherName.setText(student.father_name)
        binding.etFatherID.setText(student.father_id)
        binding.etFatherEducatino.setText(student.father_education)
        binding.etFatherOccupation.setText(student.father_occupation)
        binding.etMotherName.setText(student.mother_name)
        binding.etMotherID.setText(student.mother_id)
        binding.etIdentityMark.setText(student.identification_mark)
        binding.etPreviousSchool.setText(student.st_previous_school)
        binding.etcreatedAt.setText(student.created_at)
        binding.TxtId.setText(student.id)


        // Handle setting gender (assuming radio buttons or dropdown)
        setSelectedGender(student.gender)

        // Load the image if available
        /*if (student.picture.isNotEmpty()) {
            val imageUri = Uri.parse(student.picture)
            binding.imageView.setImageURI(imageUri)  // Assuming `imageView` is the ImageView for the picture
        }*/
    }

    private fun getSpinnerIndex(spinner: Spinner, value: String): Int {
        for (i in 0 until spinner.count) {
            if (spinner.getItemAtPosition(i).toString().equals(value, ignoreCase = true)) {
                return i
            }
        }
        return 0
    }

    // Assuming you have a function to set the selected gender (for RadioButtons or Spinner)
    private fun setSelectedGender(gender: String) {
        when (gender) {
            "Male" -> binding.radioMale.isChecked = true
            "Female" -> binding.radioFemale.isChecked = true
            // Add other cases if needed
        }
    }


    private fun handleGenderSelection() {
        val selectedId: Int = binding.radioGroupGender.checkedRadioButtonId
        if (selectedId != -1) {
            val selectedRadioButton: RadioButton = binding.root.findViewById(selectedId)
            selectedGender = selectedRadioButton.text.toString()
            Toast.makeText(activity, "Selected: $selectedGender", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(activity, "No gender selected", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showDatePicker(isBirthDate: Boolean) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog =
            DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
                val date = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                if (isBirthDate) {
                    edDateOfBirth.setText(date)
                } else {
                    edDateOfAdmission.setText(date)
                }
            }, year, month, day)

        datePickerDialog.show()
    }

    private fun SetUpLisners() {

        binding.btnSubmit.setOnClickListener {
            handleGenderSelection()
            EditStudent1()
        }
        edDateOfBirth = binding.edDateOfBirth
        edDateOfAdmission = binding.etDateOfAdmission
        imageView = binding.imageStudent  // Correctly reference the ImageView ID

        edDateOfBirth.setOnClickListener { showDatePicker(true) }
        edDateOfAdmission.setOnClickListener { showDatePicker(false) }


    }

    private fun getSelectedGender(): String {
        return selectedGender ?: "Not specified"
    }

    private fun EditStudent1() {
        val schoolId = SchoolId().getSchoolId(requireContext())

        val EditStudentMap = mapOf(
            "school_id" to schoolId,
            "st_name" to (binding.etStudentName.text?.toString() ?: ""),
            "registration_no" to (binding.etregistrationNo.text?.toString() ?: ""),
            "st_class" to (binding.spStudentSelectClass.selectedItem?.toString() ?: ""),
            "picture" to (/*binding.etPicture.text?.toString() ?:*/ ""),
            "dt_of_admission" to (binding.etDateOfAdmission.text?.toString() ?: ""),
            "discount_fee" to (binding.etDiscountFees.text?.toString() ?: ""),
            "identification_mark" to (/*binding.etIdentificationMark.text?.toString() ?:*/ "kkj"),
            "st_birth_id" to (binding.etBirthId.text?.toString() ?: ""),
            "st_previous_school" to (binding.etPreviousSchool.text?.toString() ?: ""),
            "number" to (binding.etPhoneNumber.text?.toString() ?: ""),
            "dt_of_birth" to (edDateOfBirth.text?.toString() ?: ""),
            "religion" to (binding.spSelectReligion.selectedItem?.toString() ?: ""),
            "blood_group" to (binding.spSelectBloodGroup.selectedItem?.toString() ?: ""),
            "orphan_student" to (binding.etOrphanStudent.text?.toString() ?: "0"),
            "gender" to getSelectedGender(),
            "cast" to (binding.spSelectCast.selectedItem?.toString() ?: ""),
            "osc" to (binding.etOSC.text?.toString() ?: ""),
            "address" to (binding.etAddress.text?.toString() ?: ""),
            "father_name" to (binding.etFatherName.text?.toString() ?: ""),
            "father_id" to (/*binding.etFatherId.text?.toString() ?:*/ "kk"),
            "father_education" to (/*binding.etFatherEducation.text?.toString() ?:*/ "kkf"),
            "father_mobile" to (binding.etFatherMobile.text?.toString() ?: ""),
            "father_profession" to (binding.etFatherProfession.text?.toString() ?: ""),
            "father_income" to (/*binding.etFatherIncome.text?.toString() ?:*/""),
            "father_occupation" to (binding.etFatherOccupation.text?.toString() ?: ""),
            "mother_name" to (binding.etMotherName.text?.toString() ?: ""),
            "mother_id" to (/*binding.etMotherId.text?.toString() ?:*/ "dflkfdkj"),
            "mother_mobile" to (binding.etMotherMobile.text?.toString() ?: ""),
            "mother_occupation" to (binding.etMotherOccupation.text?.toString() ?: ""),
            "mother_income" to (/*binding.etMotherIncome.text?.toString() ?:*/ "sdkjfds"),
            "mother_education" to (binding.etMotherEducation.text?.toString() ?: ""),
            "mother_profession" to (binding.etMotherProfession.text?.toString() ?: ""),
            "status" to (/*binding.etStatus.text?.toString() ?:*/ "Active"),
            "id" to (binding.TxtId.text?.toString() ?: ""),
            "created_at" to (binding.etcreatedAt.text?.toString() ?: "")
        )
        Toast.makeText(requireContext(), "Student updated successfully!", Toast.LENGTH_SHORT).show()
        Log.d("EditStudent", "Student data as Map: $EditStudentMap")
        viewModel.editStudent(EditStudentMap)
    }
}