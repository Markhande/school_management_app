package com.example.schoolerp.DataClasses

class AllClassResponse (
    var status: Boolean? = null,
    var message: String? = null,
    var data: List<AllClassData>? = null
)
