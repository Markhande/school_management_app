package com.example.schoolerp.DataClasses

data class GetMessageData(    val id: String,
                              val recipient_type: String,
                              val search_specific: String,
                              val message: String,
                              val attachment: String?,
                              val school_id: String,
                              val created_at: String
)

