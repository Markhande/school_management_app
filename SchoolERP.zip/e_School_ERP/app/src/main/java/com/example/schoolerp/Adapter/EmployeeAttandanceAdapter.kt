package com.example.schoolerp.Adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.schoolerp.Adapters.AbsentStudentAdapter
import com.example.schoolerp.DataClasses.AbsentStudent
import com.example.schoolerp.DataClasses.EmployeeAttendance
import com.example.schoolerp.R
import com.example.schoolerp.databinding.ItemEmployeeAttendanceBinding


class EmployeeAttandanceAdapter(
    private var attendanceList: List<EmployeeAttendance> = mutableListOf()
) : RecyclerView.Adapter<EmployeeAttandanceAdapter.EmployeeViewHolder>() {


    // Method to update data in the adapter
    fun updateData(newData: List<EmployeeAttendance>) {
        Log.d("AttendanceData", "Updating adapter with new data: $newData")


        // Log the size of the data added to the adapter
        Log.d("AttendanceData", "Adapter data size after update: ${attendanceList.size}")

        notifyDataSetChanged() // Notify the adapter that the data has changed
    }

    // ViewHolder class to bind data to each item view
    class EmployeeViewHolder(private val binding: ItemEmployeeAttendanceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(employeeAttendance: EmployeeAttendance) {
            // Set the name, default to "Unknown" if the name is null
            binding.textViewStudentName.text = employeeAttendance.employee_name.ifEmpty { "Unknown" }

            // Set the image for the employee, use a default if the resource is null
            if (employeeAttendance.imgRes != null) {
                binding.imageViewStudent.setImageResource(employeeAttendance.imgRes)
            } else {
                binding.imageViewStudent.setImageResource(R.drawable.officer)
            }
        }

    }

    // Create the ViewHolder and return it
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmployeeViewHolder {
        val binding = ItemEmployeeAttendanceBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EmployeeViewHolder(binding)
    }

    // Bind data to the ViewHolder for a specific position
    override fun onBindViewHolder(holder: EmployeeViewHolder, position: Int) {
        holder.bind(attendanceList[position])
    }

    // Return the size of the data list (number of items)
    override fun getItemCount(): Int = attendanceList.size
}
