package com.example.onboardingschool

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.schoolerp.Activities.MainActivity
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.databinding.ActivityLoginPageBinding
import com.example.schoolerp.repository.UserRepository
import com.example.schoolerp.viewmodel.LoginViewModel
import com.example.schoolerp.viewmodel.LoginViewModelFactory

class LoginPage : AppCompatActivity() {

    private lateinit var binding: ActivityLoginPageBinding
    private lateinit var sharedPreferences: SharedPreferences
    private val loginViewModel: LoginViewModel by viewModels {
        LoginViewModelFactory(UserRepository(RetrofitHelper.getApiService()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("onboarding_prefs", MODE_PRIVATE)

        // Check if the user is logged in already
        if (sharedPreferences.getBoolean("is_logged_in", false)) {
            navigateToMainActivity()
            return
        }

        // Set listeners for login and password visibility toggle
        setListeners()
        observeViewModel()

        binding.eyeOpen.setOnClickListener {
            togglePasswordVisibility(true)
        }

        binding.eyeClose.setOnClickListener {
            togglePasswordVisibility(false)
        }
    }

    private fun setListeners() {
        binding.btnLogin.setOnClickListener {
            val schoolId = binding.usernameEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            if (schoolId.isNotEmpty() && password.isNotEmpty()) {
                loginViewModel.login(schoolId, password)
            } else {
                Toast.makeText(this, "Please enter both school ID and password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeViewModel() {
        loginViewModel.loginResponse.observe(this) { response ->
            if (response?.status == true) {
                Toast.makeText(this, "Login successful ${response.role}", Toast.LENGTH_SHORT).show()
                when {
                    response.role.equals("Admin", ignoreCase = true) -> {
                        sharedPreferences.edit()
                            .putString("school_id", response.school_id)
//                            .putString("role", response.role)
                            .putString("school_name", response.school_name)
//                            .putString("employee_id", response.employee_id)
                            .putString("password", response.password)
                            .putString("number", response.phone_number)
                            .putString("created_at", response.updated_at)
                            .putString("school_id", response.school_id)
                            .putString("role", response.role)
                            .putString("institute_address", response.institute_address)
                            .putString("website", response.website)
                            .putString("tagline", response.tag_line)
                            .putBoolean("is_logged_in", true).apply()
                        sharedPreferences.edit()
                        navigateToMainActivity()
                    }
                    response.role.equals("Teacher", ignoreCase = true) -> {
                        sharedPreferences.edit()
                            .putString("school_id", response.school_id)
                            .putString("role", response.role)
                            .putBoolean("is_logged_in", true).apply()
                        navigateToMainActivity()
                    }
                    response.role.equals("Manager", ignoreCase = true) -> {
                        sharedPreferences.edit().putString("school_id", response.school_id).apply()
                        sharedPreferences.edit().putBoolean("is_logged_in", true).apply()
                        navigateToMainActivity()
                    }
                    response.role.equals("Student", ignoreCase = true) -> {
                        sharedPreferences.edit().putString("school_id", response.school_id).apply()
                        sharedPreferences.edit().putBoolean("is_logged_in", true).apply()
                        sharedPreferences.edit().putString("role", response.role).apply()
                        navigateToMainActivity()
                    }
                    response.role.equals("Principal", ignoreCase = true) -> {
                        sharedPreferences.edit()
                            .putString("school_id", response.school_id)
                            .putString("school_name", response.school_name)
//                            .putString("employee_id", response.employee_id)
                            .putString("password", response.password)
                            .putString("number", response.phone_number)
                            .putString("created_at", response.updated_at)
                            .putString("school_id", response.school_id)
                            .putString("role", response.role)
                            .putString("institute_address", response.institute_address)
                            .putString("website", response.website)
                            .putString("tagline", response.tag_line)
                            .putBoolean("is_logged_in", true).apply()
                        sharedPreferences.edit()
                        navigateToMainActivity()
                    }
                    else -> {
                        Toast.makeText(this, "Unknown role", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Invalid login credentials", Toast.LENGTH_SHORT).show()
            }
        }

        loginViewModel.errorMessage.observe(this) { error ->
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePasswordVisibility(isVisible: Boolean) {
        if (isVisible) {
            binding.eyeOpen.visibility = View.GONE
            binding.eyeClose.visibility = View.VISIBLE
            binding.passwordEditText.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            binding.eyeClose.visibility = View.GONE
            binding.eyeOpen.visibility = View.VISIBLE
            binding.passwordEditText.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        binding.passwordEditText.setSelection(binding.passwordEditText.text.length)
    }

    private fun navigateToMainActivity() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
