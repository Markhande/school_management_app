package com.example.schoolerp.Fragments


import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.schoolerp.R
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.databinding.FragmentAddExpenseBinding
import com.example.schoolerp.repository.AddExpenseRepository
import com.example.schoolerp.viewmodel.AddExpenseViewModel
import com.example.schoolerp.viewmodelfactory.AddExpenseViewModelFactory
import java.util.Calendar

class AddExpense : Fragment() {
    private lateinit var binding: FragmentAddExpenseBinding
    private val viewModel: AddExpenseViewModel by viewModels {
        AddExpenseViewModelFactory(AddExpenseRepository(RetrofitHelper.getApiService()))
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            FragmentAddExpenseBinding.bind(inflater.inflate(R.layout.fragment_add_expense, null))

        // Set up submit button click listener
        binding.btnSubmit.setOnClickListener {
            submitExpenseData()
        }

        // Set up date picker for the EditText
        binding.edtDateExpense.setOnClickListener {
            showDatePickerDialog()
        }

        return binding.root
    }

    private fun showDatePickerDialog() {
        // Get current date
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        // Create DatePickerDialog
        val datePickerDialog =
            DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
                // Format the date and set it to the EditText
                val formattedDate = String.format(
                    "%02d/%02d/%02d",
                    selectedDay,
                    selectedMonth + 1,
                    selectedYear % 100
                )
                binding.edtDateExpense.setText(formattedDate)
            }, year, month, day)

        datePickerDialog.show()
    }

    private fun submitExpenseData() {
        // Collect form data from input fields
        val expenseDate = binding.edtDateExpense.text.toString()
        val expenseAmount = binding.edtExpenseAmount.text.toString()
        val expenseDescription = binding.edtExpenseDescription.text.toString()

        // Validate input data
        if (expenseDate.isEmpty() || expenseAmount.isEmpty() || expenseDescription.isEmpty()) {
            Toast.makeText(activity, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Prepare data to be sent to the ViewModel
        val expenseData = HashMap<String, String>().apply {
            put("date_of_expense", expenseDate)
            put("expense_amount", expenseAmount)
            put("expense_description", expenseDescription)
        }

        // Observe LiveData from ViewModel
        viewModel.submitExpenseData(expenseData).observe(viewLifecycleOwner) { apiResponse ->
            if (apiResponse != null) {
                // Check if the response indicates success
                val message = apiResponse.Message ?: "Expense added successfully"
                if (apiResponse.status) {
                    Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(activity, "Failed to add Expense: $message", Toast.LENGTH_SHORT)
                        .show()
                }
            } else {
                Toast.makeText(activity, "Failed to add Expense", Toast.LENGTH_SHORT).show()
            }
        }
    }
}


