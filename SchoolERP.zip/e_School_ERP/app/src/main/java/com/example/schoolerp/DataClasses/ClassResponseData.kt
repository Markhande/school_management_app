package com.example.schoolerp.DataClasses

class ClassResponseData (
    val status: Boolean,
    val message: String
)

