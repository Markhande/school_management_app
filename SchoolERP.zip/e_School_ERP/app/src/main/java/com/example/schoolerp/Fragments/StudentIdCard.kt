package com.example.schoolerp.Fragments.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.example.schoolerp.Adapter.StduentIDAdapter
import com.example.schoolerp.Api.ApiService
import com.example.schoolerp.Api.RetrofitHelper
import com.example.schoolerp.DataClasses.StudentIDData
import com.example.schoolerp.R
import com.example.schoolerp.databinding.FragmentStudentIdCardBinding
import com.example.schoolerp.models.responses.StudentIdCardRespones
import com.example.schoolerp.models.responses.getStudentIdcardResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class StudentIdCard : Fragment() {

    private lateinit var binding: FragmentStudentIdCardBinding
    private lateinit var studentIDAdapter: StduentIDAdapter
    private val classList = mutableListOf<StudentIDData>()
    private val apiService = RetrofitHelper.getApiService()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentStudentIdCardBinding.inflate(inflater, container, false)
        initView()
        fetchStudentIdCardData() // Fetch student data from API
        return binding.root
    }

    private fun initView() {
        val gridLayoutManager = GridLayoutManager(activity, 1)
        binding.recyclerViewStudentIdCard.layoutManager = gridLayoutManager
        studentIDAdapter = StduentIDAdapter(classList)
        binding.recyclerViewStudentIdCard.adapter = studentIDAdapter
    }

    private fun fetchStudentIdCardData() {
        // Make the API call
        apiService.getStudentIcard("eraAbc").enqueue(object :
            Callback<getStudentIdcardResponse> {
            override fun onResponse(
                call: Call<getStudentIdcardResponse>,
                response: Response<getStudentIdcardResponse>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    val studentData = response.body()!!.StudentIdCardRespones
                    // Map the API response to the list format your adapter requires
                    val studentList = studentData.map {
                        StudentIDData(
                            name = it.st_name,
                            studentId = it.id,
                            dob = it.dt_of_birth ?: "",
                            address = it.address

                        )
                    }
                    // Update the RecyclerView adapter
                    studentIDAdapter.updateStudentList(studentList)
                } else {
                    Toast.makeText(context, "Failed to load data", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<getStudentIdcardResponse>, t: Throwable) {
                Toast.makeText(context, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
