package com.example.schoolerp.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.schoolerp.DataClasses.paySalaryData
import com.example.schoolerp.repository.PaySalaryRepository

class PaySalaryViewModel(private val repository: PaySalaryRepository) : ViewModel() {

}

  /*  fun paySalary(
        employeeId: String,
        employeeName: String,
        employeeRole: String,
        fhName: String,
        salaryMonth: String,
        salaryAmount: String,
        salaryDate: String,
        bonus: String,
        deduction: String,
        netPaid: String
    ): MutableLiveData<paySalaryData?> */
        //return repository.paySalary(employeeId, employeeName, employeeRole, fhName, salaryMonth, salaryAmount, salaryDate, bonus, deduction, netPaid)

