package com.example.schoolerp.models.responses

data class ClassWiseSubjectResponse(
    val status: Boolean,
    val data: List<Subject>
)
